import React, { } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import styles from './styles';
import * as IMAGES from 'src/assets/images'
import { useNavigation } from '@react-navigation/native';


interface ICellProps {
    item?: any
}

const cell = (props: ICellProps) => {
    const { item } = props;
    const navigation = useNavigation()

    return (
        <View style={styles.ofcContainer}>
            <View style={[styles.ofcSubContainer, { backgroundColor: item.main ? '#4FB263' : "#1F2428" }]}>
                <View style={styles.detailConatainer}>
                    <Text style={styles.ofcName}>{item.name}</Text>
                    <Text style={styles.ofcDesignation}>{item.designation}</Text>
                    <Text style={styles.ofcCode}>{item.code}</Text>
                </View>
                <View style={styles.ofcButtonContainer}>
                    <TouchableOpacity style={styles.ofcButton} onPress={() => {
                        navigation.navigate('BioBO', {
                            item: item,
                        });
                    }}>
                        <Image source={IMAGES.IC_BIO} style={styles.ofcIcon} resizeMode={"contain"} />
                        <Text style={styles.ofcButtonText}>Bio</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.ofcButton}>
                        <Image source={IMAGES.IC_CALL} style={styles.ofcIcon} resizeMode={"contain"} />
                        <Text style={styles.ofcButtonText}>Call</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.ofcButton}>
                        <Image source={IMAGES.IC_TEXT} style={styles.ofcIcon} resizeMode={"contain"} />
                        <Text style={styles.ofcButtonText}>Text</Text>
                    </TouchableOpacity>
                    {item.main &&
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_DM} style={styles.ofcIcon} resizeMode={"contain"} />
                            <Text style={styles.ofcButtonText}>DM</Text>
                        </TouchableOpacity>
                    }
                </View>
            </View>
            <Image source={item.image} style={{ height: 100, width: 100, marginLeft: 20, position: 'absolute', top: 0 }} />
        </View>
    );
};
export default cell;
