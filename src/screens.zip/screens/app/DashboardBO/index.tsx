import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  ScrollView,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import CELL from './cell'
import { useNavigation } from '@react-navigation/native';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { toggleSettingOption } from 'src/redux/actions/common'


interface IDashboardLOProps {
  toggleSettingOption: any;
  showOptions: boolean;
}
const DashboardLO = (props: IDashboardLOProps) => {
  const navigation = useNavigation()

  const data = [
    {
      title: 'Calculator',
      image: IMAGES.IC_CELL_CAL
    },
    {
      title: 'Scan Documents',
      image: IMAGES.IC_CELL_SCAN
    },
    {
      title: 'Uploaded Documents',
      image: IMAGES.IC_CELL_DOC
    },
  ];
  const OfficerData = [
    {
      name: 'Robert Baker',
      designation: "Branch Manager",
      code: "NMLS : 236495",
      image: IMAGES.IC_DEMO_PROFILE,
      main: true
    },
    {
      name: 'Roy Miller',
      designation: "Branch Manager",
      code: "NMLS : 236495",
      image: IMAGES.IC_DEMO_PROFILE,
      main: false
    },
  ];
  const introData = {
    title: "Welcome!",
    detail: "Proin at sollicitudin molestie non quis tempor vestibulum ac. Nulla dignissim egestas iaculis sem mauris curabitur eget id euismod. Enim blandit nulla..."
  }
  React.useEffect(() => {

  }, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity style={styles.cellContainer}>
        <Image source={item.image} style={styles.cellImage} resizeMode={"contain"} />
        <Text style={styles.cellTitle}>{item.title}</Text>
      </TouchableOpacity>
    )
  }
  const renderIntro = () => {
    return (
      <View style={styles.introContainer}>
        <Text style={styles.introTitle}>{introData.title}</Text>
        <Text style={styles.introDetail}>{introData.detail}</Text>
        <TouchableOpacity style={styles.readMoreButton}>
          <Text style={styles.readMoreText}>READ MORE</Text>
        </TouchableOpacity>
      </View>
    )
  }
  const renderOfficer = () => {
    return (
      <View>
        <FlatList
          scrollEnabled={false}
          data={OfficerData}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.containStyle}
          renderItem={({ item }) => <CELL item={item} />}
        />
        {renderIntro()}
      </View >
    )
  }
  const selectOfficer = () => {
    return (
      <View>
        <TouchableOpacity style={styles.selectOfficeContainer} onPress={() => navigation.navigate("SelectLoanOfficerBO")}>
          <Text style={styles.loanOfficeText}>Select Loan Officer</Text>
        </TouchableOpacity>
      </View >
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Dashboard'}
          leftImg={IMAGES.IC_HEADER_SETTING}
          leftClick={() => props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView>
          {renderOfficer()}
          {/* {selectOfficer()} */}
          <FlatList
            scrollEnabled={false}
            data={data}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.containStyle}
            renderItem={({ item }) => renderItem(item)}
          />
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions
});

export default connect(mapStateToProps, {
  toggleSettingOption
})(DashboardLO);

