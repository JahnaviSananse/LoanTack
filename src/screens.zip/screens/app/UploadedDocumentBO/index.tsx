import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Image
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import { SwipeListView } from 'react-native-swipe-list-view';

// const data = [
//   { title: "img123.jpg", time: "3 mins ago" },
//   { title: "Rental Insurance", time: "1 hour ago" },
//   { title: "Health Insurance", time: "2 hours ago" }
// ]

const UploadedDocumentBO = () => {
  const navigation = useNavigation()
  let _swipeListView = null
  const [data, setData] = React.useState([
    { title: "img123.jpg", time: "3 mins ago" },
    { title: "Rental Insurance", time: "1 hour ago" },
    { title: "Health Insurance", time: "2 hours ago" }
  ]);
  React.useEffect(() => {
  }, [])
  const renderItem = (item: any) => {
    return (
      <View style={styles.cellContainer}>
        <Image source={IMAGES.IC_DOCUMENT_FILLED} style={styles.docImage} resizeMode={"contain"} />
        <Text style={styles.title}>{item.item.title}</Text>
        <Text style={styles.time}>{item.item.time}</Text>
      </View>
    )
  }
  const renderHiddenItem = (item: any, rowMap: any) => (
    <View style={styles.rowBack}>
      <TouchableOpacity
        style={[styles.backRightBtn, styles.backRightBtnRight]}
        onPress={() => {
          _swipeListView.safeCloseOpenRow();
          let tempAry = JSON.parse(JSON.stringify(data))
          tempAry.splice(item.index, 1)
          setData(tempAry)
        }}>
        <Image source={IMAGES.IC_DELETE} style={{ height: 25, width: 25 }} resizeMode={'contain'} />
      </TouchableOpacity>
    </View>
  );
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Uploaded Documents'}
          // leftImg={IMAGES.IC_BACK}
          // leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <SwipeListView
          ref={ref => _swipeListView = ref}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={(data) => renderItem(data)}
          renderHiddenItem={(data, rowMap) => renderHiddenItem(data, rowMap)}
          rightOpenValue={-50}
          previewRowKey={'0'}
          previewOpenValue={-40}
          previewOpenDelay={3000}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default UploadedDocumentBO;

