import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';


const DashboardLO = () => {
  const navigation = useNavigation()
  const [selectedOffer, setSelectedOffer] = React.useState({});
  const [modalVisible, setModalVisible] = React.useState(false);
  const data = [
    {
      title: 'Promotions',
      desc: 'Discount for the upcoming Thanksgiving occasion.',
      time: '1 hour ago',
    },
    {
      title: 'Tip of the Day',
      desc:
        'You can refer the app to a friend and earn rewards or discounts.',
      time: '2 hour ago',
    },
    {
      title: 'Reminders',
      desc:
        'Your subscription period is about to end. Please subscribe to continue enjoying the system.',
      time: '1 week ago',
    },
  ];
  React.useEffect(() => {

  }, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity
        onPress={() => {
          setSelectedOffer(item);
          setModalVisible(true);
        }}
        style={styles.cellContainer}>
        <Text style={styles.cellTitle}>{item.title}</Text>
        <Text style={styles.cellDesc}>{item.desc}</Text>
        <Text style={styles.cellTime}>{item.time}</Text>
      </TouchableOpacity>
    )
  }
  function renderPopup() {
    return (
      <View style={styles.popupView}>
        <Modal
          animationType="none"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => { }}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <TouchableOpacity
                onPress={() => setModalVisible(false)}
                style={styles.closeContainer}>
                <Image
                  source={IMAGES.IC_CLOSE}
                  resizeMode={'contain'}
                  style={styles.closeIcon}
                />
              </TouchableOpacity>
              <Text style={styles.modalTitle}>{selectedOffer.title}</Text>
              <Text style={styles.modalDesc}>{selectedOffer.desc}</Text>
              <View style={styles.modalSep} />
              <Text style={styles.useCodeText}>Use code</Text>
              <Text style={styles.codeText}>ThanksGiving30</Text>
              <Text style={styles.codeDesc}>
                to enjoy flat 30% discount for upcoming month’s subscription.
              </Text>
            </View>
          </View>
        </Modal>
      </View>
    );
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Dashboard'}
          rightImg={IMAGES.IC_NOTIFICATION}
          rightClick={() => navigation.navigate("NotificationLO")}
        />
        {renderPopup()}
        <View style={styles.dataContainer}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.containStyle}
            renderItem={({ item }) => renderItem(item)}
          />
        </View>
        <View style={styles.buttonContainer}>
          <COMPONENT.Button
            title={"REFER A FRIEND"}
            type={"fill"}
            onPress={() => console.log("refer")}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default DashboardLO;
