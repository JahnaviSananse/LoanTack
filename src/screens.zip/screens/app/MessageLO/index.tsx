import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import { useNavigation, useRoute } from '@react-navigation/native';
import styles from './styles';

const MessageLO = () => {
  const navigation = useNavigation()
  const data = [
    { name: "Robert Baker", time: "3 mins ago", message: true },
    { name: "Jack Smith", time: "42 mins ago", message: true },
    { name: "Oliver Ross", time: "1 hour ago", message: false },
    { name: "Ethan Fortin", time: "5 hours ago", message: false },
    { name: "Mike Rudd", time: "1 day ago", message: false }
  ]
  React.useEffect(() => {

  }, [])
  const renderItem = (item: any) => {
    return (
      <View>
        <TouchableOpacity onPress={() => {
          navigation.navigate('ChatLO', {
            name: item.name,
          })
        }
        } style={styles.cellContainer}>
          <View style={styles.avatarContainer}>
            <Image source={IMAGES.IC_AVATAR} style={styles.avatar} />
            {item.message && <View style={styles.messagePoint} />}
          </View>
          <Text style={styles.nameText}>{item.name}</Text>
          <Text style={styles.timeText}>{item.time}</Text>
        </TouchableOpacity>
        <View style={styles.separetor} />
      </View >
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"Message"}
          rightImg={IMAGES.IC_NOTIFICATION}
          rightClick={() => navigation.navigate("NotificationLO")}
        />
        <View style={styles.flatListContainer}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) =>
              renderItem(item)
            }
          />
          <TouchableOpacity onPress={() => navigation.navigate("SelectLO")} style={styles.FloatButton} >
            <Image source={IMAGES.IC_MESSAGE_ADD} style={styles.floatAdd} />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default MessageLO;

