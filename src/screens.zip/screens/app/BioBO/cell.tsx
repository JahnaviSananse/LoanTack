import React, { } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import styles from './styles';
import * as IMAGES from 'src/assets/images'
import { useNavigation } from '@react-navigation/native';


interface ICellProps {
    item?: any
}

const cell = (props: ICellProps) => {
    const { item } = props;
    const navigation = useNavigation()

    return (
        <View style={styles.ofcContainer}>
            <View style={styles.ofcSubContainer}>
                <View style={styles.detailConatainer}>
                    <Text style={styles.ofcName}>{item.name}</Text>
                    <Text style={styles.ofcDesignation}>{item.designation}</Text>
                    <Text style={styles.ofcCode}>{item.code}</Text>
                </View>
                <View style={styles.socialMargin}>
                    <View style={styles.ofcSocialContaier}>
                        <TouchableOpacity style={styles.ofcButton} onPress={() => navigation.navigate("BioBO")}>
                            <Image source={IMAGES.IC_WEBSITE} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_MAIL} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_FACEBOOK} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_TWITTER} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.ofcMoreSocialContaier}>
                        <TouchableOpacity style={styles.ofcButton} onPress={() => navigation.navigate("BioBO")}>
                            <Image source={IMAGES.IC_LINKEDIN} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_GPLUS} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_YOUTUBE} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.ofcButton}>
                            <Image source={IMAGES.IC_PINTEREST} style={styles.ofcIcon} resizeMode={"contain"} />
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </View >
    );
};
export default cell;
