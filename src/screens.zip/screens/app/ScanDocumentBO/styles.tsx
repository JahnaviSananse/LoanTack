import { StyleSheet, Dimensions, Platform } from 'react-native';
import * as COLOR from 'src/constants/colors'
import * as FONT from 'src/assets/fonts'
import * as CONSTANT from 'src/constants/constant'

let buttonSize = CONSTANT.SCREEN_WIDTH / 2 - 30
export default styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLOR.THEME.WHITE,
    flexDirection: "column",
  },
  keyboardAware: {
    flex: 1
  },
  mainContainer: {
    // justifyContent: "space-between"
  },
  title: {
    marginLeft: 15,
    marginTop: 20,
    fontSize: 20,
    fontWeight: 'bold',
    fontFamily: FONT.ROBOTO
  },
  extraPadding: {
    paddingBottom: 150
  },
  img: {
    height: 30,
    width: 30,
    alignSelf: 'center'
  },
  uploadDocumentContainer: {
    marginTop: '25%'
  },
  uploadDocumentButton: {
    backgroundColor: '#4FB263',
    borderRadius: 4,
    height: 40,
    justifyContent: 'center',
    alignSelf: "center"
  },
  uploadDocumentText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    paddingHorizontal: 20,
    fontFamily: FONT.ROBOTO
  },
  buttonTitle: {
    alignSelf: 'center',
    fontSize: 17,
    marginTop: 10,
    fontFamily: FONT.ROBOTO
  },
  buttonsContainer: {
    marginTop: 20,
    flexDirection: 'row',
    marginHorizontal: 20,
    justifyContent: 'space-between',
  },
  button: {
    backgroundColor: '#DEFFE5',
    width: buttonSize,
    height: buttonSize,
    borderStyle: 'dashed',
    borderColor: '#4FB263',
    borderWidth: 1,
    justifyContent: "center",
    alignItems: 'center',
    borderRadius: 4
  },
  popupView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 22,
  },
  toucableButton: {
    height: 40,
    width: '50%',
    backgroundColor: COLOR.THEME.GREEN,
    borderRadius: 4,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonTitle: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 15,
  },
  modalOverlay: {
    height: '100%',
    width: '100%',
    backgroundColor: '#00000095',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    width: '90%',
    alignSelf: 'center',
    borderRadius: 4,
  },
  closeContainer: {
    height: 30,
    width: 30,
    position: 'absolute',
    top: 10,
    right: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  popupImage: {
    height: 50,
    width: 50,
    alignSelf: 'center',
    paddingVertical: 50
  },
  desc: {
    alignSelf: 'center',
    fontSize: 17,
    marginTop: 20,
    fontWeight: 'bold'
  },
  buttonContainer: {
    marginTop: 10,
    marginBottom: 30,
    height: 100,
    justifyContent: "space-between"
  }
});
