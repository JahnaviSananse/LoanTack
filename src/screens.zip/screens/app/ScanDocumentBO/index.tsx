import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  ScrollView,
  Image
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import POPUP from './popup'

const ScanDocumentBO = () => {
  const navigation = useNavigation()
  const [showAlert, setShowAlert] = React.useState(false);
  const [fileName, setFileName] = React.useState("");
  React.useEffect(() => {
  }, [])
  const renderButton = () => {
    return (
      <View style={styles.uploadDocumentContainer}>
        <TouchableOpacity style={styles.uploadDocumentButton} onPress={() => navigation.navigate("UploadedDocumentBO")}>
          <Text style={styles.uploadDocumentText}>UPLOADED DOCUMENTS</Text>
        </TouchableOpacity>
      </View>
    )
  }
  const renderOptions = () => {
    return (
      <View>
        <View style={styles.buttonsContainer}>
          <View>
            <TouchableOpacity style={styles.button} onPress={() => setShowAlert(true)}>
              <Image source={IMAGES.IC_BUTTON_CAMERA} style={styles.img} resizeMode={'contain'} />
            </TouchableOpacity>
            <Text style={styles.buttonTitle}>Take a Photo</Text>
          </View>
          <View>
            <TouchableOpacity style={styles.button} onPress={() => setShowAlert(true)}>
              <Image source={IMAGES.IC_BUTTON_GALLARY} style={styles.img} resizeMode={'contain'} />
            </TouchableOpacity>
            <Text style={styles.buttonTitle}>Select from Gallery</Text>
          </View>
        </View>
        <View style={styles.buttonsContainer}>
          <View>
            <TouchableOpacity style={styles.button} onPress={() => setShowAlert(true)}>
              <Image source={IMAGES.IC_BUTTON_FILE} style={styles.img} resizeMode={'contain'} />
            </TouchableOpacity>
            <Text style={styles.buttonTitle}>Upload File</Text>
          </View>
        </View>
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Scan'}
          // leftImg={IMAGES.IC_BACK}
          // leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <POPUP type={"failure"}
          visible={showAlert}
          closeAlert={() => closeAlert()}
          onChangeText={(text: string) => setFileName(text)}
          value={fileName}
        />
        <Text style={styles.title}>Scan New Document</Text>
        <ScrollView style={styles.mainContainer} contentContainerStyle={styles.extraPadding}>
          {renderOptions()}
          {renderButton()}
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default ScanDocumentBO;

