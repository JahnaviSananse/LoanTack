import React from 'react';
import { Text, TouchableOpacity, View, Modal, Image, Alert } from 'react-native';
import styles from './styles'
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import { useNavigation, useRoute } from '@react-navigation/native';


interface IButtonProps {
    visible: boolean;
    type: string;
    closeAlert: any;
    onChangeText: any;
    value: any;
}

const Popup = (props: IButtonProps) => {
    const navigation = useNavigation();
    const { visible, closeAlert, onChangeText, value } = props;

    return (
        <View style={styles.popupView}>
            <Modal
                animationType="none"
                transparent={true}
                visible={visible}
                onRequestClose={() => { }}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContainer}>
                        <Text style={styles.desc}>{"Document Name"}</Text>
                        <COMPONENT.TextField
                            maxLength={50}
                            value={value}
                            keyboardType={"email-address"}
                            title={'Name'}
                            placeholder={'Enter Here'}
                            secureTextEntry={false}
                            onChangeText={(text: string) => {
                                onChangeText(text);
                            }}
                        />
                        <View style={styles.buttonContainer}>
                            <COMPONENT.Button
                                title={"NEXT"}
                                onPress={() => {
                                    closeAlert(false)
                                    setTimeout(() => {
                                        navigation.navigate("ScanedDocumentBO")
                                    }, 300);
                                }}
                                type={"fill"}
                            />
                            <COMPONENT.Button
                                title={"CANCEL"}
                                onPress={() => closeAlert(false)}
                                type={"unfill"}
                            />
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );

}
export default Popup;
