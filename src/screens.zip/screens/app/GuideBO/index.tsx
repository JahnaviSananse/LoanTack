import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { toggleSettingOption } from 'src/redux/actions/common'

const data = [
  { title: 'Learning Center', redirect: "LearningCenterBO", image: IMAGES.IC_LEARNING_CENTER },
  { title: 'Loan Programs', redirect: "LoanProgramsBO", image: IMAGES.IC_LOAN_CENTER },
  { title: 'Glossary', redirect: "GlossaryBO", image: IMAGES.IC_GLOSSARY },
  { title: 'Checklists', redirect: "ChecklistBO", image: IMAGES.IC_CHECKLIST },
]

interface IGuideBOProps {
  toggleSettingOption: any;
  showOptions: boolean;
}
const GuideBO = (props: IGuideBOProps) => {
  const navigation = useNavigation()
  React.useEffect(() => {

  }, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity style={styles.cellContainer} onPress={() => navigation.navigate(item.redirect)}>
        <Image source={item.image} style={styles.icon} resizeMode={'contain'} />
        <Text style={styles.title}>{item.title}</Text>
      </TouchableOpacity>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Guide'}
          leftImg={IMAGES.IC_HEADER_SETTING}
          leftClick={() => props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <FlatList
          scrollEnabled={false}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => renderItem(item)}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions
});

export default connect(mapStateToProps, {
  toggleSettingOption
})(GuideBO);

