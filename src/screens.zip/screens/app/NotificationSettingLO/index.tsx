import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Switch,
  View,
  SafeAreaView,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import * as COLOR from "src/constants/colors"
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const NotificationSettingLO = () => {
  const navigation = useNavigation()
  const [data, setData] = React.useState([])

  React.useEffect(() => {
    let ary = [
      { name: "Direct Message", enable: false },
      { name: "Document Upload", enable: false },
      { name: "Application download from your link", enable: false },
    ]
    setData(ary)
  }, [])

  const renderItem = (item: any, index: number) => {
    return (
      <View style={styles.mainContainer}>
        <View style={styles.nameContainer}>
          <Text style={styles.nameText}>{item.name}</Text>
        </View>
        <View style={styles.switchContainer}>
          <Switch
            style={styles.switchStyle}
            trackColor={{ true: COLOR.THEME.TRACK_COLOR_TRUE, false: COLOR.THEME.TRACK_COLOR_FALSE }}
            thumbColor={COLOR.THEME.WHITE}
            ios_backgroundColor={COLOR.THEME.TRACK_COLOR_FALSE}
            value={item.enable}
            onValueChange={() => {
              let currentData = JSON.parse(JSON.stringify(data))
              currentData[index].enable = currentData[index].enable ? false : true
              setData(currentData)
            }}
          />
        </View>
        <View style={styles.separetor} />
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"Notification Settings"}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <View style={styles.flatlistContainer}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => renderItem(item, index)}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default NotificationSettingLO;

