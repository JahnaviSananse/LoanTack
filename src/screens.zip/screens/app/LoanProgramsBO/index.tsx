import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const data = [
  { title: 'FHA' },
  { title: 'Conventional' },
  { title: 'Jumbo' },
  { title: 'USDA' },
  { title: 'VA' },
]

const LearningCenterBO = () => {
  const navigation = useNavigation()
  React.useEffect(() => {

  }, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity style={styles.cellContainer}>
        <Text style={styles.title}>{item.title}</Text>
        <View style={styles.saperator} />
      </TouchableOpacity>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Loan Programs'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <FlatList
          scrollEnabled={true}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => renderItem(item)}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default LearningCenterBO;
