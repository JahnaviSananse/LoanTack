import { StyleSheet } from 'react-native';
import * as COLOR from 'src/constants/colors';
import * as CONSTANT from 'src/constants/constant'

export default styles = StyleSheet.create({
  container: {
    height: '100%',
    width: '100%',
    backgroundColor: COLOR.THEME.WHITE,
    flexDirection: 'column',
  },
  keyboardAwareL: {
    flex: 1
  },
  cellContainer: {
    height: 75,
    width: "100%",
    justifyContent: 'center',
    alignSelf: 'center'
  },
  title: {
    marginLeft: 15,
    fontSize: 17,
    marginTop: 10,
    fontWeight: 'bold'
  },
  date: {
    marginLeft: 15,
    fontSize: 13,
    marginTop: 5,
    marginBottom: 20,
    fontStyle: 'italic',
    color: COLOR.THEME.LIGHT_GRAY
  },
  saperator: {
    height: 0.5,
    alignSelf: 'center',
    width: CONSTANT.SCREEN_WIDTH - 30,
    backgroundColor: COLOR.THEME.TRACK_COLOR_FALSE
  }
});
