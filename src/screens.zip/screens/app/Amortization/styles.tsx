import { StyleSheet } from 'react-native';
import * as COLOR from 'src/constants/colors';
import * as CONSTANT from 'src/constants/constant'
import * as FONT from 'src/assets/fonts'

export default styles = StyleSheet.create({
  container: {
    height: '100%',
    width: '100%',
    backgroundColor: COLOR.THEME.WHITE,
    flexDirection: 'column',
  },
  keyboardAwareL: {
    flex: 1
  },
  cellContainer: {
    height: 75,
    width: "100%",
    justifyContent: 'center',
    alignSelf: 'center'
  },
  title: {
    marginLeft: 15,
    fontSize: 17,
    marginTop: 10,
    fontWeight: 'bold'
  },
  date: {
    marginLeft: 15,
    fontSize: 13,
    marginTop: 5,
    marginBottom: 20,
    fontStyle: 'italic',
    color: COLOR.THEME.LIGHT_GRAY
  },
  saperator: {
    height: 0.5,
    alignSelf: 'center',
    width: CONSTANT.SCREEN_WIDTH - 30,
    backgroundColor: COLOR.THEME.TRACK_COLOR_FALSE
  },
  dataCellContainer: {
    width: '30%',
    height: 25,
    marginLeft: 15,
    marginTop: 15
  },
  dataContainer: {
    flexDirection: 'row'
  },
  colorBox: {
    height: 12,
    width: 12,
    alignSelf: "center",
  },
  colorText: {
    fontSize: 15,
    fontWeight: 'bold',
    alignSelf: "center",
    marginLeft: 10,
  },
  rowContainer: {
    height: 60,
    width: '100%',
    justifyContent: "center",
    alignItems: "center",
    flexDirection: 'row'
  },
  headerTextIndex: {
    fontFamily: FONT.ROBOTO,
    width: '10%',
    color: "#8D8E90"
  },
  headerTextData: {
    fontFamily: FONT.ROBOTO,
    width: '20%',
    fontWeight: "bold",
    color: "#8D8E90"
  },
  textIndex: {
    fontFamily: FONT.ROBOTO,
    width: '10%',
  },
  textData: {
    fontFamily: FONT.ROBOTO,
    width: '20%',
  },
  rowSaperator: {
    height: 0.5,
    width: CONSTANT.SCREEN_WIDTH - 30,
    backgroundColor: "#CACACA",
    position: 'absolute',
    bottom: 0
  },
  headerContainer: {
    height: 60,
    backgroundColor: "#F2F2F2",
    width: '100%',
    justifyContent: "center",
    alignItems: "center",
    flexDirection: 'row'
  },
  flatlistStyle: {
    marginTop: 20
  },
  lineChart: {
    marginVertical: 8,
    borderRadius: 16,
  }
});
