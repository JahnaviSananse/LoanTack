import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  View,
  Dimensions,
  Text
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
// import { LineChart, Grid, YAxis } from 'react-native-svg-charts'
import { LineChart } from "react-native-chart-kit";

const data = [
  { color: "#4FB263", title: "Principal" }, { color: "#EB4949", title: "Interest" },
  { color: "#F4C427", title: "Balance" }, { color: "#FF9060", title: "Taxes/Fees" }]

const tableData = [
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
]
const chartData = {
  labels: [
    'Text',
    'Text',
    'Text',
  ],
  datasets: [
    {
      data: [90, 45, 28],
      strokeWidth: 3,
      color: (opacity = 1) => `#4FB263`,
    },
    {
      data: [10, 40, 23],
      strokeWidth: 3,
      color: (opacity = 1) => `#EB4949`,
    },
    {
      data: [5, 10, 60],
      strokeWidth: 3,
      color: (opacity = 1) => `#F4C427`,
    },
    {
      data: [30, 60, 30],
      strokeWidth: 3,
      color: (opacity = 1) => `#FF9060`,
    },
  ],
}
const Amortization = () => {
  const navigation = useNavigation()
  React.useEffect(() => {

  }, []);
  const renderTableRow = (item: any) => {
    return (
      <View style={styles.rowContainer}>
        <Text style={styles.textIndex}>{item.index}</Text>
        <Text style={styles.textData}>{item.tax}</Text>
        <Text style={styles.textData}>{item.interest}</Text>
        <Text style={styles.textData}>{item.principal}</Text>
        <Text style={styles.textData}>{item.balance}</Text>
        <View style={styles.rowSaperator} />
      </View>
    )
  }
  const renderHeader = () => {
    return (
      <View style={styles.headerContainer}>
        <Text style={styles.headerTextIndex}>#</Text>
        <Text style={styles.headerTextData}>Taxes/Fees</Text>
        <Text style={styles.headerTextData}>Interest</Text>
        <Text style={styles.headerTextData}>Principal</Text>
        <Text style={styles.headerTextData}>Balance</Text>
        <View style={styles.rowSaperator} />
      </View>
    )
  }
  const renderTable = () => {
    return (
      <FlatList
        scrollEnabled={true}
        data={tableData}
        style={styles.flatlistStyle}
        ListHeaderComponent={() => renderHeader()}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => renderTableRow(item)}
      />
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Amortization'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <LineChart
          data={chartData}
          width={Dimensions.get('window').width - 16}
          height={220}
          chartConfig={{
            backgroundColor: "white",
            backgroundGradientFrom: "white",
            backgroundGradientTo: "white",
            labelColor: (opacity = 1) => '#A3A3A3',
            decimalPlaces: 2,
            color: (opacity = 1) => `#A3A3A3`,
            propsForDots: {
              r: "5",
            },
          }}
          style={styles.lineChart}
        />
        <COMPONENT.ChartDetail data={data} column={3} />
        {renderTable()}
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default Amortization;
