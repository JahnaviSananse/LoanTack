import React from 'react';

import { View, SafeAreaView, Text, ScrollView, Alert } from 'react-native';
import * as COMPONENT from 'src/components'
import styles from './styles';
import * as IMAGES from 'src/assets/images'
import * as Router from 'src/routes/router'
import { useNavigation } from '@react-navigation/native';

const data = [
    {
        title: 'Original Loan Amount',
        signature: '$',
        amt: '7,500',
        value: 0.2
    },
    {
        title: 'Original Interest Rate',
        signature: '$',
        amt: '3,000',
        value: 0.5
    },
]
const data2 = [
    {
        title: 'New Loan Amount',
        signature: '$',
        amt: '7,500',
        value: 0.2
    },
    {
        title: 'New Interest Rate',
        signature: '$',
        amt: '3,000',
        value: 0.5
    },
]
const pickerdata = [
    { label: 'Football', value: 'football' },
    { label: 'Baseball', value: 'baseball' },
    { label: 'Hockey', value: 'hockey' },
]
const ShouldIRefinanceBO = () => {
    const [value, setValue] = React.useState(0.2)
    const [downPayment, setDP] = React.useState(0.5)
    const [InterestRate, setInterestRate] = React.useState(0.7)
    const [HOAValue, setHOAValue] = React.useState("")
    const [InsuranceValue, setInsuranceValue] = React.useState("")
    const [PropertyPercentage, setPropertyPercenatge] = React.useState("")
    const [PropertyAmount, setPropertyAmount] = React.useState("")
    const navigation = useNavigation()

    const renderPicker = () => {
        return (
            <COMPONENT.Picker
                data={pickerdata}
                onValueChange={(value: any) => {
                    console.log("Value==>", value);
                }}
                placeholder={{
                    label: 'Select',
                    value: null,
                    // color: 'black',
                }}

            />
        )
    }
    return (
        <SafeAreaView style={styles.container}>
            <COMPONENT.Header
                title='Should I Refinance?'
                rightImg={IMAGES.IC_HEADER_INFO}
                leftImg={IMAGES.IC_BACK}
                leftClick={() => Router.goBack()} />
            <ScrollView style={styles.scrollView}>
                <View style={styles.container}>
                    <View style={[styles.hzLine, { marginTop: 10 }]} />
                    <Text style={styles.boldTitle}>{'Your Original Loan'}</Text>
                    <View style={styles.hzLine} />
                    {
                        data.map((item, index) => {
                            let sliderValue = item.value;
                            if (index === 0) {
                                sliderValue = value;
                            } else if (index === 1) {
                                sliderValue = downPayment
                            } else {
                                sliderValue = InterestRate;
                            }
                            return (
                                <>
                                    <View style={styles.viewContainer}>
                                        <Text style={styles.text}>{item.title}</Text>
                                        <COMPONENT.PriceBox
                                            sign={item.signature}
                                            title={item.amt} />
                                    </View>
                                    <COMPONENT.Slider
                                        value={sliderValue}
                                        onValueChange={(value: any) => {
                                            if (index === 0) {
                                                setValue(value)
                                            } else if (index === 1) {
                                                setDP(value)
                                            } else {
                                                setInterestRate(value)
                                            }

                                        }} />
                                </>
                            )
                        })
                    }
                    <Text style={styles.title}>{'Origination Year'}</Text>
                    {renderPicker()}
                    <Text style={styles.title}>{'Original Term'}</Text>
                    {renderPicker()}
                    <View style={[styles.hzLine, { marginTop: 20 }]} />
                    <Text style={styles.boldTitle}>{'Your New Loan'}</Text>
                    <View style={styles.hzLine} />
                    <View style={{ marginVertical: 20 }}>

                        {
                            data2.map((item, index) => {
                                let sliderValue = item.value;
                                if (index === 0) {
                                    sliderValue = value;
                                } else if (index === 1) {
                                    sliderValue = downPayment
                                } else {
                                    sliderValue = InterestRate;
                                }
                                return (
                                    <>
                                        <View style={styles.viewContainer}>
                                            <Text style={styles.text}>{item.title}</Text>
                                            <COMPONENT.PriceBox
                                                sign={item.signature}
                                                title={item.amt} />
                                        </View>
                                        <COMPONENT.Slider
                                            value={sliderValue}
                                            onValueChange={(value: any) => {
                                                if (index === 0) {
                                                    setValue(value)
                                                } else if (index === 1) {
                                                    setDP(value)
                                                } else {
                                                    setInterestRate(value)
                                                }

                                            }} />
                                    </>
                                )
                            })
                        }
                        <Text style={styles.title}>{'Refinance Fees'}</Text>
                        <COMPONENT.SignatureTextInput
                            isLeft={true}
                            sign={'$'}
                            placeholder={'0.00'}
                            value={HOAValue}
                            onChangeText={(text: any) => {
                                setHOAValue(text)
                            }}
                            keyboardType={'default'}
                            customStyle={styles.textInputCustom}
                        />
                        <Text style={styles.title}>{'New Term'}</Text>
                        {renderPicker()}
                        <View style={styles.buttonContainer}>
                            <COMPONENT.Button
                                title={"CALCULATE"}
                                type={"fill"}
                                onPress={() => navigation.navigate("RefinanceResult")}
                            />
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default ShouldIRefinanceBO;
