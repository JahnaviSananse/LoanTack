import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
  ScrollView
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const data = [
  { color: "#4FB263", title: "$1,155.73", desc: "Total Savings" },
  { color: "#EB4949", title: "$66.67", desc: "New Payment" },
]

const description = "LoanTack helps you determine your monthly mortgage payment by estimating your total loan amount, mortgage term length, and interest rate. Accurate estimates rely on the user entering accurate FICO score, property taxes and applicable HOA fees. Any calculation results are estimates, not final loan amounts, and are not guaranteed."

const AffordabilityResult = () => {
  const navigation = useNavigation()
  React.useEffect(() => {
  }, [])

  const renderBlackBox = () => {
    return (
      <View style={styles.blackBoxContainer}>
        <View>
          <Text style={styles.purchasePriceText}>Refinancing could save you</Text>
          <Text style={styles.purchasePriceAmount}>$164.12 / Month</Text>
        </View>
      </View>
    )
  }
  const renderDesription = () => {
    return (
      <View style={styles.descContainer}>
        <Text style={styles.descText}>{description}</Text>
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Results'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView contentContainerStyle={styles.contentStyle}>
          {renderBlackBox()}
          <COMPONENT.ChartDetail data={data} column={2} />
          <View style={styles.buttonContainer}>
            <COMPONENT.Button
              title={"SAVE"}
              type={"fill"}
              onPress={() => { }}
            />
          </View>
        </ScrollView>
        {renderDesription()}
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default AffordabilityResult;

