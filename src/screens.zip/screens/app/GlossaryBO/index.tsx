import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const rows = [
  { title: 'Affidavit', isOpen: false, options: [{ title: "option1", isSelected: false }, { title: "option2", isSelected: false }, { title: "option3", isSelected: false }, { title: "option4", isSelected: false },] },
  { title: 'Amortization', isOpen: false, options: [{ title: "option1", isSelected: false }, { title: "option2", isSelected: false }] },
  { title: 'Realtor', isOpen: false, options: [{ title: "option1", isSelected: false }, { title: "option2", isSelected: false }] },
]

const LearningCenterBO = () => {
  const navigation = useNavigation()
  const [data, setData] = React.useState(rows);
  React.useEffect(() => {

  }, []);
  const renderCheckBox = (item: any, index: number, mainIndex: any) => {
    return (
      <View style={styles.checkBoxContainer}>
        <TouchableOpacity style={styles.checkBox} onPress={() => {
          let tempData = JSON.parse(JSON.stringify(data))
          let innnerAry = tempData[mainIndex].options
          innnerAry[index].isSelected = !innnerAry[index].isSelected
          setData(tempData)
        }}>
          <Image source={item.isSelected ? IMAGES.IC_CHECKBOX_SELECTED : IMAGES.IC_CHECKBOX} style={styles.checkBoxIcon} resizeMode={"contain"}></Image>
        </TouchableOpacity>
        <Text style={styles.checkBoxText}>{item.title}</Text>
      </View>
    )
  }

  const renderItem = (item: any, ind: number) => {
    return (
      <View style={styles.cell}>
        <TouchableOpacity style={styles.cellContainer} onPress={() => {
          let tempData = JSON.parse(JSON.stringify(data))
          tempData[ind].isOpen = !tempData[ind].isOpen
          setData(tempData)
        }}>
          <Text style={styles.title}>{item.title}</Text>
          <Image source={item.isOpen ? IMAGES.IC_UP_ARROW : IMAGES.IC_DOWN_ARROW} style={styles.arrow} resizeMode={'contain'} />
        </TouchableOpacity>
        {item.isOpen === true &&
          <View style={styles.flatlist}>
            <FlatList
              scrollEnabled={false}
              data={item.options}
              showsVerticalScrollIndicator={false}
              renderItem={({ item, index }) => renderCheckBox(item, index, ind)}
            />
          </View>
        }
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Glossary'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <FlatList
          scrollEnabled={true}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => renderItem(item, index)}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default LearningCenterBO;
