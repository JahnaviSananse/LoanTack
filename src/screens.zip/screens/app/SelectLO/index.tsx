import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  TextInput,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const SelectLO = () => {
  const navigation = useNavigation()
  const [search, setSearch] = React.useState('');

  const data = [
    { name: "Robert Baker", time: "3 mins ago" },
    { name: "Jack Smith", time: "42 mins ago" },
    { name: "Oliver Ross", time: "1 hour ago" },
    { name: "Ethan Fortin", time: "5 hours ago" },
    { name: "Mike Rudd", time: "1 day ago" }
  ]
  React.useEffect(() => {
  }, [])
  const renderItem = (item: any) => {
    return (
      <View>
        <TouchableOpacity onPress={() => {
          navigation.navigate('ChatLO', {
            name: item.name,
          });
        }}
          style={styles.cellContainer}>
          <Image source={IMAGES.IC_AVATAR} style={styles.avatar} />
          <Text style={styles.nameText}>{item.name}</Text>
        </TouchableOpacity>
        <View style={styles.separetor} />
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"New Message"}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <View style={styles.dataContainer}>
          <View style={styles.searchContainer}>
            <Image source={IMAGES.IC_SEARCH} style={styles.searchIcon} />
            <TextInput
              style={styles.textInput}
              value={search}
              placeholder={"Search"}
              onChangeText={text => setSearch(text)}
            />
          </View>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => renderItem(item)}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default SelectLO;

