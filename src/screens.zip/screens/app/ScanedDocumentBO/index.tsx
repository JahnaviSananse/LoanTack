import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  FlatList,
  Image
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const data = [
  { index: 1 },
  { index: 2 },
  { index: 2 },
]

const ScanDocumentBO = () => {
  const navigation = useNavigation()
  React.useEffect(() => {
  }, [])
  const renderItem = (item: any) => {
    return (
      <View style={styles.cellContainer}>
        <TouchableOpacity style={styles.deleteButton}>
          <Image source={IMAGES.IC_DELETE} style={styles.deleteIcon} resizeMode={'contain'} />
        </TouchableOpacity>
        <Image source={IMAGES.IC_DOCUMENT_IMAGE} style={styles.imagePlaceholder} resizeMode={'contain'} />
      </View >
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Scan Document'}
          leftClick={() => navigation.goBack()}
          leftImg={IMAGES.IC_BACK}
          rightImg={IMAGES.IC_HEADER_RIGHT}
        />
        <View style={styles.checkBoxContaier}>
          <TouchableOpacity style={styles.checkBox}>
          </TouchableOpacity>
          <Text style={styles.combineText}>Combine all images</Text>
        </View>
        <FlatList
          scrollEnabled={true}
          data={data}
          style={styles.flatlistStyle}
          showsVerticalScrollIndicator={false}
          numColumns={2}
          renderItem={({ item }) => renderItem(item)}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default ScanDocumentBO;

