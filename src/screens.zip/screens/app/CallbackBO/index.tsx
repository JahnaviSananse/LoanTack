import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  ScrollView,
  Image,
  TextInput,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import POPUP from './popup';
import { useNavigation } from '@react-navigation/native';

const ScanDocumentBO = () => {
  const navigation = useNavigation()
  const [phone, setPhone] = React.useState('');
  const [comment, setComment] = React.useState('');
  const [selectedSlot, setTimeslot] = React.useState('');
  const [displayPhone, setDisplayPhone] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);

  React.useEffect(() => {
  }, [])

  const closeAlert = () => [
    setShowAlert(false)
  ]
  const timeSlot = (slot: string) => [
    setTimeslot(slot)
  ]
  const renderPhoneNumber = () => {
    return (
      <COMPONENT.PhoneNumberInput
        maxLength={12}
        value={displayPhone}
        keyboardType={"number-pad"}
        title={'Cell Phone'}
        placeholder={'(xxx) xxx - xxxx'}
        onChangeText={(text: string) => {
          let phone = text.replace(/\D/g, '');
          const match = phone.match(/^(\d{1,3})(\d{0,3})(\d{0,4})$/);
          if (match) {
            phone = `${match[1]}${match[2] ? ' ' : ''}${match[2]}${match[3] ? '-' : ''}${match[3]}`;
          }
          setPhone(text)
          setDisplayPhone(phone)
        }}
      />
    )
  }
  const renderBestTimeToCall = () => {
    return (
      <View>
        <Text style={styles.placeholderText}>Best Time to Call</Text>
        <TouchableOpacity style={styles.timeContainer} onPress={() => setShowAlert(true)}>
          <Text
            style={[styles.slotText, { fontStyle: selectedSlot ? 'normal' : 'italic', color: selectedSlot ? "black" : '#8D8E90', }]}>
            {selectedSlot ? selectedSlot : "Select"}
          </Text>
          <Image source={IMAGES.IC_DROPDOWN} style={styles.imgDropdown} resizeMode={"contain"} />
        </TouchableOpacity>
      </View>
    )
  }
  const renderComment = () => {
    return (
      <View>
        <Text style={styles.placeholderText}>Comments</Text>
        <TextInput
          maxLength={200}
          style={[styles.textField, { fontStyle: comment.length > 0 ? "normal" : "italic" }]}
          underlineColorAndroid={'transparent'}
          multiline={true}
          numberOfLines={6}
          value={comment}
          placeholder={"Enter Here"}
          onChangeText={(text: string) => {
            setComment(text)
          }}
        />
      </View>
    )
  }
  const renderButton = () => {
    return (
      <View style={styles.buttonPadding} >
        <COMPONENT.Button
          title={"SEND"}
          type={"fill"}
          onPress={() => console.log("coming")}
        />
      </View >
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Callback Request'}
          leftImg={IMAGES.IC_BACK}
          rightImg={IMAGES.IC_HEADER_INFO}
        />
        <ScrollView contentContainerStyle={{ paddingBottom: 150 }}>
          {renderPhoneNumber()}
          {renderBestTimeToCall()}
          {renderComment()}
          {renderButton()}
          <POPUP visible={showAlert} closeAlert={() => closeAlert()} timeSlot={(slot: string) => timeSlot(slot)} />
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default ScanDocumentBO;

