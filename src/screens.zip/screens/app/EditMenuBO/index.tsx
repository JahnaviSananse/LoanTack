import React from 'react';
import {
  View,
  Dimensions,
  SafeAreaView,
  Image,
  Text,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import { DraggableGrid } from 'react-native-draggable-grid';
import styles from './styles';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { useNavigation } from '@react-navigation/native';
import { setTabbarTabs } from 'src/redux/actions/common'

interface IEditMenuBOProps {
  setTabbarTabs: Function;
  allTabs: any;
}

const EditMenuBO = (props: IEditMenuBOProps) => {
  const navigation = useNavigation()
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");
  const [data, setData] = React.useState([
    {
      name: 'Uploaded Documents', key: '0', grey: IMAGES.IC_DOCUMENT_GRAY, white: IMAGES.IC_DOCUMENT_WHITE, green: IMAGES.IC_DOCUMENT_GREEN
    },
    {
      name: 'Message', key: '1', grey: IMAGES.IC_MESSAGE_GRAY, white: IMAGES.IC_MESSAGE_WHITE, green: IMAGES.IC_MESSAGE_GREEN
    },
    { name: 'Notifications', key: '2', grey: IMAGES.IC_NOTIFICATION_GRAY, white: IMAGES.IC_NOTIFICATION_WHITE, green: IMAGES.IC_NOTIFICATION_GREEN },
    {
      name: 'Saved Calculations', key: '3', grey: IMAGES.IC_ACCOUNTING_GRAY, white: IMAGES.IC_ACCOUNTING_WHITE, green: IMAGES.IC_ACCOUNTING_GREEN
    },
    {
      name: 'Checklist', key: '4', grey: IMAGES.IC_CHECKLIST_GRAY, white: IMAGES.IC_CHECKLIST_WHITE, green: IMAGES.IC_CHECKLIST_GREEN
    },
    {
      name: 'Callback Request', key: '5', grey: IMAGES.IC_PHONE_GRAY, white: IMAGES.IC_PHONE_WHITE, green: IMAGES.IC_PHONE_GREEN
    },
    { name: '', key: '6', image: "" },
    { name: '', key: '7', image: "" },
    {
      name: 'Dashboard', key: '8', grey: IMAGES.IC_DASHBOARD_GRAY, white: IMAGES.IC_DASHBOARD_WHITE, green: IMAGES.IC_DASHBOARD_GREEN
    },
    {
      name: 'Calculator', key: '9', grey: IMAGES.IC_CALCULATOR_GRAY, white: IMAGES.IC_CALCULATOR_WHITE, green: IMAGES.IC_CALCULATOR_GREEN
    },
    {
      name: 'Scan', key: '10', grey: IMAGES.IC_SCAN_GRAY, white: IMAGES.IC_SCAN_WHITE, green: IMAGES.IC_SCAN_GREEN
    },
    {
      name: 'Guide', key: '11', grey: IMAGES.IC_GUIDE_GRAY, white: IMAGES.IC_GUIDE_WHITE, green: IMAGES.IC_GUIDE_GREEN
    },
  ]);
  React.useEffect(() => {
    if (props.allTabs.length > 0) {
      setData(props.allTabs)
    }
  }, [props.allTabs])
  const renderItem = (item: any, index: number) => {
    return (
      <View>
        {index > 7 ?
          <View style={styles.selected_item}
            key={item.key}>
            <Image source={item.white} style={styles.icon} resizeMode={'contain'} />
            <Text style={styles.item_selectedtext}>{item.name}</Text>
          </View>
          :
          <View style={styles.item}
            key={item.key}>
            <Image source={item.grey} style={styles.icon} resizeMode={'contain'} />
            <Text style={styles.item_text}>{item.name}</Text>
          </View>
        }
      </View>
    )
  }
  const validateOptions = () => {
    if (data[6].name === "" && data[7].name === "") {
      props.setTabbarTabs(data)
      setTimeout(() => {
        navigation.goBack()
      }, 100);
    } else {
      setShowAlert(true)
      setAlertMsg("Please make tabs in sequence")
    }
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={"Edit Menu"}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => validateOptions()}
      />
      <View style={styles.blackContainer}>
        <Text style={styles.mainLinks}>Main Links</Text>
      </View>
      <View style={styles.whiteContainer}>
        <Text style={styles.moreLinks}>More Links</Text>
      </View>
      <View style={styles.wrapper}>
        <DraggableGrid
          numColumns={4}
          renderItem={(item, index) => renderItem(item, index)}
          data={data}
          onDragRelease={(data) => {
            setData(data)
          }}
        />
      </View>
      <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
    </SafeAreaView>
  );
};

const mapStateToProps = (state: IReduxState) => (
  {
    allTabs: state.common.tabs
  });

export default connect(mapStateToProps, {
  setTabbarTabs
})(EditMenuBO);
