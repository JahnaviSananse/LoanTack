import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const SettingLO = () => {
  const navigation = useNavigation()
  const data = [
    { name: "Profile Settings", redirect: "ProfileLO" },
    { name: "Change Password", redirect: "ChangePasswordLO" },
    { name: "Notifications Settings", redirect: "NotificationSettingLO" },
    { name: "Log-out", redirect: "Login" },
  ]
  React.useEffect(() => {

  }, [])
  const renderItem = (item: any) => {
    return (
      <View>
        <TouchableOpacity onPress={() => {
          if (item.name === "Log-out") {
            navigation.reset({
              routes: [{
                name: item.redirect
              }],
            });
          } else {
            navigation.navigate(item.redirect);
          }
        }}
          style={styles.cellContainer}>
          <Text style={styles.nameText}>{item.name}</Text>
        </TouchableOpacity>
        <View style={styles.separetor} />
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"Settings"}
          rightImg={IMAGES.IC_NOTIFICATION}
          rightClick={() => navigation.navigate("NotificationLO")}
        />
        <View style={styles.flatlistContainer}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => renderItem(item)}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default SettingLO;

