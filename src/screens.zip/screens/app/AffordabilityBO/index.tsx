import React from 'react';

import { View, SafeAreaView, Text, ScrollView, Alert } from 'react-native';
import * as COMPONENT from 'src/components'
import styles from './styles';
import * as IMAGES from 'src/assets/images'
import * as Router from 'src/routes/router'
import { useNavigation } from '@react-navigation/native';

const data = [
    {
        title: 'Annual Gross Income',
        signature: '$',
        amt: '50,000',
        value: 0.2
    },
    {
        title: 'Monthly Debts',
        signature: '$',
        amt: '7,500',
        value: 0.5
    },
    {
        title: 'Down Payment',
        signature: '$',
        amt: '7,500',
        value: 0.7
    },
    {
        title: 'Interest Rate',
        signature: '%',
        amt: '3.000',
        value: 0.7
    },
]
const pickerdata = [
    { label: 'Football', value: 'football' },
    { label: 'Baseball', value: 'baseball' },
    { label: 'Hockey', value: 'hockey' },
]
const AffordabilityBO = () => {
    const [value, setValue] = React.useState(0.2)
    const [downPayment, setDP] = React.useState(0.5)
    const [InterestRate, setInterestRate] = React.useState(0.7)
    const [HOAValue, setHOAValue] = React.useState("")
    const [InsuranceValue, setInsuranceValue] = React.useState("")
    const [PropertyPercentage, setPropertyPercenatge] = React.useState("")
    const [PropertyAmount, setPropertyAmount] = React.useState("")
    const navigation = useNavigation()

    const renderPicker = () => {
        return (
            <COMPONENT.Picker
                data={pickerdata}
                onValueChange={(value: any) => {
                    console.log("Value==>", value);
                }}
                placeholder={{
                    label: 'Select',
                    value: null,
                    // color: 'black',
                }}

            />
        )
    }
    return (
        <SafeAreaView style={styles.container}>
            <COMPONENT.Header
                title='Affordability'
                rightImg={IMAGES.IC_HEADER_INFO}
                leftImg={IMAGES.IC_BACK}
                leftClick={() => Router.goBack()} />
            <ScrollView style={styles.scrollView}>
                <View style={styles.container}>
                    {
                        data.map((item, index) => {
                            let sliderValue = item.value;
                            if (index === 0) {
                                sliderValue = value;
                            } else if (index === 1) {
                                sliderValue = downPayment
                            } else {
                                sliderValue = InterestRate;
                            }
                            return (
                                <>
                                    <View style={styles.viewContainer}>
                                        <Text style={styles.text}>{item.title}</Text>
                                        <COMPONENT.PriceBox
                                            sign={item.signature}
                                            title={item.amt} />
                                    </View>
                                    <COMPONENT.Slider
                                        value={sliderValue}
                                        onValueChange={(value: any) => {
                                            if (index === 0) {
                                                setValue(value)
                                            } else if (index === 1) {
                                                setDP(value)
                                            } else {
                                                setInterestRate(value)
                                            }

                                        }} />
                                </>
                            )
                        })
                    }
                    <View style={[styles.hzLine, { marginTop: 10 }]} />
                    <Text style={styles.boldTitle}>{'Advanced'}</Text>
                    <View style={styles.hzLine} />
                    <View style={{ marginVertical: 20 }}>
                        <Text style={styles.title}>{'Credit Score'}</Text>
                        {renderPicker()}
                        <Text style={styles.title}>{'Desired Term'}</Text>
                        {renderPicker()}
                        <Text style={styles.title}>{'Monthly HOA'}</Text>
                        <COMPONENT.SignatureTextInput
                            isLeft={true}
                            sign={'$'}
                            placeholder={'0.00'}
                            value={HOAValue}
                            onChangeText={(text: any) => {
                                setHOAValue(text)
                            }}
                            keyboardType={'default'}
                            customStyle={styles.textInputCustom}

                        />
                        <Text style={styles.title}>{'Annual Hazard Insurance'}</Text>
                        <COMPONENT.SignatureTextInput
                            isLeft={true}
                            sign={'$'}
                            placeholder={'0.00'}
                            value={InsuranceValue}
                            onChangeText={(text: any) => {
                                setInsuranceValue(text)
                            }}
                            keyboardType={'default'}
                            customStyle={styles.textInputCustom}

                        />
                        <Text style={styles.title}>{'Annual Property Tax'}</Text>
                        <View style={styles.taxMainContainer}>
                            <View style={styles.taxContainer}>
                                <COMPONENT.SignatureTextInput
                                    isLeft={false}
                                    sign={'%'}
                                    placeholder={'0.00'}
                                    value={PropertyPercentage}
                                    onChangeText={(text: any) => {
                                        setPropertyPercenatge(text)
                                    }}
                                    keyboardType={'default'}
                                    customStyle={styles.textInputCustom}

                                />
                            </View>
                            <View style={styles.taxContainer}>
                                <COMPONENT.SignatureTextInput
                                    isLeft={true}
                                    sign={'$'}
                                    placeholder={'0.00'}
                                    value={PropertyAmount}
                                    onChangeText={(text: any) => {
                                        setPropertyAmount(text)
                                    }}
                                    keyboardType={'default'}
                                    customStyle={styles.textInputCustom}

                                />
                            </View>


                        </View>

                        <Text style={styles.title}>{'State'}</Text>
                        {renderPicker()}
                        <Text style={styles.title}>{'County'}</Text>
                        {renderPicker()}
                        <View style={styles.buttonContainer}>
                            <COMPONENT.Button
                                title={"CALCULATE"}
                                type={"fill"}
                                onPress={() => navigation.navigate("AffordabilityResult")}
                            />
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default AffordabilityBO;
