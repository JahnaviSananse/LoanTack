import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  ScrollView,
  Image,
  TextInput,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const ScanDocumentBO = () => {
  const navigation = useNavigation()
  const [phone, setPhone] = React.useState('');
  const [name, setName] = React.useState('');
  const [displayPhone, setDisplayPhone] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");
  const [type, setType] = React.useState("failure");

  React.useEffect(() => {
  }, [])
  const validateForm = () => {
    let message = '';
    let isValidate = false;
    if (name.trim() === '') {
      message = 'Please enter name';
    } else if (phone.trim() === '') {
      message = 'Please enter phone';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      setShowAlert(true)
      setAlertMsg(message)
    } else {
      setType("success")
      setShowAlert(true)
      setAlertMsg("User detail updated")
      setTimeout(() => {
        setShowAlert(false)
        navigation.goBack()
      }, 500);
    }
  }
  const renderButton = () => {
    return (
      <View style={styles.buttonPadding} >
        <COMPONENT.Button
          title={"SAVE"}
          type={"fill"}
          onPress={() => validateForm()}
        />
        <COMPONENT.Button
          title={"CANCEL"}
          type={"unfill"}
          onPress={() => console.log("coming")}
        />
      </View >
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Callback Request'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <ScrollView contentContainerStyle={{ paddingBottom: 150 }}>
          <COMPONENT.TextField
            maxLength={50}
            value={name}
            keyboardType={"default"}
            title={'Name'}
            placeholder={'Enter Here'}
            secureTextEntry={false}
            style={styles.textField}
            onChangeText={(text: string) => {
              setName(text);
            }}
          />
          <COMPONENT.PhoneNumberInput
            maxLength={12}
            value={displayPhone}
            keyboardType={"number-pad"}
            title={'Cell Phone'}
            placeholder={'(xxx) xxx - xxxx'}
            onChangeText={(text: string) => {
              let phone = text.replace(/\D/g, '');
              const match = phone.match(/^(\d{1,3})(\d{0,3})(\d{0,4})$/);
              if (match) {
                phone = `${match[1]}${match[2] ? ' ' : ''}${match[2]}${match[3] ? '-' : ''}${match[3]}`;
              }
              setPhone(text)
              setDisplayPhone(phone)
            }}
          />
          {renderButton()}
          <COMPONENT.Popup desciption={alertMsg} type={type} visible={showAlert} closeAlert={() => closeAlert()} />
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default ScanDocumentBO;

