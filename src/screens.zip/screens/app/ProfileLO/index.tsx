import React from 'react';
import {
  TouchableOpacity,
  TextInput,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import * as utility from 'src/utility/util'
import { useNavigation } from '@react-navigation/native';
import ImagePicker from 'react-native-image-crop-picker';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const ProfileLO = () => {
  const navigation = useNavigation()
  const [bio, setBio] = React.useState("")
  const [profileImage, setProfileImage] = React.useState("")
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");

  React.useEffect(() => {

  }, [])
  const closeAlert = () => {
    setShowAlert(false)
  }

  const renderButtons = () => {
    return (
      <View style={styles.btnContainer}>
        <COMPONENT.Button
          title={"SAVE"}
          type={"fill"}
          onPress={() => {
            setShowAlert(true)
            setAlertMsg("Profile updated successfully")
            setTimeout(() => {
              setShowAlert(false)
              navigation.goBack()
            }, 1500);
          }}
        />
        <COMPONENT.Button
          title={"CANCEL"}
          type={"unfill"}
          onPress={() => navigation.goBack()}
        />
      </View>
    )
  }
  const chooseImage = () => {
    ImagePicker.openPicker({
      mediaType: 'photo',
      multiple: false
    }).then(images => {
      setProfileImage(images.path)
    })
  }
  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={"Profile Settings"}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <KeyboardAwareScrollView>
        <COMPONENT.Popup desciption={alertMsg} type={"success"} visible={showAlert} closeAlert={() => closeAlert()} />
        <View style={styles.profileContainer}>
          <Text style={styles.profileText}>Profile Photo</Text>
          <TouchableOpacity onPress={() => chooseImage()} style={styles.btnAddPic}>
            {profileImage === "" ?
              <Image source={IMAGES.IC_ADD} style={styles.add} resizeMode={"contain"} /> :
              <Image source={{ uri: profileImage }} style={styles.profileImage} resizeMode={"cover"} />
            }
          </TouchableOpacity>
          <View style={styles.bioContainer}>
            <Text style={styles.bioText}>Bio</Text>
            <TextInput
              maxLength={200}
              style={[styles.textField, { fontStyle: bio.length > 0 ? "normal" : "italic" }]}
              underlineColorAndroid={'transparent'}
              multiline={true}
              numberOfLines={6}
              value={bio}
              placeholder={"Enter Here"}
              onChangeText={(bio: string) => {
                setBio(bio)
              }}
            />
          </View>
        </View>
        {renderButtons()}
      </KeyboardAwareScrollView>
    </SafeAreaView >
  );
};

export default ProfileLO;

