import React from 'react';
import {
  View,
  SafeAreaView,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as utility from 'src/utility/util'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'



const ChangePasswordLO = () => {
  const navigation = useNavigation()
  const [currentPass, setCurrentPass] = React.useState("")
  const [newPass, setNewPass] = React.useState("")
  const [confirmPass, setConfirmPass] = React.useState("")
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");
  React.useEffect(() => {

  }, [])
  const validatePassword = () => {
    let message = '';
    let isValidate = false;
    if (currentPass.trim() === '') {
      message = 'Please enter current password';
    } else if (newPass.trim() === '') {
      message = 'Please enter new password';
    } else if (confirmPass.trim() === '') {
      message = 'Please enter confirm password';
    } else if (newPass.trim() !== confirmPass.trim()) {
      message = 'Password and confirm password must be same';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      setAlertMsg(message)
      setShowAlert(true)
    } else {
      setShowAlert(true)
      setAlertMsg("Password successfully changes")
      setTimeout(() => {
        setShowAlert(false)
        navigation.goBack()
      }, 1500);
    }
  }
  const renderButtons = () => {
    return (
      <View style={styles.btnContainer}>
        <COMPONENT.Button
          title={"SAVE"}
          type={"fill"}
          onPress={() => validatePassword()}
        />

        <COMPONENT.Button
          title={"CANCEL"}
          type={"unfill"}
          onPress={() => navigation.goBack()}
        />
      </View>
    )
  }
  const renderForm = () => {
    return (
      <View>
        <COMPONENT.TextField
          maxLength={15}
          value={currentPass}
          title={'Current Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setCurrentPass(password);
          }}
        />
        <COMPONENT.TextField
          maxLength={15}
          value={newPass}
          title={'New Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setNewPass(password);
          }}
        />
        <COMPONENT.TextField
          maxLength={15}
          value={confirmPass}
          title={'Confirm Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setConfirmPass(password);
          }}
        />
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <SafeAreaView style={styles.container}>

      <COMPONENT.Header
        title={"Change Password"}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
      <KeyboardAwareScrollView>
        <View>
          {renderForm()}
          {renderButtons()}
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default ChangePasswordLO;

