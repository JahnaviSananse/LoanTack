import { createStackNavigator } from '@react-navigation/stack';
import React from 'react';
import DashboardLO from 'src/screens/app/DashboardLO'
import NotificationLO from 'src/screens/app/NotificationLO'
import SelectLoanOfficerBO from 'src/screens/app/SelectLoanOfficerBO'
import DashboardBO from 'src/screens/app/DashboardBO'
import BioBO from 'src/screens/app/BioBO'

import AffordabilityResult from 'src/screens/app/AffordabilityResult'
import RefinanceResult from 'src/screens/app/RefinanceResult'
import ScanBO from 'src/screens/app/ScanBO'
import ScanStatusBO from 'src/screens/app/ScanStatusBO'

import Amortization from 'src/screens/app/Amortization'
import SavedCalculationBO from 'src/screens/app/SavedCalculationBO'
import ResultDetailBO from 'src/screens/app/ResultDetailBO'
import ResultBO from 'src/screens/app/ResultBO'

const Stack = createStackNavigator();

export const DashboardStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    {/* <Stack.Screen name="ScanStatusBO" component={ScanStatusBO} /> */}
    {/* <Stack.Screen name="ScanBO" component={ScanBO} /> */}
    {/* <Stack.Screen name="RefinanceResult" component={RefinanceResult} /> */}
    {/* <Stack.Screen name="AffordabilityResult" component={AffordabilityResult} /> */}

    {/* <Stack.Screen name="ResultBO" component={ResultBO} /> */}
    {/* <Stack.Screen name="Amortization" component={Amortization} /> */}
    {/* <Stack.Screen name="ResultDetailBO" component={ResultDetailBO} /> */}
    {/* <Stack.Screen name="SavedCalculationBO" component={SavedCalculationBO} /> */}

    {/* <Stack.Screen name="DashboardBO" component={DashboardBO} />
    <Stack.Screen name="BioBO" component={BioBO} /> */}

    <Stack.Screen name="DashboardLO" component={DashboardLO} />
    <Stack.Screen name="SelectLoanOfficerBO" component={SelectLoanOfficerBO} />
    <Stack.Screen name="NotificationLO" component={NotificationLO} />
  </Stack.Navigator>
);
