import React, { Component } from 'react';
import {
  ScrollView,
  KeyboardAvoidingView,
  Image,
  View,
  Text,
  SafeAreaView,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import * as utility from 'src/utility/util';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const ForgotPassword = () => {
  const navigation = useNavigation();
  const [email, setEmail] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");

  React.useEffect(() => { }, []);

  const handleProceed = () => {
    let message = '';
    let isValidate = false;
    if (email.trim() === '') {
      message = 'Please enter email';
    } else if (!utility.isValidEmail(email)) {
      message = 'Please enter valid email';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      setAlertMsg(message)
      setShowAlert(true)
    } else {
      navigation.navigate('VerificationCode');
    }
  };
  const renderForm = () => {
    return (
      <View style={styles.scrollView}>
        <COMPONENT.TextField
          maxLength={50}
          value={email}
          keyboardType={"email-address"}
          title={'Email Address'}
          placeholder={'abc@xyz.com'}
          secureTextEntry={false}
          style={styles.textField}
          onChangeText={(text: any) => {
            setEmail(text);
          }}
        />
      </View>
    )
  }
  const renderButtons = () => {
    return (
      <View style={styles.proceedContainer}>
        <COMPONENT.Button
          title={"PROCEED"}
          type={"fill"}
          onPress={() => handleProceed()}
        />
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={""}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
        <View style={styles.logoContainer}>
          <Image
            resizeMode={'contain'}
            source={IMAGES.IC_LOGO}
            style={styles.logo}
          />
          <View style={styles.forgotPassTextContainer}>
            <Text style={styles.forgotPassText}>Forgot Password</Text>
          </View>
        </View>
        {renderForm()}
        {renderButtons()}
      </KeyboardAwareScrollView>
      <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
    </SafeAreaView>
  );
};

export default ForgotPassword;
