import React from 'react';
import {
  TouchableOpacity,
  SafeAreaView,
  Image,
  View,
  Text,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import * as utility from 'src/utility/util';
import { useNavigation } from '@react-navigation/native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const Signup = () => {
  const navigation = useNavigation();
  const [name, setName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const [phone, setPhone] = React.useState('');
  const [displayPhone, setDisplayPhone] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");



  React.useEffect(() => {

  }, [phone]);

  const handleSignup = () => {
    let message = '';
    let isValidate = false;
    if (name.trim() === '') {
      message = 'Please enter name';
    } else if (email.trim() === '') {
      message = 'Please enter email';
    } else if (!utility.isValidEmail(email)) {
      message = 'Please enter a valid email address';
    } else if (password.trim() === '') {
      message = 'Please enter password';
    } else if (confirmPassword.trim() === '') {
      message = 'Please enter confirm password';
    } else if (password.trim() !== confirmPassword.trim()) {
      message = 'Password and confirm password must be same';
    } else if (phone.trim() === '') {
      message = 'Please enter cell phone';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      setAlertMsg(message)
      setShowAlert(true)
    } else {
      setAlertMsg("Signup Successful")
      setShowAlert(true)
      setTimeout(() => {
        navigation.navigate("Login")
      }, 1500);
    }
  };

  const renderform = () => {
    return (
      <View style={styles.scrollView}>
        <COMPONENT.TextField
          maxLength={50}
          value={name}
          title={'Name'}
          placeholder={'Enter Here'}
          secureTextEntry={false}
          style={styles.textField}
          onChangeText={(name: string) => {
            setName(name);
          }}
        />
        <COMPONENT.TextField
          maxLength={50}
          value={email}
          keyboardType={"email-address"}
          title={'Email Address'}
          placeholder={'abc@xyz.com'}
          secureTextEntry={false}
          style={styles.textField}
          onChangeText={(email: string) => {
            setEmail(email);
          }}
        />
        <COMPONENT.TextField
          maxLength={15}
          value={password}
          title={'Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setPassword(password);
          }}
        />
        <COMPONENT.TextField
          maxLength={15}
          value={confirmPassword}
          title={'Confirm Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setConfirmPassword(password);
          }}
        />
        <COMPONENT.PhoneNumberInput
          maxLength={12}
          value={displayPhone}
          keyboardType={"number-pad"}
          title={'Cell Phone'}
          placeholder={'(xxx) xxx - xxxx'}
          style={styles.textField}

          onChangeText={(text: string) => {
            let phone = text.replace(/\D/g, '');
            const match = phone.match(/^(\d{1,3})(\d{0,3})(\d{0,4})$/);
            if (match) {
              phone = `${match[1]}${match[2] ? ' ' : ''}${match[2]}${match[3] ? '-' : ''}${match[3]}`;
            }
            setPhone(text)
            setDisplayPhone(phone)
          }}
        />
      </View>
    )
  }
  const renderButton = () => {
    return (
      <View style={styles.buttonContainer}>
        <COMPONENT.Button
          title={"SIGN UP"}
          type={"fill"}
          onPress={() => handleSignup()}
        />

        <View style={styles.signContainer}>
          <Text style={styles.signupExtraText}>Have an account?</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
            <Text style={styles.signupText}>Log In</Text>
          </TouchableOpacity>
        </View>
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={""}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
      <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
        <View style={styles.logoContainer}>
          <Image
            resizeMode={'contain'}
            source={IMAGES.IC_LOGO}
            style={styles.logo}
          />
          <View style={styles.loginTextContainer}>
            <Text style={styles.loginText}>Sign Up</Text>
          </View>
        </View>
        {renderform()}
        {renderButton()}
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default Signup;
