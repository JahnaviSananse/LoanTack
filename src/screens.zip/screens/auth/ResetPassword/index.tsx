import React from 'react';
import {
  ScrollView,
  KeyboardAvoidingView,
  Image,
  View,
  Text,
  SafeAreaView,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import * as utitliy from 'src/utility/util'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

const ResetPassword = () => {
  const navigation = useNavigation();
  const [password, setPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");

  React.useEffect(() => { }, []);

  const handleSave = () => {
    let message = '';
    let isValidate = false;
    if (password.trim() === '') {
      message = 'Please enter password';
    } else if (confirmPassword.trim() === '') {
      message = 'Please enter confirm password';
    } else if (password.trim() !== confirmPassword.trim()) {
      message = 'Password and confirm password must be same';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      setAlertMsg(message)
      setShowAlert(true)
    } else {
      navigation.reset({
        routes: [{
          name: 'Login',
        }],
      });
    }
  };
  const renderForm = () => {
    return (
      <View style={styles.scrollView}>
        <COMPONENT.TextField
          maxLength={50}
          value={password}
          secureTextEntry={true}
          title={'New Password'}
          placeholder={'Enter Here'}
          style={styles.textField}
          onChangeText={(password: string) => {
            setPassword(password);
          }}
        />
        <COMPONENT.TextField
          maxLength={50}
          value={confirmPassword}
          title={'Confirm Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setConfirmPassword(password);
          }}
        />
      </View>
    )
  };
  const renderButton = () => {
    return (
      <View style={styles.proceedContainer}>
        <COMPONENT.Button
          title={"SAVE"}
          type={"fill"}
          onPress={() => handleSave()}
        />
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    // <SafeAreaView style={styles.container}>
    //   <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
    // <COMPONENT.Header
    //   title={""}
    //   leftImg={IMAGES.IC_BACK}
    //   leftClick={() => navigation.goBack()}
    // />
    //     <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
    //     <View style={styles.logoContainer}>
    //       <Image
    //         resizeMode={'contain'}
    //         source={IMAGES.IC_LOGO}
    //         style={styles.logo}
    //       />
    //     </View>
    //     <View style={styles.forgotPassTextContainer}>
    //       <Text style={styles.forgotPassText}>Reset Password</Text>
    //     </View>
    // {renderForm()}
    // {renderButton()}
    //   </KeyboardAwareScrollView>
    // </SafeAreaView>
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={""}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
        <View style={styles.logoContainer}>
          <Image
            resizeMode={'contain'}
            source={IMAGES.IC_LOGO}
            style={styles.logo}
          />
          <View style={styles.forgotPassTextContainer}>
            <Text style={styles.forgotPassText}>Reset Password</Text>
          </View>
        </View>
        {renderForm()}
        {renderButton()}
      </KeyboardAwareScrollView>
      <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
    </SafeAreaView>
  );
};

export default ResetPassword;
