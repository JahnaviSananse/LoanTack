import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        height: '100%',
        width: '100%',
        backgroundColor: '#ececec',
        alignItems: 'center',
        justifyContent: 'center',
    },
    logoContainer: {
        height: "40%",
        width: '100%',
        top: 5,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute'
    },
    keyboardAware: { flex: 1 },
    logo: {
        height: 40,
        width: '100%',
    },
    splashContainer: {
        height: "100%",
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    splash: {
        height: '100%',
        width: '100%'
    }
});
export default styles