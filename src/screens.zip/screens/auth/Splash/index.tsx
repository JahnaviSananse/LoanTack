import React from 'react';
import {
    Image,
    View,
} from 'react-native';
import styles from './styles'
import * as IMAGES from 'src/assets/images'
import { useNavigation } from '@react-navigation/native';
import CodePush from 'react-native-code-push';

const Splash = () => {
    const navigation = useNavigation()
    const [restartAllowed, setRestartAllowed] = React.useState("");
    React.useEffect(() => {
        setTimeout(() => {
            navigation.navigate("WalkthroughBO")
        }, 2000);
        syncImmediate()
    }, [])

    const codePushStatusDidChange = (syncStatus) => {
        switch (syncStatus) {
            case CodePush.SyncStatus.CHECKING_FOR_UPDATE:
                console.log('Checking for update.');
                break;
            case CodePush.SyncStatus.DOWNLOADING_PACKAGE:
                console.log('Downloading package.');
                break;
            case CodePush.SyncStatus.AWAITING_USER_ACTION:
                console.log('Awaiting user action.');
                break;
            case CodePush.SyncStatus.INSTALLING_UPDATE:
                console.log('Installing update.');
                break;
            case CodePush.SyncStatus.UP_TO_DATE:
                console.log('App up to date.');
                break;
            case CodePush.SyncStatus.UPDATE_IGNORED:
                console.log('Update cancelled by user.');
                break;
            case CodePush.SyncStatus.UPDATE_INSTALLED:
                console.log('Update installed and will be applied on restart.');
                break;
            case CodePush.SyncStatus.UNKNOWN_ERROR:
                console.log('An unknown error occurred.');
                break;
        }
    }

    const codePushDownloadDidProgress = (progress) => {
        console.log("progress", progress)
    }

    const toggleAllowRestart = () => {
        setRestartAllowed(!restartAllowed)
    }

    const getUpdateMetadata = () => {
        CodePush.getUpdateMetadata(CodePush.UpdateState.RUNNING).then(
            (metadata: LocalPackage) => {
            },
            (error: any) => {

            }
        );
    }

    /** Update is downloaded silently, and applied on restart (recommended) */
    const sync = () => {
        CodePush.sync({},
            codePushStatusDidChange(),
            codePushDownloadDidProgress());
    }

    /** Update pops a confirmation dialog, and then immediately reboots the app */
    const syncImmediate = () => {
        CodePush.sync(
            { installMode: CodePush.InstallMode.IMMEDIATE, updateDialog: true },
            codePushStatusDidChange(),
            codePushDownloadDidProgress()
        );
    }
    return (
        <View style={styles.container}>
            <View style={styles.splashContainer} >
                <Image resizeMode={'stretch'} source={IMAGES.IC_SPLASH} style={styles.splash} />
            </View>
            <View style={styles.logoContainer}>
                <Image resizeMode={'contain'} source={IMAGES.IC_LOGO} style={styles.logo} />
            </View>
        </View>
    );
};

export default Splash;

