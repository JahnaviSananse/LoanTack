import React from 'react';
import {
  Image,
  View,
  Text,
  SafeAreaView,
  TouchableOpacity
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import * as utility from 'src/utility/util'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import {
  CodeField,
  Cursor,
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';

const VerificationCode = () => {
  const navigation = useNavigation()
  const CELL_COUNT = 6;
  const [enableMask, setEnableMask] = React.useState(true);
  const [value, setValue] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState("");

  const ref = useBlurOnFulfill({ value, cellCount: CELL_COUNT });
  const [props, getCellOnLayoutHandler] = useClearByFocusCell({
    value,
    setValue,
  });
  React.useEffect(() => {

  }, [])

  const handleProceed = () => {
    if (value.length !== 6) {
      setAlertMsg("Please enter code")
      setShowAlert(true)
    } else {
      navigation.navigate("ResetPassword")
    }
  }
  const handleResend = () => {

  }
  const renderCell = ({ index, symbol, isFocused }) => {
    let textChild = null;
    if (symbol) {
      textChild = enableMask ? '•' : symbol;
    } else if (isFocused) {
      textChild = <Cursor />;
    }
    return (
      <View>
        <Text
          key={index}
          style={[styles.cell, isFocused && styles.focusCell]}
          onLayout={getCellOnLayoutHandler(index)}>
          {textChild}
        </Text>
        {index !== 6 && <View style={styles.dash} />}
      </View>
    );
  };
  const renderCodeInput = () => {
    return (
      <View style={styles.scrollView}>
        <Text style={styles.placeholderText}>{"Enter Verification Code"}</Text>
        <CodeField
          ref={ref}
          {...props}
          value={value}
          onChangeText={setValue}
          cellCount={CELL_COUNT}
          keyboardType="number-pad"
          textContentType="oneTimeCode"
          renderCell={renderCell}
        />
      </View>
    )
  }
  const renderButton = () => {
    return (
      <View style={styles.buttonsContainer}>
        <COMPONENT.Button
          title={"PROCEED"}
          type={"fill"}
          onPress={() => handleProceed()}
        />
        <TouchableOpacity
          style={styles.unfillButton}
          onPress={() => handleResend()}>
          <Text style={styles.unfillText}>{"RESEND CODE"}</Text>
        </TouchableOpacity >
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    // <SafeAreaView style={styles.container}>
    //   <COMPONENT.Header
    //     title={""}
    //     leftImg={IMAGES.IC_BACK}
    //     leftClick={() => navigation.goBack()}
    //   />
    //   <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
    //   <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
    //     <View style={styles.logoContainer}>
    //       <Image resizeMode={'contain'} source={IMAGES.IC_LOGO} style={styles.logo} />
    //     </View>
    //     <View style={styles.forgotPassTextContainer}>
    //       <Text style={styles.forgotPassText}>Verification Code</Text>
    //     </View>
    //     {renderCodeInput()}
    //     {renderButton()}
    //   </KeyboardAwareScrollView>
    // </SafeAreaView>
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={""}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
        <View style={styles.logoContainer}>
          <Image
            resizeMode={'contain'}
            source={IMAGES.IC_LOGO}
            style={styles.logo}
          />
          <View style={styles.forgotPassTextContainer}>
            <Text style={styles.forgotPassText}>Verification Code</Text>
          </View>
        </View>
        {renderCodeInput()}
        {renderButton()}
      </KeyboardAwareScrollView>
      <COMPONENT.Popup desciption={alertMsg} type={"failure"} visible={showAlert} closeAlert={() => closeAlert()} />
    </SafeAreaView>
  );
};

export default VerificationCode;

