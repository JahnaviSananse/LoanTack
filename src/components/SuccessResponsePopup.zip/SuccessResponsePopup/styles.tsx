import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        height: 44,
        backgroundColor: 'white',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10
    },
    popupView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 22,
    },
    modalOverlay: {
        height: '100%',
        width: '100%',
        backgroundColor: '#00000095',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContainer: {
        backgroundColor: 'white',
        width: '70%',
        alignSelf: 'center',
        borderRadius: 14,
        paddingVertical: 30,
    },
    popupImage: {
        height: 50,
        width: 50,
        alignSelf: 'center',
        marginBottom: 15,
    },
    desc: {
        alignSelf: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: "center",
        paddingHorizontal: 20,
    },
});
export default styles; 