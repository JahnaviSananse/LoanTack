import React from 'react';
import { Modal, Text, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import * as IMAGES from 'src/assets/images';
import Image from 'src/components/Image';
import styles from './styles';
interface IPopupProps {
  modalVisible: boolean;
  closeModal: any;
}
const Popup = (props: IPopupProps) => {
  const { modalVisible ,closeModal } = props;

  return (
    <View style={styles.popupView}>
      <Modal
        animationType="none"
        transparent={true}
        visible={modalVisible}>
        <TouchableOpacity style={styles.modalOverlay} onPress={closeModal}>
          <View style={styles.modalContainer}>
            <Image
              source={IMAGES.IC_SUCCESS}
              style={styles.popupImage}
              resizeMode={'contain'}
            />
            <Text style={styles.desc}>{'Your response is posted successfully'}</Text>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
};

export default Popup;
