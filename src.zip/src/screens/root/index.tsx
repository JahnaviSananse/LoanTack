import React, {PureComponent} from 'react';
import {AsyncStorage} from 'react-native';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
import {App} from '../app/tabs/index';
import {Auth} from '../auth';
import * as COMPONENT from 'src/components';

interface IProps {
  access_token: any;
}
const Root = (props: IProps) => {
  console.disableYellowBox = true;

  React.useEffect(() => {});
  return (
    <>
      <COMPONENT.InfoPopup />

      <Auth />
    </>
  );
};
// export default Root;
const mapStateToProps = (state: IReduxState) => (
  console.log('Root ===>', state),
  {
    user_data: state.auth.user_data,
    access_token: state.auth.access_token,
    // access_token: "",
  }
);

// const mapDispatchToProps = (
//   dispatch: ThunkDispatch<AppState, {}, AnyAction>,
// ) => ({
//   changeOrientation: (isLandScape: boolean) =>
//     dispatch(changeOrientation(isLandScape)),
// });

export default connect(mapStateToProps)(Root);
