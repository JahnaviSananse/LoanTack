import { StyleSheet, Dimensions } from 'react-native';
import * as COLOR from 'src/constants/colors';
import * as CONSTANT from 'src/constants/constant'
const optionContainerWidth = CONSTANT.SCREEN_WIDTH - 80
const optionWidth = optionContainerWidth / 7

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLOR.THEME.WHITE,
    // backgroundColor: "#1F2428",
    flexDirection: "column",
  },
  openButton: {
    height: 15,
    width: '100%',
    backgroundColor: '#1F2428',
    // backgroundColor: 'red',
    borderTopRightRadius: 4,
    borderTopLeftRadius: 4,
  },
  closeButton: {
    height: 25,
    width: 100,
    position: "absolute",
    // backgroundColor: "red",
    justifyContent: 'center',
    alignItems: "center",
    top: 5,
    alignSelf: "center"
  },
  tabContainer: {
    height: 65,
    width: '100%',
    alignSelf: 'center',
    alignItems: "center",
    backgroundColor: "#1F2428",
    flexDirection: 'row'
  },
  hiddenSheet: {
    height: 85,
    borderTopRightRadius: 8,
    borderTopLeftRadius: 8
  },
  singalTab: {
    flex: 1,
  },
  tabIcon: {
    height: 25,
    width: 25,
    alignSelf: "center",
    // marginTop: 5
  },
  tabTitle: {
    marginTop: 10,
    alignSelf: "center",
    fontSize: 13,
    textAlign: "center",
    color: 'white'
  },
  extraOptions: {
    height: CONSTANT.SCREEN_WIDTH / 4,
    width: CONSTANT.SCREEN_WIDTH / 4,
    justifyContent: 'center',
    alignItems: 'center'
  },
  item_text: {
    fontSize: 13,
    marginTop: 10,
    textAlign: 'center',
    color: '#8D8E90',
  },
  icon: {
    height: 25,
    width: 25,
    marginTop: 10
  },
  bottomSheetContainer: {
    justifyContent: "center",
    alignItems: "center"
  },
  customStyle: {
    backgroundColor: 'white',
    alignItems: "center",
    marginBottom: CONSTANT.IS_IPHONEX ? 100 : 70,
    borderTopRightRadius: 4,
    borderTopLeftRadius: 4,
  },
  sheetOptions: {
    width: '100%'
  },
  sheetCloseIcon: {
    height: 15,
    width: 15,
    alignSelf: 'center'
  },
  sheetOptionContainer: {
    position: "absolute",
    // backgroundColor: 'red',
    justifyContent: "center",
    alignItems: "center",
    height: 25,
    width: 50,
    top: 5,
    right: 10
  },
  editText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#4FB263'
  },
  flatListStyles: {
    marginTop: 25
  }
});
export default styles