import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import {useNavigation, useRoute} from '@react-navigation/native';
import * as modalInfo from 'src/redux/types/modalDescription';

const rows = [
  {
    title: 'ID Verification',
    isOpen: false,
    options: [
      {title: 'Health Insurance', isSelected: false},
      {title: 'Passport', isSelected: false},
      {title: 'Work Visa', isSelected: false},
      {title: 'ID Verification', isSelected: false},
    ],
  },
  {
    title: 'Items Needed',
    isOpen: false,
    options: [
      {title: 'option1', isSelected: false},
      {title: 'option2', isSelected: false},
    ],
  },
  {
    title: 'Optional',
    isOpen: false,
    options: [
      {title: 'option1', isSelected: false},
      {title: 'option2', isSelected: false},
    ],
  },
];
const desc = 'You can maintain a checklist of necessary items in this section.';
const LearningCenterBO = () => {
  const navigation = useNavigation();
  const params = useRoute().params;
  const [showAlert, setShowAlert] = React.useState(false);
  const [data, setData] = React.useState(rows);
  React.useEffect(() => {}, []);
  const renderCheckBox = (item: any, index: number, mainIndex: any) => {
    return (
      <View style={styles.checkBoxContainer}>
        <TouchableOpacity
          style={styles.checkBox}
          onPress={() => {
            let tempData = JSON.parse(JSON.stringify(data));
            let innnerAry = tempData[mainIndex].options;
            innnerAry[index].isSelected = !innnerAry[index].isSelected;
            setData(tempData);
          }}>
          <Image
            source={
              item.isSelected ? IMAGES.IC_CHECKBOX_SELECTED : IMAGES.IC_CHECKBOX
            }
            style={styles.checkBoxIcon}
            resizeMode={'contain'}></Image>
        </TouchableOpacity>
        <Text style={styles.checkBoxText}>{item.title}</Text>
      </View>
    );
  };

  const renderItem = (item: any, ind: number) => {
    return (
      <View style={styles.cell}>
        <TouchableOpacity
          style={styles.cellContainer}
          onPress={() => {
            let tempData = JSON.parse(JSON.stringify(data));
            tempData[ind].isOpen = !tempData[ind].isOpen;
            setData(tempData);
          }}>
          <Text style={styles.title}>{item.title}</Text>
          <Image
            source={item.isOpen ? IMAGES.IC_UP_ARROW : IMAGES.IC_DOWN_ARROW}
            style={styles.arrow}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
        {item.isOpen === true && (
          <View style={styles.flatlist}>
            <FlatList
              scrollEnabled={false}
              data={item.options}
              showsVerticalScrollIndicator={false}
              renderItem={({item, index}) => renderCheckBox(item, index, ind)}
            />
          </View>
        )}
      </View>
    );
  };
  const closeAlert = () => {
    setShowAlert(false);
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Checklist'}
          leftImg={params !== undefined && IMAGES.IC_BACK}
          leftClick={() => params !== undefined && navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          rightOneClick={() => setShowAlert(true)}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
          popupInfo={{
            title: modalInfo.default.checklistTitle,
            description: modalInfo.default.checklistDescription,
          }}
        />
        <FlatList
          scrollEnabled={true}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({item, index}) => renderItem(item, index)}
        />
        <COMPONENT.InfoPopup
          title={'Checklist'}
          visible={showAlert}
          desciption={desc}
          closeAlert={() => closeAlert()}
        />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default LearningCenterBO;
