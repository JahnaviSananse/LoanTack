import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  View,
  ScrollView,
  Dimensions,
  Text
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import * as CONSTANT from 'src/constants/constant'
import { LineChart } from "react-native-chart-kit";

const data = [
  { color: "#F4C427", title: "Balance" },
  { color: "#4FB263", title: "Principal" },
  { color: "#EB4949", title: "Interest" },
  { color: "#FF9060", title: "Taxes/Fees" }]

const tableData = [
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
  { index: "1", tax: "$100", interest: "$500", principal: "$100", balance: "$99,900" },
  { index: "2", tax: "$100", interest: "$500", principal: "$100", balance: "$99,800" },
  { index: "3", tax: "$101", interest: "$499", principal: "$101", balance: "$99,700" },
]
const chartData = {
  labels: [
    'May 2020',
    'Jun 2020',
    'July 2020',
  ],
  datasets: [
    {
      data: [90, 45, 28],
      strokeWidth: 3,
      color: (opacity = 1) => `#4FB263`,
    },
    {
      data: [10, 40, 23],
      strokeWidth: 3,
      color: (opacity = 1) => `#EB4949`,
    },
    {
      data: [5, 10, 60],
      strokeWidth: 3,
      color: (opacity = 1) => `#F4C427`,
    },
    {
      data: [30, 60, 30],
      strokeWidth: 3,
      color: (opacity = 1) => `#FF9060`,
    },
  ],
}
let width = CONSTANT.SCREEN_WIDTH - 30
let optionWidth = width / 4

const Amortization = () => {
  const navigation = useNavigation()
  React.useEffect(() => {

  }, []);
  const renderTableRow = (item: any, index: number) => {
    return (
      <View style={styles.rowContainer}>
        <Text style={styles.textIndex}>{index + 1}</Text>
        <Text style={styles.textData}>{item.balance}</Text>
        <Text style={styles.textData}>{item.principal}</Text>
        <Text style={styles.textData}>{item.interest}</Text>
        <Text style={styles.textData}>{item.tax}</Text>
        <View style={styles.rowSaperator} />
      </View>
    )
  }
  const renderHeader = () => {
    return (
      <View style={styles.headerContainer}>
        <Text style={styles.headerTextIndex}>#</Text>
        <Text style={styles.headerTextData}>Balance</Text>
        <Text style={styles.headerTextData}>Principal</Text>
        <Text style={styles.headerTextData}>Interest</Text>
        <Text style={styles.headerTextData}>Taxes/Fees</Text>
        <View style={styles.rowSaperator} />
      </View>
    )
  }
  const renderTable = () => {
    return (
      <View style={styles.tableContainer}>
        {renderHeader()}
        <FlatList
          contentContainerStyle={styles.flatScroll}
          nestedScrollEnabled={true}
          scrollEnabled={true}
          data={tableData}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => renderTableRow(item, index)}
        />
      </View>
    )
  }
  const renderLegends = () => {
    return (
      <View style={styles.lagendContainer} >
        <FlatList
          scrollEnabled={false}
          data={data}
          showsVerticalScrollIndicator={false}
          numColumns={4}
          renderItem={({ item }) =>
            <View style={[styles.cellContainer, { width: optionWidth }]}>
              <View style={styles.colorContainer}>
                <View style={[styles.colorBoxLegend, { backgroundColor: item.color }]} />
                <Text style={[styles.cellAmount, { color: item.color }]}>{item.title}</Text>
              </View>
              {item.desc && <Text style={styles.cellDesc}>{item.desc}</Text>}
            </View>
          }
        />
      </View >
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Amortization'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <ScrollView
          contentContainerStyle={styles.scroll}
          stickyHeaderIndices={[1]}
          nestedScrollEnabled={true}
        >
          <View style={styles.firstComponent}>
            <LineChart
              data={chartData}
              width={CONSTANT.SCREEN_WIDTH + CONSTANT.SCREEN_WIDTH * 0.3}
              height={220}
              chartConfig={{
                backgroundColor: "white",
                backgroundGradientFrom: "white",
                backgroundGradientTo: "white",
                labelColor: (opacity = 1) => '#A3A3A3',
                decimalPlaces: 2,
                color: (opacity = 1) => `#A3A3A3`,
                propsForDots: {
                  r: "5",
                },
              }}
              style={styles.lineChart}
            />
            {renderLegends()}
          </View>
          <View style={styles.secComponent}>
            {renderTable()}
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default Amortization;
