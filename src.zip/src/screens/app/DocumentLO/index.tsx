import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';



const DocumentLO = () => {
  const navigation = useNavigation()

  const data = [
    { name: "Robert Baker", time: "3 mins ago" },
    { name: "Jack Smith", time: "42 mins ago" },
    { name: "Oliver Ross", time: "1 hour ago" },
    { name: "Ethan Fortin", time: "5 hours ago" },
    { name: "Mike Rudd", time: "1 day ago" }
  ]
  React.useEffect(() => {
  }, [])
  const renderItem = (item: any) => {
    return (
      <View>
        <TouchableOpacity onPress={() => {
          navigation.navigate('DocumentDetailLO', {
            name: item.name,
          });
        }}
          style={styles.cellContainer}>
          <Image source={IMAGES.IC_AVATAR} style={styles.avatar} />
          <Text style={styles.nameText}>{item.name}</Text>
          <Text style={styles.timeText}>{item.time}</Text>
        </TouchableOpacity>
        <View style={styles.separetor} />
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"Documents"}
          rightImg={IMAGES.IC_NOTIFICATION}
          rightClick={() => navigation.navigate("NotificationLO")}
        />
        <View style={styles.flatlistContainer}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => renderItem(item)}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default DocumentLO;

