import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
  ScrollView,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import {useNavigation} from '@react-navigation/native';
import Pie from 'react-native-pie';
import * as COLOR from 'src/constants/colors';
import ScrollableTabView, {
  ScrollableTabBar,
} from 'react-native-scrollable-tab-view';

const chartData = [
  {
    percentage: 10,
    color: '#F4C427',
  },
  {
    percentage: 20,
    color: '#4FB263',
  },
  {
    percentage: 50,
    color: '#3ACBE9',
  },
  {
    percentage: 20,
    color: '#EB4949',
  },
];
const data = [
  {color: '#4FB263', title: '$1,155.73', desc: 'Mortgage Payments '},
  {color: '#EB4949', title: '$66.67', desc: 'Debt Payments'},
  {color: '#F4C427', title: '$250.00', desc: 'Income Taxes'},
  {color: '#3ACBE9', title: '$228.24', desc: 'Remaining'},
];
const description =
  'When considering your monthly debts you should take into account obligations like student/auto loans, credit cards, alimony and child support to name a few.';

const AffordabilityResult = () => {
  const navigation = useNavigation();
  React.useEffect(() => {}, []);

  const renderPie = () => {
    return (
      <View style={styles.chartContainer}>
        <Pie radius={80} sections={chartData} strokeCap={'butt'} />
      </View>
    );
  };
  const renderBlackBox = () => {
    return (
      <View style={styles.blackBoxContainer}>
        <View>
          <Text style={styles.purchasePriceText}>Purchase Price</Text>
          <Text style={styles.purchasePriceAmount}>$1364.123</Text>
        </View>
      </View>
    );
  };
  const renderDesription = () => {
    return (
      <View style={styles.descContainer}>
        <Text style={styles.descText}>{description}</Text>
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Results'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <View style={styles.tabbarTopBorder} />
        <ScrollableTabView
          renderTabBar={() => <ScrollableTabBar />}
          style={styles.scrollableTabViewStyle}
          tabBarTextStyle={styles.tabbarTextStyle}
          tabBarInactiveTextColor={COLOR.THEME.LIGHT_GRAY}
          tabBarActiveTextColor={COLOR.THEME.TRACK_COLOR_TRUE}
          tabBarUnderlineStyle={styles.tabbarUnderlineStyle}
          initialPage={1}>
          <View
            key={'1'}
            tabLabel={'Conservative'}
            style={styles.tabbarPageContainer}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.scrollViewContentStyle}>
              {renderPie()}
              <COMPONENT.ChartDetail data={data} column={2} />
              {renderBlackBox()}
            </ScrollView>
            {renderDesription()}
          </View>
          <View
            key={'2'}
            tabLabel={'Moderate'}
            style={styles.tabbarPageContainer}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.scrollViewContentStyle}>
              {renderPie()}
              <COMPONENT.ChartDetail data={data} column={2} />
              {renderBlackBox()}
            </ScrollView>
            {renderDesription()}
          </View>
          <View
            key={'3'}
            tabLabel={'Aggressive'}
            style={styles.tabbarPageContainer}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.scrollViewContentStyle}>
              {renderPie()}
              <COMPONENT.ChartDetail data={data} column={2} />
              {renderBlackBox()}
            </ScrollView>
            {renderDesription()}
          </View>
        </ScrollableTabView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default AffordabilityResult;
