import React from 'react';
import { View, Text, Image, TouchableOpacity, Linking } from 'react-native';
import styles from './styles';
import * as IMAGES from 'src/assets/images';
import { useNavigation } from '@react-navigation/native';

interface ICellProps {
  item?: any;
}

const cell = (props: ICellProps) => {
  const { item } = props;
  const navigation = useNavigation();

  return (
    <View style={styles.ofcContainer}>
      <View
        style={[
          styles.ofcSubContainer,
          { backgroundColor: item.role === 2 ? '#4FB263' : '#1F2428' },
        ]}>
        <View style={styles.detailConatainer}>
          <Text style={styles.ofcName}>{item.name}</Text>
          <Text style={styles.ofcDesignation}>{item.designation}</Text>
          <Text style={styles.ofcCode}>{"NMLS :" + item.licence}</Text>
        </View>
        <View style={styles.socialMargin}>
          <View style={styles.ofcSocialContaier}>
            <TouchableOpacity
              style={styles.ofcButton}
              // onPress={() => navigation.navigate('BioBO')}
              onPress={() =>
                item.social_links.website_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.website_link,
                })
              }>
              <Image
                source={item.role === 2 ? IMAGES.IC_WEBSITE : IMAGES.IC_BLACK_WEBSITE}
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
            <TouchableOpacity style={styles.ofcButton} onPress={() => Linking.openURL('mailto:' + item.email)}>
              <Image
                source={item.role === 2 ? IMAGES.IC_MAIL : IMAGES.IC_BLACK_MAIL}
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.ofcButton}
              onPress={() =>
                item.social_links.facebook_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.facebook_link,
                })
              }>
              <Image
                source={item.role === 2 ? IMAGES.IC_FACEBOOK : IMAGES.IC_BLACK_FB}
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.ofcButton}
              onPress={() =>
                item.social_links.twitter_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.twitter_link,
                })
              }>
              <Image
                source={item.role === 2 ? IMAGES.IC_TWITTER : IMAGES.IC_BLACK_TWITTER}
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.ofcMoreSocialContaier}>
            <TouchableOpacity
              style={styles.ofcButton}
              onPress={() =>
                item.social_links.linkedin_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.linkedin_link,
                })
              }>
              <Image
                source={
                  item.role === 2 ? IMAGES.IC_LINKEDIN : IMAGES.IC_BLACK_LINKEDIN
                }
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.ofcButton}
              onPress={() =>
                item.social_links.google_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.google_link,
                })
              }>
              <Image
                source={
                  item.role === 2 ? IMAGES.IC_GPLUS : IMAGES.IC_BLACK_GOOGLE_PLUS
                }
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.ofcButton}
              onPress={() =>
                item.social_links.youtube_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.youtube_link,
                })
              }>
              <Image
                source={item.role === 2 ? IMAGES.IC_YOUTUBE : IMAGES.IC_BLACK_YOUTUBE}
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.ofcButton}
              onPress={() =>
                item.social_links.pinterest_link != null &&
                navigation.navigate('Webview', {
                  url: item.social_links.pinterest_link,
                })
              }>
              <Image
                source={
                  item.role === 2 ? IMAGES.IC_PINTEREST : IMAGES.IC_BLACK_PINTREST
                }
                style={styles.ofcIcon}
                resizeMode={'contain'}
              />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <Image
        source={{ uri: item.profile_photo }}
        style={{
          height: 100,
          width: 100,
          marginLeft: 20,
          position: 'absolute',
          top: 0,
        }}
      />
    </View>
  );
};
export default cell;
