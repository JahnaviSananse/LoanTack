import React from 'react';
import {
  ScrollView,
  Image,
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation, useRoute } from '@react-navigation/native';
import HTML from "react-native-render-html";
import CELL from './cell';

const officerData = {
  title: 'Sollicitudin',
  detail:
    'Quis tristique vestibulum quisque convallis. Sed lacus, id erat sit at amet condimentum mauris mauris. Proin at sollicitudin molestie non quis tempor vestibulum ac. Nulla dignissim egestas iaculis sem mauris curabitur eget id euismod. Enim blandit nulla neque viverra ultrices. Sit tristique eu nec, purus mauris nisl morbi nunc. Eget parturient nulla ullamcorper ipsum viverra blandit sed. Sed sagittis, habitasse integer justo, turpis tincidunt dui at viverra. Etiam neque ut tempor malesuada. Consequat fames est mattis velit. Ac velit orci mi, eu facilisi at magna. ',
};
const renderDetail = (title: string, detail: string) => {
  return (
    <View style={styles.descContainer}>
      {/* <Text style={styles.officeTitle}>{title}</Text>
      <Text style={styles.officerDetail}>{detail}</Text> */}
      <View style={styles.htmlContainer}>
        <HTML html={title} />
        <HTML html={detail} />
      </View>
    </View>
  );
};
const BioBO = () => {
  const navigation = useNavigation();
  const params = useRoute().params;
  React.useEffect(() => {
  }, []);

  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Bio'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <ScrollView contentContainerStyle={styles.extraScroll}>
          <Image
            source={{ uri: params.item.logo }}
            resizeMode={'contain'}
            style={styles.logo}
          />
          <CELL item={params.item} />
          {renderDetail(params.item.bio)}
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default BioBO;
