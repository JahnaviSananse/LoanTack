import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation, useRoute } from '@react-navigation/native';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { toggleSettingOption } from 'src/redux/actions/common';
import * as modalInfo from 'src/redux/types/modalDescription';

const data = [
  {
    title: 'Learning Center',
    redirect: 'LearningCenterBO',
    image: IMAGES.IC_LEARNING_CENTER,
  },
  {
    title: 'Loan Programs',
    redirect: 'LoanProgramsBO',
    image: IMAGES.IC_LOAN_CENTER,
  },
  { title: 'Glossary', redirect: 'GlossaryBO', image: IMAGES.IC_GLOSSARY },
  {
    title: 'Checklists',
    redirect: 'ChecklistBO',
    image: IMAGES.IC_CHECKLIST,
    stack: 'ChecklistScreen',
  },
];

interface IGuideBOProps {
  toggleSettingOption: any;
  showOptions: boolean;
  updateInfoModal: Function;
}
const GuideBO = (props: IGuideBOProps) => {
  const navigation = useNavigation();
  const params = useRoute().params;
  React.useEffect(() => { }, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity
        style={styles.cellContainer}
        onPress={() => {
          if (item.stack) {
            navigation.navigate(item.stack, {
              screen: item.redirect,
              params: { isBack: true },
            });
          } else {
            navigation.navigate(item.redirect);
          }
        }}>
        <Image source={item.image} style={styles.icon} resizeMode={'contain'} />
        <Text style={styles.title}>{item.title}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Guide'}
          leftImg={params !== undefined ? IMAGES.IC_BACK : IMAGES.IC_HEADER_SETTING}
          leftClick={() => params !== undefined ? navigation.goBack() : props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          popupInfo={{
            title: modalInfo.default.guidedTitle,
            description: modalInfo.default.guidedDescription,
          }}
          rightOneClick={() => { }}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <FlatList
          scrollEnabled={false}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => renderItem(item)}
        />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions,
});

export default connect(mapStateToProps, {
  toggleSettingOption,
})(GuideBO);
