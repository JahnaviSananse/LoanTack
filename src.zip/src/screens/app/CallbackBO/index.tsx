import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  ScrollView,
  Image,
  TextInput,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import POPUP from './popup';
import { useNavigation, useRoute } from '@react-navigation/native';
import { OpenValidationAlert } from 'src/redux/actions/common';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
interface ICallBackProps {
  loading: boolean;
  OpenValidationAlert: Function;
}
const ScanDocumentBO = (props: ICallBackProps) => {
  const navigation = useNavigation();
  const params = useRoute().params;
  const [phone, setPhone] = React.useState('');
  const [comment, setComment] = React.useState('');
  const [selectedSlot, setTimeslot] = React.useState('');
  const [displayPhone, setDisplayPhone] = React.useState('');
  const [showSlotAlert, setShowSlotAlert] = React.useState(false);
  const [showAlert, setShowAlert] = React.useState(false);

  React.useEffect(() => { }, []);

  const closeAlert = () => {
    setShowAlert(false);
    setShowSlotAlert(false);
  };
  const timeSlot = (slot: string) => [setTimeslot(slot)];
  const validateForm = () => {
    let message = '';
    let isValidate = false;
    let type = 'failure';
    if (phone.trim() === '') {
      message = 'Please enter phone number';
    } else if (selectedSlot === '') {
      message = 'Please select time to call';
    } else if (comment.trim() === '') {
      message = 'Please enter comment';
    } else {
      isValidate = true;
      type = 'success';
      message = 'Your request has been sent';
    }

    if (!isValidate) {
      //setAlertType('failure');
      //setShowAlert(true);
      //setAlertMsg(message);
      let obj = {
        message: message,
        type: 'failure',
      };
      props.OpenValidationAlert(obj);
    } else {
      setPhone('');
      setComment('');
      setTimeslot('');
      setDisplayPhone('');
      //setAlertType('success');
      //setShowAlert(true);
      //setAlertMsg(message);
      let obj = {
        message: message,
        type: 'success',
      };
      props.OpenValidationAlert(obj);
    }
  };
  const renderPhoneNumber = () => {
    return (
      <COMPONENT.PhoneNumberInput
        maxLength={12}
        value={displayPhone}
        keyboardType={'number-pad'}
        title={'Cell Phone'}
        placeholder={'(xxx) xxx - xxxx'}
        onChangeText={(text: string) => {
          let phone = text.replace(/\D/g, '');
          const match = phone.match(/^(\d{1,3})(\d{0,3})(\d{0,4})$/);
          if (match) {
            phone = `${match[1]}${match[2] ? ' ' : ''}${match[2]}${
              match[3] ? '-' : ''
              }${match[3]}`;
          }
          setPhone(text);
          setDisplayPhone(phone);
        }}
      />
    );
  };
  const renderBestTimeToCall = () => {
    return (
      <View>
        <Text style={styles.placeholderText}>Best Time to Call</Text>
        <TouchableOpacity
          style={styles.timeContainer}
          onPress={() => setShowSlotAlert(true)}>
          <Text
            style={[
              styles.slotText,
              {
                fontStyle: selectedSlot ? 'normal' : 'italic',
                color: selectedSlot ? 'black' : '#8D8E90',
              },
            ]}>
            {selectedSlot ? selectedSlot : 'Select'}
          </Text>
          <Image
            source={IMAGES.IC_DROPDOWN}
            style={styles.imgDropdown}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
      </View>
    );
  };
  const renderComment = () => {
    return (
      <View>
        <Text style={styles.placeholderText}>Comments</Text>
        <TextInput
          maxLength={200}
          style={[
            styles.textField,
            { fontStyle: comment.length > 0 ? 'normal' : 'italic' },
          ]}
          underlineColorAndroid={'transparent'}
          multiline={true}
          numberOfLines={6}
          value={comment}
          placeholder={'Enter Here'}
          onChangeText={(text: string) => {
            setComment(text);
          }}
        />
      </View>
    );
  };
  const renderButton = () => {
    return (
      <View style={styles.buttonPadding}>
        <COMPONENT.Button
          title={'SEND'}
          type={'fill'}
          onPress={() => validateForm()}
        />
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Callback Request'}
          leftImg={params !== undefined && IMAGES.IC_BACK}
          leftClick={() => params !== undefined && navigation.goBack()}
          rightImg={IMAGES.IC_HEADER_INFO}
        />
        <ScrollView contentContainerStyle={{ paddingBottom: 150 }}>
          {renderPhoneNumber()}
          {renderBestTimeToCall()}
          {renderComment()}
          {renderButton()}
          <POPUP
            visible={showSlotAlert}
            closeAlert={() => closeAlert()}
            timeSlot={(slot: string) => timeSlot(slot)}
            value={selectedSlot}
          />
          <COMPONENT.Popup />
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  loading: state.auth.loading,
});
export default connect(mapStateToProps, {
  OpenValidationAlert,
})(ScanDocumentBO);
