import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import {useNavigation} from '@react-navigation/native';
import * as modalInfo from 'src/redux/types/modalDescription';

const data = [
  {title: 'FHA', redirect: 'FHAPurchaseBO'},
  {title: 'Conventional', redirect: 'ConventionalPurchaseBO'},
  {title: 'Jumbo', redirect: 'JumboPurchaseBO'},
  {title: 'USDA', redirect: 'USDAPurchaseBO'},
  {title: 'VA', redirect: 'VAPurchaseBO'},
];
const desc =
  'Browse loan programs to learn about your eligibility and the requirements for each. Read the minimum credit, debit, and down payment standard for each loan type to evaluate the best option for you.';
const LearningCenterBO = () => {
  const navigation = useNavigation();
  const [showAlert, setShowAlert] = React.useState(false);
  React.useEffect(() => {}, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity
        style={styles.cellContainer}
        //  onPress={() => navigation.navigate(item.redirect)}
      >
        <Text style={styles.title}>{item.title}</Text>
        <View style={styles.saperator} />
      </TouchableOpacity>
    );
  };
  const closeAlert = () => {
    setShowAlert(false);
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Loan Programs'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          rightOneClick={() => setShowAlert(true)}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
          popupInfo={{
            title: modalInfo.default.loanProgramTitle,
            description: modalInfo.default.loanProgramDescription,
          }}
        />
        <FlatList
          scrollEnabled={true}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({item}) => renderItem(item)}
        />
        <COMPONENT.InfoPopup
          title={'Loan Programs'}
          visible={showAlert}
          desciption={desc}
          closeAlert={() => closeAlert()}
        />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default LearningCenterBO;
