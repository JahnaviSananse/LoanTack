import React from 'react';
import { View, TextInput, AsyncStorage } from 'react-native';
import styles from './styles';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { WebView } from 'react-native-webview';
import { SafeAreaView, KeyboardAvoidingView } from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import * as CONSTANT from 'src/constants/constant'
import { useNavigation, useRoute } from '@react-navigation/native';


interface IWebviewProps {
  customLink: string;
}
const Webview = (props: IWebviewProps) => {
  const navigation = useNavigation();
  var params = useRoute().params;
  const [redirect, setRedirect] = React.useState('');
  React.useEffect(() => {
    if (props.customLink) {
      setRedirect(props.customLink)
    }
  }, [props.customLink]);

  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={''}
          leftImg={params.url && IMAGES.IC_BACK}
          leftClick={() => params.url && navigation.goBack()}
        />
        <WebView source={{ uri: params.url ? params.url : redirect }} scrollEnabled={true} />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  customLink: state.common.customLink
});

export default connect(mapStateToProps, {

})(Webview);
