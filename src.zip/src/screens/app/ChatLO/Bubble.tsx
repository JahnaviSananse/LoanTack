import React, { } from 'react';
import { View, Text, Image, TouchableOpacity, Dimensions, Linking } from 'react-native';
import styles from './styles';
import * as IMAGES from 'src/assets/images'

interface ICellProps {
    item?: any,
    showDate?: boolean
}
const getTime = (date: any) => {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}
const isUrl = (url: string) => {
    var strRegex = "^((https|Https|Http|http|ftp|rtsp|mms)?://)"
    // + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?" //ftp的user@
    // + "(([0-9]{1,3}\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
    // + "|" // 允许IP和DOMAIN（域名）
    // + "([0-9a-z_!~*'()-]+\.)*" // 域名- www.
    // + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\." // 二级域名
    // + "[a-z]{2,6})" // first level domain- .com or .museum
    // + "(:[0-9]{1,4})?" // 端口- :80
    // + "((/?)|" // a slash isn't required if there is no file name
    // + "(/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+/?)$";
    var re = new RegExp(strRegex);
    return re.test(url);
}

const Bubble = (props: ICellProps) => {
    const { item, showDate } = props;
    let textStyle = isUrl(item.text) ? styles.linkText : styles.normalText
    return (
        <View style={styles.cellContainer}>
            {showDate &&
                <View>
                    <View style={styles.dateSaperator} />
                    <Text style={styles.dateText}>Today</Text>
                </View>
            }
            {item.image &&
                <View style={item.user_id === 1 ? styles.imageRight : styles.imageLeft}>
                    <Image source={IMAGES.IC_ADD_IMAGE} style={styles.cellImage} resizeMode={'contain'} />
                    <Text style={styles.cellText}>{item.filename}</Text>
                    {item.user_id !== 1 &&
                        <TouchableOpacity style={styles.imageContanier}>
                            <Image source={IMAGES.IC_ATTACHEMENT_DOWNLOAD} style={styles.cellImage} resizeMode={'contain'} />
                        </TouchableOpacity>
                    }
                </View>}
            {item.pdf &&
                <View style={item.user_id === 1 ? styles.imageRight : styles.imageLeft}>
                    <Image source={IMAGES.IC_ATTACHEMENT_DOC} style={styles.cellImage} resizeMode={'contain'} />
                    <Text style={styles.cellText}>{item.filename}</Text>
                    {item.user_id !== 1 &&
                        <TouchableOpacity style={styles.imageContanier}>
                            <Image source={IMAGES.IC_ATTACHEMENT_DOWNLOAD} style={styles.cellImage} resizeMode={'contain'} />
                        </TouchableOpacity>
                    }
                </View>
            }
            {item.text &&
                <TouchableOpacity style={item.user_id === 1 ? styles.rightBubble : styles.leftBubble} onPress={() => Linking.openURL(item.text)}>
                    <Text style={textStyle}>{item.text}</Text>
                </TouchableOpacity>
            }
            <Text style={item.user_id === 1 ? styles.rightTime : styles.leftTime}>{getTime(item.createdAt)}</Text>
        </View>
    );
};
export default Bubble;

