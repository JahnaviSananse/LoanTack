import React from 'react';
import {
  KeyboardAvoidingView,
  SafeAreaView,
  ScrollView,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const data = "A volutpat neque augue dolor egestas fusce in. Velit sed facilisi vehicula vestibulum malesuada tellus, purus vestibulum, mauris. Facilisis viverra nec orci interdum metus. Et tellus leo enim imperdiet enim at. Gravida quis pulvinar tincidunt nisl nunc mauris. Vitae tellus in enim ultrices scelerisque et massa vestibulum, arcu. Sit elit, lectus sagittis facilisis elit cras tortor consectetur tellus. Nec, cras nulla lobortis ac sodales. Massa id aliquam a, tellus ipsum arcu praesent. Nunc vitae dui nisl est, id et praesent morbi. Eleifend vitae proin tortor vel massa nisi, facilisis consectetur enim. Interdum sed a cras habitant scelerisque. Fringilla suspendisse dictum quam eu egestas quis molestie arcu."
const DisclaimerBO = () => {
  const navigation = useNavigation()
  React.useEffect(() => {

  }, [])

  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"Privacy Policy"}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <ScrollView contentContainerStyle={{ paddingBottom: 200 }}>
          <Text style={styles.text}>{data}</Text>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default DisclaimerBO;

