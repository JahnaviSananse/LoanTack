import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation, useRoute } from '@react-navigation/native';

const DocumentDetailLO = () => {
  const navigation = useNavigation()
  const params = useRoute().params;

  const data = [
    { name: "Driving License ID", time: "May 10, 2020, 10:30PM" },
    { name: "Rental insurance", time: "May 10, 2020, 10:30PM" },
    { name: "Health insurance", time: "May 10, 2020, 10:30PM" },
  ]
  React.useEffect(() => {


  }, [])
  const renderItem = (item: any) => {
    return (
      <View style={styles.cellContainer}>
        <View style={styles.detailContainer}>
          <Text style={styles.nameText}>{item.name}</Text>
          <Text style={styles.timeText}>{item.time}</Text>
        </View>
        <View style={styles.downloadContainer}>
          <TouchableOpacity style={styles.btnDownload}>
            <Image source={IMAGES.IC_DOWNLOAD} style={styles.downloadIcon} resizeMode={"contain"} />
          </TouchableOpacity>
        </View>
        <View style={styles.separtor} />
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={params.name}
          rightImg={IMAGES.IC_NOTIFICATION}
          rightClick={() => navigation.navigate("NotificationLO")}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <View style={styles.flatlistContainer}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => renderItem(item)}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default DocumentDetailLO;

