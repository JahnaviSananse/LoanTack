import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  View,
  Image,
  Modal,
  Text,
  KeyboardAvoidingView,
  AsyncStorage,
  SafeAreaView,
  ScrollView,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import styles from './styles';
import CELL from './cell';
import { useNavigation } from '@react-navigation/native';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import HTML from "react-native-render-html";
import { toggleSettingOption } from 'src/redux/actions/common';
import { setScanRedirect } from 'src/redux/actions/common';
import * as CONSTANT from 'src/constants/constant';
import {
  getLOOfficers,
  getAssignedLO,
  assignLO,
  clearAssignData,
} from 'src/redux/actions/dashboard_bo';
import * as COMPONENT from 'src/components';

const menuArray = ["Dashboard", "Calculator", "Scan", "Guide", "Uploaded Documents", "Message", "Notifications", "Saved Calculations", "Checklist", "Callback Request"]
interface IDashboardLOProps {
  toggleSettingOption: any;
  showOptions: boolean;
  setScanRedirect: Function;
  userData: Object;
  getLOOfficers: Function;
  getAssignedLO: Function;
  clearAssignData: Function;
  assignedloData: any;
  loading: boolean;
  dashboardList: any;
}
const DashboardLO = (props: IDashboardLOProps) => {
  const navigation = useNavigation();
  const [isAvailable, setIsAvailable] = React.useState(null);
  const [openReadMore, setOpenReadMore] = React.useState(false);
  const [dashboardList, setDashboardList] = React.useState([]);
  const OfficerData = [
    {
      name: 'Robert Baker',
      designation: 'Branch Manager',
      code: 'NMLS : 236495',
      image: IMAGES.IC_DEMO_PROFILE,
      main: true,
    },
    {
      name: 'Roy Miller',
      designation: 'Branch Manager',
      code: 'NMLS : 236495',
      image: IMAGES.IC_LOAN_OFFICER,
      main: false,
    },
  ];
  const introData = {
    title: 'Welcome!',
    detail:
      'Proin at sollicitudin molestie non quis tempor vestibulum ac. Nulla dignissim egestas iaculis sem mauris curabitur eget id euismod. Enim blandit nulla...',
  };
  React.useEffect(() => {
    props.getAssignedLO();
  }, []);

  React.useEffect(() => {
    AsyncStorage.getItem(CONSTANT.USER_DATA).then((value) => {
      let data = JSON.parse(value);
      if (data.data.user.parent_id) {
        setIsAvailable(true);
      } else {
        setIsAvailable(false);
      }
    });
    if (isAvailable) {
      //props.getAssignedLO();
      console.log('AssignedLO_data', props.assignedloData);
    }
    if (props.dashboardList) {
      let filterData = Object.values(props.dashboardList).filter(fvalue => fvalue.name !== "Dashboard")
      filterData = filterData.filter(fvalue => fvalue.type !== 2) // remove this who custom links
      setDashboardList(filterData)
    }
  }, [props.getAssignedLO, props.assignedloData, isAvailable, props.dashboardList]);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity
        style={styles.cellContainer}
        onPress={() => {
          // console.log("item", item.link)
          if (menuArray.includes(item.name)) {
            redirectToScreen(item.name)
          } else {
            redirectToScreen(item.link)
          }
        }}>
        <Image
          source={{ uri: item.icon.green }}
          style={styles.cellImage}
          resizeMode={'contain'}
        />
        <Text style={styles.cellTitle}>{item.name}</Text>
      </TouchableOpacity>
    );
  };
  const redirectToScreen = (name: string) => {
    switch (name) {
      case 'Dashboard':
        navigation.navigate("DashboardBO");
        break;
      case 'Calculator':
        navigation.navigate("CalculatorScreen", {
          screen: "CalculatorBO",
          params: { isBack: true },
        });
        break;
      case 'Scan':
        props.setScanRedirect('ScanDocumentBO');
        navigation.navigate("ScanScreen", {
          screen: "ScanDocumentBO",
          params: { isBack: true },
        });
        break;
      case 'Guide':
        navigation.navigate("GuildScreen", {
          screen: "GuideBO",
          params: { isBack: true },
        });
        break;
      case 'Uploaded Documents':
        props.setScanRedirect('UploadedDocumentBO');
        navigation.navigate("UploadedDocumentScreen", {
          screen: "UploadedDocumentBO",
          params: { isBack: true },
        });
        break;
      case 'Message':
        navigation.navigate("MessageScreen", {
          screen: "ChatLO",
          params: { isBack: true },
        });
        break;
      case 'Notifications':
        navigation.navigate("NotificationScreen", {
          screen: "NotificationLO",
          params: { isBack: true },
        });
        break;
      case 'Saved Calculations':
        navigation.navigate("SavedCalculationScreen", {
          screen: "SavedCalculationBO",
          params: { isBack: true },
        });
        break;
      case 'Checklist':
        navigation.navigate("ChecklistScreen", {
          screen: "ChecklistBO",
          params: { isBack: true },
        });
        break;
      case 'Callback Request':
        navigation.navigate("CallbackScreen", {
          screen: "CallbackBO",
          params: { isBack: true },
        });
        break;
      default:
        navigation.navigate('Webview', {
          isBack: true,
          url: name,
        });
    }
  };
  const renderIntro = (detail: any) => {
    return (
      <View style={styles.introContainer}>
        <Text style={styles.introTitle}>{introData.title}</Text>
        <View style={styles.htmlContainer}>
          <HTML
            html={detail}
          />
        </View>
        <View style={styles.readmoreContainer}>
          <TouchableOpacity style={styles.readMoreButton} onPress={() => setOpenReadMore(true)}>
            <Text style={styles.readMoreText}>READ MORE</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };
  const readMorePopup = () => {
    return (
      <Modal
        animationType="none"
        transparent={true}
        visible={openReadMore}
        onRequestClose={() => {
          setOpenReadMore(false)
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.readmoremodalContainer}>
            <TouchableOpacity style={styles.closeButton} onPress={() => setOpenReadMore(false)}>
              <Image style={styles.image} resizeMode={"contain"} source={IMAGES.IC_CLOSE} />
            </TouchableOpacity>
            <ScrollView style={styles.htmlmodalContainer}>
              <HTML
                html={Object.entries(props.assignedloData).length
                  ? props.assignedloData.data.welcome_text
                  : ''}
              />
            </ScrollView>
          </View>
        </View>
      </Modal>
    )
  }
  const renderOfficer = () => {
    if (props.assignedloData === []) {
      //props.getAssignedLO();
    }
    let data = Object.entries(props.assignedloData).length
      ? [props.assignedloData.data]
      : [];
    return (
      <View>
        <FlatList
          scrollEnabled={false}
          data={data}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.containStyle}
          renderItem={({ item }) => <CELL item={item} />}
        />
      </View>
    );
  };
  const selectOfficer = () => {
    return (
      <View>
        <TouchableOpacity
          style={styles.selectOfficeContainer}
          onPress={() => {
            props.getLOOfficers();
            navigation.navigate('MessageScreen', {
              screen: 'SelectLO',
              params: { isBack: true },
            });
            props.clearAssignData();
          }}>
          <Text style={styles.loanOfficeText}>Select Loan Officer</Text>
        </TouchableOpacity>
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Dashboard'}
          leftImg={IMAGES.IC_HEADER_SETTING}
          leftClick={() => props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView>
          {isAvailable ? renderOfficer() : selectOfficer()}
          <View style={styles.optionContainer}>
            {renderIntro(
              Object.entries(props.assignedloData).length
                ? props.assignedloData.data.welcome_text
                : '',
            )}
            <FlatList
              scrollEnabled={false}
              data={dashboardList}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.containStyle}
              renderItem={({ item }) => renderItem(item)}
            />
          </View>
        </ScrollView>
        <COMPONENT.Loader isLoading={props.loading} />
        {readMorePopup()}
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions,
  userData: state.auth.userData,
  assignedloData: state.dashboard_bo.assignedloData,
  loading: state.dashboard_bo.loading,
  dashboardList: state.dashboard_bo.dashboardList
});

export default connect(mapStateToProps, {
  toggleSettingOption,
  setScanRedirect,
  getLOOfficers,
  getAssignedLO,
  clearAssignData,
})(DashboardLO);
