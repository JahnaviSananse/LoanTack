import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
  ScrollView
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import * as utility from 'src/utility/util';
import { useNavigation } from '@react-navigation/native';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { toggleSettingOption } from 'src/redux/actions/common'

interface IScanBOProps {
  toggleSettingOption: any;
  showOptions: boolean;
}
const ScanBO = (props: IScanBOProps) => {
  const navigation = useNavigation()
  const [email, setEmail] = React.useState('');
  React.useEffect(() => {
  }, [])
  const renderDetail = () => {
    return (
      <View style={styles.detailContainer}>
        <Text style={styles.title}>Email Verification Required</Text>
        <Text style={styles.desc}>In order to scan and submit documents you must first verify your email address. Please provide a valid email to continue.</Text>
      </View>
    )
  }

  const handleContinue = () => {
    let message = '';
    let isValidate = false;
    if (email.trim() === '') {
      message = 'Please enter email';
    } else if (!utility.isValidEmail(email.trim())) {
      message = 'Please enter valid email';
    } else {
      isValidate = true;
    }
    if (!isValidate) {
      // utility.showAlert('LoanTack', message);
      <COMPONENT.Popup desciption={message} type={"failure"} visible={true} />
    } else {
      navigation.navigate("ScanStatusBO")
    }
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Scan'}
          leftImg={IMAGES.IC_HEADER_SETTING}
          leftClick={() => props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView contentContainerStyle={styles.contentStyle}>
          {renderDetail()}
          <View style={styles.formContainer}>
            <COMPONENT.TextField
              maxLength={50}
              value={email}
              keyboardType={"email-address"}
              title={'Email Address'}
              placeholder={'abc@xyz.com'}
              secureTextEntry={false}
              onChangeText={(email: string) => {
                setEmail(email);
              }}
            />
            <COMPONENT.Button
              title={"CONTINUE"}
              type={"fill"}
              onPress={() => handleContinue()}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};
const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions
});

export default connect(mapStateToProps, {
  toggleSettingOption
})(ScanBO);


