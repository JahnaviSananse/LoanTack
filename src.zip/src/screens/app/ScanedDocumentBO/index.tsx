import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  FlatList,
  Image,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const ScanDocumentBO = () => {
  const navigation = useNavigation();
  const [isCombine, setCombine] = React.useState(false);
  const [data, setData] = React.useState([{ index: 0 }, { index: 1 }, { index: 2 }]);
  React.useEffect(() => { }, []);
  const renderItem = (item: any, index: number) => {
    return (
      <View style={styles.cellContainer}>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => {
            let tempAry = JSON.parse(JSON.stringify(data));
            tempAry.splice(index, 1);
            setData(tempAry);
          }}>
          <Image
            source={IMAGES.IC_DELETE}
            style={styles.deleteIcon}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
        <Image
          source={IMAGES.IC_DOCUMENT_IMAGE}
          style={styles.imagePlaceholder}
          resizeMode={'contain'}
        />
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'Scan Document'}
          leftClick={() => navigation.goBack()}
          leftImg={IMAGES.IC_BACK}
          rightImg={IMAGES.IC_HEADER_RIGHT}
          rightClick={() => {
            navigation.navigate('UploadedDocumentScreen', {
              screen: 'UploadedDocumentBO',
              params: { isBack: true },
            });
          }}
        />
        <TouchableOpacity
          onPress={() => {
            setCombine(!isCombine);
          }}
          style={[styles.checkBoxContaier]}>
          <TouchableOpacity disabled style={styles.checkBox}>
            {isCombine && (
              <Image
                style={{ width: 12, height: 12 }}
                resizeMode={'contain'}
                source={IMAGES.IC_HEADER_RIGHT}
              />
            )}
          </TouchableOpacity>
          <Text style={styles.combineText}>Combine all images</Text>
        </TouchableOpacity>
        <FlatList
          scrollEnabled={true}
          data={data}
          style={styles.flatlistStyle}
          showsVerticalScrollIndicator={false}
          numColumns={2}
          renderItem={({ item, index }) => renderItem(item, index)}
        />
        <TouchableOpacity
          onPress={() => navigation.navigate('ScanDocumentBO')}
          style={styles.FloatButton}>
          <Image source={IMAGES.IC_MESSAGE_ADD} style={styles.floatAdd} />
        </TouchableOpacity>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default ScanDocumentBO;
