import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
  Modal,
  ScrollView,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import {useNavigation} from '@react-navigation/native';
import {OpenValidationAlert} from 'src/redux/actions/common';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
const data = [
  {color: '#4FB263', title: '$1,155.73', desc: 'Total Savings'},
  {color: '#EB4949', title: '$66.67', desc: 'New Payment'},
];

const description =
  'LoanTack helps you determine your monthly mortgage payment by estimating your total loan amount, mortgage term length, and interest rate. Accurate estimates rely on the user entering accurate FICO score, property taxes and applicable HOA fees. Any calculation results are estimates, not final loan amounts, and are not guaranteed.';
interface IRResult {
  loading: boolean;
  OpenValidationAlert: Function;
}
const AffordabilityResult = (props: IRResult) => {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = React.useState(false);
  const [fileName, setFileName] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState('');
  React.useEffect(() => {}, []);

  const renderBlackBox = () => {
    return (
      <View style={styles.blackBoxContainer}>
        <View>
          <Text style={styles.purchasePriceText}>
            Refinancing could save you
          </Text>
          <Text style={styles.purchasePriceAmount}>$164.12 / Month</Text>
        </View>
      </View>
    );
  };
  const renderDesription = () => {
    return (
      <View style={styles.descContainer}>
        <Text style={styles.descText}>{description}</Text>
      </View>
    );
  };
  const validateName = () => {
    if (fileName.trim() === '') {
      //setAlertMsg('Please enter file name');
      //setShowAlert(true);
      let obj = {
        message: 'Please enter file name',
        type: 'failure',
      };
      props.OpenValidationAlert(obj);
    } else {
      setModalVisible(false);
      setTimeout(() => {
        setFileName('');
        navigation.navigate('SavedCalculationScreen', {
          screen: 'SavedCalculationBO',
          params: {isBack: true},
        });
      }, 500);
    }
  };
  const renderPopup = () => {
    return (
      <View style={styles.popupView}>
        <Modal
          animationType="none"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {}}>
          <View style={styles.modalOverlay}>
            <View style={styles.modalContainer}>
              <Text style={styles.alertTitle}>Save Calculation</Text>
              <COMPONENT.TextField
                maxLength={15}
                value={fileName}
                title={'Name'}
                placeholder={'Enter Here'}
                secureTextEntry={false}
                onChangeText={(name: string) => {
                  setFileName(name);
                }}
              />
              <View style={styles.alertbuttonsContainer}>
                <COMPONENT.Button
                  title={'SAVE'}
                  type={'fill'}
                  onPress={() => validateName()}
                />

                <COMPONENT.Button
                  title={'CANCEL'}
                  type={'unfill'}
                  onPress={() => setModalVisible(false)}
                />
              </View>
            </View>
          </View>
          <COMPONENT.Popup />
        </Modal>
      </View>
    );
  };
  const closeAlert = () => {
    setShowAlert(false);
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Results'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView contentContainerStyle={styles.contentStyle}>
          {renderBlackBox()}
          <COMPONENT.ChartDetail data={data} column={2} />
          <View style={styles.buttonContainer}>
            <COMPONENT.Button
              title={'SAVE'}
              type={'fill'}
              onPress={() => setModalVisible(true)}
            />
          </View>
        </ScrollView>
        {renderPopup()}
        {renderDesription()}
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  loading: state.auth.loading,
});
export default connect(mapStateToProps, {
  OpenValidationAlert,
})(AffordabilityResult);
