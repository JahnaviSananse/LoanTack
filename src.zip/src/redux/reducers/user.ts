import * as TYPE from '../types/user';

const initialState = {
  loading: false,
  profileData: [],
  borrowerProfileSuccess: false,
  passwordChangeMessage: '',
  passwordChangeSuccess: false,
  borrowerProfileMessage: '',
  LOProfileSuccess: false,
  LOProfileMessage: '',
  notificationData: [],
  getNotificationSuccess: false,
};
export default (
  state = initialState,
  action: IReduxAction,
): typeof initialState => {
  switch (action.type) {
    //get user profile
    case TYPE.GET_PROFILE_REQUEST: {
      return {
        ...state,
        loading: true,
      };
    }
    case TYPE.GET_PROFILE_SUCCESS: {
      return {
        ...state,
        loading: false,
        profileData: action.payload.data,
      };
    }
    case TYPE.GET_PROFILE_ERROR: {
      return {
        ...state,
        loading: false,
        profileData: [],
      };
    }
    //change password
    case TYPE.CHANGE_PASSWORD_REQUEST: {
      return {
        ...state,
        loading: true,
        passwordChangeMessage: '',
        passwordChangeSuccess: false,
      };
    }
    case TYPE.CHANGE_PASSWORD_SUCCESS: {
      setTimeout(() => {
        state.passwordChangeSuccess = false;
      }, 1000);
      return {
        ...state,
        loading: false,
        passwordChangeSuccess: true,
        passwordChangeMessage: '',
      };
    }
    case TYPE.CHANGE_PASSWORD_ERROR: {
      return {
        ...state,
        loading: false,
        passwordChangeMessage: action.payload,
        passwordChangeSuccess: false,
      };
    }
    case TYPE.CHANGE_PASSWORD_DATA_CLEAR: {
      return {
        ...state,
        loading: false,
        passwordChangeMessage: '',
        passwordChangeSuccess: false,
      };
    }

    //borrower profile update
    case TYPE.SAVE_BORROWER_PROFILE_REQUEST: {
      return {
        ...state,
        loading: true,
        borrowerProfileMessage: '',
        borrowerProfileSuccess: false,
      };
    }
    case TYPE.SAVE_BORROWER_PROFILE_SUCCESS: {
      return {
        ...state,
        loading: false,
        borrowerProfileSuccess: true,
        borrowerProfileMessage: '',
      };
    }
    case TYPE.SAVE_BORROWER_PROFILE_ERROR: {
      return {
        ...state,
        loading: false,
        borrowerProfileMessage: action.payload,
        borrowerProfileSuccess: false,
      };
    }
    case TYPE.BORROWER_PROFILE_DATA_CLEAR: {
      return {
        ...state,
        loading: false,
        borrowerProfileMessage: '',
        borrowerProfileSuccess: false,
      };
    }
    //LO profile update
    case TYPE.SAVE_LO_PROFILE_REQUEST: {
      return {
        ...state,
        loading: true,
        LOProfileSuccess: false,
        LOProfileMessage: '',
      };
    }
    case TYPE.SAVE_LO_PROFILE_SUCCESS: {
      return {
        ...state,
        loading: false,
        LOProfileSuccess: true,
        LOProfileMessage: '',
      };
    }
    case TYPE.SAVE_LO_PROFILE_ERROR: {
      return {
        ...state,
        loading: false,
        LOProfileMessage: action.payload,
        LOProfileSuccess: false,
      };
    }
    case TYPE.LO_PROFILE_DATA_CLEAR: {
      return {
        ...state,
        loading: false,
        LOProfileMessage: '',
        LOProfileSuccess: false,
      };
    }

    //get user notification
    case TYPE.GET_NOTIFICATION_SETTING_REQUEST: {
      return {
        ...state,
        loading: true,
        getNotificationSuccess: false,
      };
    }
    case TYPE.GET_NOTIFICATION_SETTING_SUCCESS: {
      return {
        ...state,
        loading: false,
        getNotificationSuccess: true,
        notificationData: action.payload,
      };
    }
    case TYPE.GET_NOTIFICATION_SETTING_ERROR: {
      return {
        ...state,
        loading: false,
        getNotificationSuccess: false,
      };
    }
    //save user notification
    case TYPE.SAVE_NOTIFICATION_SETTING_REQUEST: {
      return {
        ...state,
        loading: true,
        //getNotificationSuccess: false,
      };
    }
    case TYPE.SAVE_NOTIFICATION_SETTING_SUCCESS: {
      return {
        ...state,
        loading: false,
        //getNotificationSuccess: true,
        //notificationData: action.payload,
      };
    }
    case TYPE.SAVE_NOTIFICATION_SETTING_ERROR: {
      return {
        ...state,
        loading: false,
        //LOProfileMessage: action.payload.message,
        //getNotificationSuccess: false,
      };
    }
    default:
      return state;
  }
};
