import {Dispatch, AnyAction} from 'redux';
import {IReduxState} from '../reducers';
import * as TYPE from '../types/user';
import * as API from 'src/api/user';

const msg: string = 'Something went wrong!';

export const getUserProfile = (req: any) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  try {
    dispatch({type: TYPE.GET_PROFILE_REQUEST});
    const data = await API.getUserProfile();
    dispatch({
      type: TYPE.GET_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: TYPE.GET_PROFILE_ERROR,
      payload: error,
    });
  }
};

export const changePassword = (
  password: string,
  new_password: string,
) => async (dispatch: Dispatch, store: IReduxState) => {
  try {
    dispatch({type: TYPE.CHANGE_PASSWORD_REQUEST});
    const data = await API.changePassword({
      password,
      new_password,
    });
    dispatch({
      type: TYPE.CHANGE_PASSWORD_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: TYPE.CHANGE_PASSWORD_ERROR,
      payload: error,
    });
  }
};

export const clearChangePassword = () => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPE.CHANGE_PASSWORD_DATA_CLEAR,
  });
};

export const saveBorrowerProfile = (request: Object) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  try {
    dispatch({type: TYPE.SAVE_BORROWER_PROFILE_REQUEST});
    const data = await API.saveBorrowerProfile(request);
    dispatch({
      type: TYPE.SAVE_BORROWER_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: TYPE.SAVE_BORROWER_PROFILE_ERROR,
      payload: error,
    });
  }
};

export const clearBorrowerProfile = () => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPE.BORROWER_PROFILE_DATA_CLEAR,
  });
};

export const saveLOProfile = (profile_photo: any, bio: string) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  try {
    dispatch({type: TYPE.SAVE_LO_PROFILE_REQUEST});
    const data = await API.saveUserProfile({
      profile_photo,
      bio,
    });
    dispatch({
      type: TYPE.SAVE_LO_PROFILE_SUCCESS,
      payload: data,
    });
  } catch (error) {
    //console.log('ACTIONERROR', error);
    dispatch({
      type: TYPE.SAVE_LO_PROFILE_ERROR,
      payload: error,
    });
  }
};

export const clearLOProfile = () => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPE.LO_PROFILE_DATA_CLEAR,
  });
};

export const getNotificationSettings = (
  profile_photo: any,
  bio: string,
) => async (dispatch: Dispatch, store: IReduxState) => {
  try {
    dispatch({type: TYPE.GET_NOTIFICATION_SETTING_REQUEST});
    const data = await API.getNotification({
      profile_photo,
      bio,
    });
    dispatch({
      type: TYPE.GET_NOTIFICATION_SETTING_SUCCESS,
      payload: data.data.data,
    });
  } catch (error) {
    dispatch({
      type: TYPE.GET_NOTIFICATION_SETTING_ERROR,
      payload: error,
    });
  }
};

export const saveNotificationSettings = (
  direct_message: boolean,
  document_upload: boolean,
  app_download_from_link: boolean,
) => async (dispatch: Dispatch, store: IReduxState) => {
  try {
    dispatch({type: TYPE.SAVE_NOTIFICATION_SETTING_REQUEST});
    const data = await API.saveNotification({
      direct_message,
      document_upload,
      app_download_from_link,
    });
    dispatch({
      type: TYPE.SAVE_NOTIFICATION_SETTING_SUCCESS,
      payload: data,
    });
  } catch (error) {
    console.log('Error', error);
    dispatch({
      type: TYPE.SAVE_NOTIFICATION_SETTING_ERROR,
      payload: error,
    });
  }
};
