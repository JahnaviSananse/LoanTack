export default {
  API_URL: 'https://classicapi.jobfilez.com/api/',
  AUTH_URL: 'https://idp.jobfilez.com/',
  version: '1',
  nativeVersion: '1.0.1',
  env: 'dev',
};
