export default {
  API_URL: 'https://classicapi-qa.jobfilez.com/',
  AUTH_URL: 'https://idp-qa.jobfilez.com/',
  version: '1',
  nativeVersion: '1.0.1',
  env: 'production',
};
