export default {
  API_URL: 'http://139.59.65.130:5000/mob/api/v1',
};
