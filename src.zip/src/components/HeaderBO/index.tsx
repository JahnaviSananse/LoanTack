import React, { Component } from 'react';
import {
  View,
  Text,
  Image,
  Alert,
  Modal,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { logout_user } from 'src/redux/actions/auth';
import styles from './style';
import { useNavigation, useRoute } from '@react-navigation/native';
import { IReduxState } from 'src/redux/reducers';
import { connect } from 'react-redux';
import { toggleSettingOption } from 'src/redux/actions/common';
import { updateInfoModal } from 'src/redux/actions/modal';
import { IModalPopup } from 'src/redux/types/modal';

interface IHeaderProps {
  leftImg?: any;
  rightOneImg?: any;
  righTwoImg?: any;
  leftClick?: any;
  rightOneClick?: any;
  rightTwoClick?: any;
  title: string;
  showOptions: boolean;
  toggleSettingOption: any;
  popupInfo?: IModalPopup;
  updateInfoModal: Function;
  logout_user: Function;
}

const data = [
  { title: 'Settings', redirect: 'SettingBO', stack: 'settingScreen' },
  {
    title: 'Notifications',
    redirect: 'NotificationLO',
    stack: 'NotificationScreen',
  },
  { title: 'Log Out', redirect: 'Login' },
];
const HeaderBO = (props: IHeaderProps) => {
  const {
    leftImg,
    rightOneImg,
    rightTwoClick,
    righTwoImg,
    leftClick,
    rightOneClick,
    title,
    showOptions,
    toggleSettingOption,
  } = props;
  const navigation = useNavigation();
  let headerTitle = title ? title : '';

  const renderItem = (item: any) => {
    return (
      <TouchableOpacity
        style={styles.cell}
        onPress={() => {
          toggleSettingOption(!showOptions);
          setTimeout(() => {
            if (item.redirect !== 'Login') {
              navigation.navigate(item.stack, {
                screen: item.redirect,
                params: { isBack: true },
              });
            } else {
              LogoutAlert()
            }
          }, 100);
        }}>
        <Text style={styles.title}>{item.title}</Text>
        <View style={styles.saperator} />
      </TouchableOpacity>
    );
  };
  const LogoutAlert = () => {
    Alert.alert(
      'LoanTack',
      'Are you sure want to logout?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        { text: 'OK', onPress: () => props.logout_user() },
      ]
    )
  }
  const renderOptions = () => {
    return (
      <Modal
        animationType="none"
        transparent={true}
        visible={props.showOptions}
        onRequestClose={() => {
          toggleSettingOption(!showOptions);
        }}>
        <TouchableOpacity
          activeOpacity={1}
          onPress={() => toggleSettingOption(!showOptions)}
          style={styles.modalView}>
          <View style={styles.flatlistContainer}>
            <FlatList
              data={data}
              showsVerticalScrollIndicator={false}
              renderItem={({ item }) => renderItem(item)}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    );
  };
  return (
    <View>
      <View style={styles.container}>
        <TouchableOpacity style={styles.leftImgContainer} onPress={leftClick}>
          <Image
            source={leftImg}
            style={styles.img}
            resizeMode={'contain'}></Image>
        </TouchableOpacity>
        <Text style={styles.headerText}>{headerTitle}</Text>
        <TouchableOpacity
          style={styles.rightOneContainer}
          onPress={() => {
            // Show Popup
            if (props.popupInfo) {
              props.updateInfoModal(
                true,
                props.popupInfo.title,
                props.popupInfo.description,
              );
            } else if (props.rightOneClick) {
              props.rightOneClick();
            }
          }}>
          <Image
            source={rightOneImg}
            style={styles.rightImage}
            resizeMode={'contain'}></Image>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.rightTwoContainer}
          onPress={rightTwoClick}>
          <Image
            source={righTwoImg}
            style={styles.rightImage}
            resizeMode={'contain'}></Image>
        </TouchableOpacity>
        <Text style={styles.versionText}>1.17</Text>
      </View>
      {renderOptions()}
    </View>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions,
});

export default connect(mapStateToProps, {
  toggleSettingOption,
  updateInfoModal,
  logout_user
})(HeaderBO);
