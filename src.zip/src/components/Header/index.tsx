import React, {Component} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import styles from './style';
import {log} from 'react-native-reanimated';

interface IHeaderProps {
  leftImg?: any;
  rightImg?: any;
  leftClick?: any;
  rightClick?: any;
  title: string;
}
// This will help you to render custom navigation bar.
// Its defualt component for my structure. We can modify as per requirement
const Header = (props: IHeaderProps) => {
  const {leftImg, rightImg, leftClick, rightClick, title} = props;
  let headerTitle = title ? title : '';
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.leftImgContainer} onPress={leftClick}>
        <Image
          source={leftImg}
          style={styles.img}
          resizeMode={'contain'}></Image>
      </TouchableOpacity>
      <Text style={styles.headerText}>{headerTitle}</Text>
      <TouchableOpacity style={styles.leftImgContainer} onPress={rightClick}>
        <Image
          source={rightImg}
          style={styles.rightImage}
          resizeMode={'contain'}></Image>
      </TouchableOpacity>
    </View>
  );
};
export default Header;
