import { Alert } from 'react-native';
import DocumentPicker from 'react-native-document-picker';

export const showAlert = (title: string, message: string) => {
  Alert.alert(title === '' ? 'LoanTack' : title, message, [{ text: 'OK' }], {
    cancelable: false,
  });
};

export const isValidEmail = (email: string) => {
  const reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (reg.test(email) === true) {
    return true;
  }
  return false;
};

export const chooseDoc = async () => {
  try {
    const res = await DocumentPicker.pick({
      type: [DocumentPicker.types.pdf],
    });
    return res.uri
  } catch (err) {
    if (DocumentPicker.isCancel(err)) {
      // User cancelled the picker, exit any dialogs or menus and move on
    } else {
      throw err;
    }
  }
}