import * as TYPES from '../types/common';
import { Dispatch, AnyAction } from 'redux';
import { IReduxState } from '../reducers';

export const toggleSettingOption = (value: boolean) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPES.SET_SETTING_OPENS,
    payload: value,
  });
};
export const setScanRedirect = (value: string) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPES.SCAN_REDIRECT,
    payload: value,
  });
};
export const OpenValidationAlert = (request: Object) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPES.SHOW_VALIDATION_ALERT,
    payload: request,
  });
};
export const closeModal = (request: Object) => async (
  dispatch: Dispatch,
  store: IReduxState,
) => {
  dispatch({
    type: TYPES.CLOSE_VALIDATION_ALERT,
    payload: false,
  });
};

