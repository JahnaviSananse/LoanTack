// export * as Authntication from './auth';
import * as authActions from './auth';
import * as commonActions from './common';
import * as modalActions from './modal';

export const ActionCreators = {
  ...authActions,
  ...commonActions,
  ...modalActions,
};
