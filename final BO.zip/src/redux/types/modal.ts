export const UPDATE_INFO_MODAL = 'UPDATE_INFO_MODAL';
export interface IModalPopup {
  title: string;
  description: string;
}
