import {combineReducers} from 'redux';
import AuthReducer from './auth';
import CommonReducer from './common';
import ModalReducer from './modal';
import UserReducer from './user';
import Dashboard_boReducer from './dashboard_bo';

const reducers = {
  auth: AuthReducer,
  common: CommonReducer,
  modal: ModalReducer,
  user: UserReducer,
  dashboard_bo: Dashboard_boReducer,
};

const combinedReducer = combineReducers(reducers);

export interface IReduxState {
  auth: ReturnType<typeof AuthReducer>;
  common: ReturnType<typeof CommonReducer>;
  modal: ReturnType<typeof ModalReducer>;
  user: ReturnType<typeof UserReducer>;
  dashboard_bo: ReturnType<typeof Dashboard_boReducer>;
}

export default combinedReducer;
