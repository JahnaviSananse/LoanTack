import React from 'react';
import { Image, View, Text, SafeAreaView, TouchableOpacity } from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { resendCode, verifyCode, clearSignupData } from 'src/redux/actions/auth';
import { OpenValidationAlert, closeModal } from 'src/redux/actions/common';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { useNavigation, useRoute } from '@react-navigation/native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import {
  CodeField,
  Cursor,
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';
import * as Router from '../../../routes/router';

interface IVerifyProps {
  resendCode: Function;
  email: string;
  verifyError: string;
  verifyCode: Function;
  resendMessage: string;
  email_verified: boolean;
  OpenValidationAlert: Function;
  loading: boolean;
  signupData: any;
  closeModal: Function;
  clearSignupData: Function;
  verifyType: string;
  verifySuccess: any;
}
const VerificationCode = (prop: IVerifyProps) => {
  const navigation = useNavigation();
  const CELL_COUNT = 6;
  const params = useRoute().params;
  const [enableMask, setEnableMask] = React.useState(true);
  const [value, setValue] = React.useState('');
  const [type, setType] = React.useState('');
  const ref = useBlurOnFulfill({ value, cellCount: CELL_COUNT });
  const [props, getCellOnLayoutHandler] = useClearByFocusCell({
    value,
    setValue,
  });
  React.useEffect(() => {
    if (prop.signupData) {
      setTimeout(() => {
        setTimeout(() => {
          showAlert(prop.signupData.message, 'success');
        }, 500);
        prop.clearSignupData();
      }, 1500);
    }
    if (prop.email && prop.verifyType == 'VERIFY') {
      setTimeout(() => {
        showAlert('Email Verified Successfully', 'success');
        setTimeout(() => {
          prop.closeModal();
          Router.navigate('Login', {});
        }, 2000);
      }, 500);

      console.log('EmailVerified', prop.email, type);
    }
    if (prop.resendMessage) {
      setTimeout(() => {
        console.log('RES_MSG', prop.resendMessage);
        showAlert(prop.resendMessage, 'success');
      }, 500);
    }
    if (prop.verifyError) {
      setTimeout(() => {
        showAlert(prop.verifyError, 'failure');
      }, 500);
    }
    if (prop.verifySuccess) {
      let redirect = params.email ? 'ResetPassword' : 'Login';
      setTimeout(() => {
        let obj = {
          message: prop.verifySuccess,
          type: 'success',
          redirect: redirect,
        };
        prop.OpenValidationAlert(obj);
      }, 500);
    }
  }, [
    prop.signupData,
    prop.resendMessage,
    prop.email_verified,
    prop.verifyError,
    prop.email,
    prop.verifyType,
    prop.verifySuccess,
  ]);

  const showAlert = (message: string, type: string) => {
    let obj = {
      message: message,
      type: type,
    };
    prop.OpenValidationAlert(obj);
  };
  const handleProceed = () => {
    if (value.length !== 6) {
      showAlert('Please enter code', 'failure');
    } else {
      setType(prop.email ? 'VERIFY' : 'RESET');
      let email = prop.email ? prop.email : params.email;
      let type = prop.email ? 'VERIFY' : 'RESET';
      let obj = {
        email: email,
        code: parseInt(value),
        type: type,
      };
      prop.verifyCode(obj);
    }
  };
  const handleResend = () => {
    setType(prop.email ? 'VERIFY' : 'RESET');
    let email = prop.email ? prop.email : params.email;
    let type = prop.email ? 'VERIFY' : 'RESET';
    let obj = {
      email: email,
      type: type,
    };
    console.log('RESEND_REQ', obj);
    prop.resendCode(obj);
  };
  const renderCell = ({ index, symbol, isFocused }) => {
    let textChild = null;
    if (symbol) {
      textChild = enableMask ? '•' : symbol;
    } else if (isFocused) {
      textChild = <Cursor />;
    }
    return (
      <View>
        <Text
          key={index}
          style={[styles.cell, isFocused && styles.focusCell]}
          onLayout={getCellOnLayoutHandler(index)}>
          {textChild}
        </Text>
        {index !== 6 && <View style={styles.dash} />}
      </View>
    );
  };
  const renderCodeInput = () => {
    return (
      <View style={styles.scrollView}>
        <Text style={styles.placeholderText}>{'Enter Verification Code'}</Text>
        <CodeField
          ref={ref}
          {...props}
          value={value}
          onChangeText={setValue}
          cellCount={CELL_COUNT}
          keyboardType="number-pad"
          textContentType="oneTimeCode"
          renderCell={renderCell}
        />
      </View>
    );
  };
  const renderButton = () => {
    return (
      <View style={styles.buttonsContainer}>
        <COMPONENT.Button
          title={'PROCEED'}
          type={'fill'}
          onPress={() => handleProceed()}
        />
        <TouchableOpacity
          style={styles.unfillButton}
          onPress={() => handleResend()}>
          <Text style={styles.unfillText}>{'RESEND CODE'}</Text>
        </TouchableOpacity>
      </View>
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={''}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.goBack()}
      />
      <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
        <View style={styles.logoContainer}>
          <Image
            resizeMode={'contain'}
            source={IMAGES.IC_LOGO}
            style={styles.logo}
          />
          <View style={styles.forgotPassTextContainer}>
            <Text style={styles.forgotPassText}>Verification Code</Text>
          </View>
        </View>
        {renderCodeInput()}
        {renderButton()}

        <COMPONENT.Popup />
      </KeyboardAwareScrollView>
      <COMPONENT.Popup />
      <COMPONENT.Loader isLoading={prop.loading} />
    </SafeAreaView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  loading: state.auth.loading,
  resendMessage: state.auth.resendMessage,
  email: state.auth.email,
  email_verified: state.auth.email_verified,
  verifyError: state.auth.verifyError,
  signupData: state.auth.signupData,
  verifyType: state.auth.verifyType,
});

export default connect(mapStateToProps, {
  resendCode,
  verifyCode,
  OpenValidationAlert,
  closeModal,
  clearSignupData,
})(VerificationCode);
