import React from 'react';
import {
  Image,
  View,
  Modal,
  Dimensions,
  Text,
  AsyncStorage,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import styles from './styles';
import ProgressBarAnimated from 'react-native-progress-bar-animated';
import * as CONSTANT from 'src/constants/constant';
import {useNavigation} from '@react-navigation/native';
import RNRestart from 'react-native-restart';
import CodePush from 'react-native-code-push';
import {getMainList} from 'src/redux/actions/dashboard_bo';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';

const progressCustomStyles = {
  backgroundColor: '#F48020',
  borderColor: 'black',
};
interface ISplashProps {
  getMainList: Function;
}
const Splash = (props: ISplashProps) => {
  const navigation = useNavigation();
  const [progressWithOnComplete, setprogressWithOnComplete] = React.useState(0);
  const [modalVisible, setModalVisible] = React.useState(false);
  React.useEffect(() => {
    let data = AsyncStorage.getItem(CONSTANT.USER_DATA);
    let isFirstTime = AsyncStorage.getItem(CONSTANT.IS_FIRST_TIME);
    setTimeout(() => {
      if (data) {
        data.then(function (result) {
          if (result) {
            let response = JSON.parse(result);
            let role = response.data.user.role;
            let emailVerified = response.data.email_verified;
            if (emailVerified) {
              props.getMainList();
              let redirect = role === 2 ? 'LoanTackTabs' : 'LoanTackTabsBO';
              navigation.reset({
                routes: [{name: redirect}],
              });
            } else {
              navigation.reset({
                routes: [{name: 'Login'}],
              });
            }
          } else {
            if (isFirstTime) {
              isFirstTime.then(function (result) {
                if (result === null) {
                  navigation.reset({
                    routes: [{name: 'WalkthroughBO'}],
                  });
                } else {
                  navigation.reset({
                    routes: [{name: 'Login'}],
                  });
                }
              });
            } else {
              navigation.reset({
                routes: [{name: 'WalkthroughBO'}],
              });
            }
          }
        });
      } else {
        if (isFirstTime) {
          isFirstTime.then(function (result) {
            if (result) {
              navigation.reset({
                routes: [{name: 'Login'}],
              });
            }
          });
        } else {
          Alert.alert('WalkthroughBO');
          navigation.reset({
            routes: [{name: 'WalkthroughBO'}],
          });
        }
      }
    }, 2000);
    checkUpdate();
  }, []);

  const renderModal = () => {
    return (
      <Modal
        animationType="none"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(false);
        }}>
        <View style={styles.overlay}>
          <View style={styles.box}>
            <Text style={styles.downloadText}>Downloading</Text>
            <View style={styles.progressContainer}>
              <ProgressBarAnimated
                {...progressCustomStyles}
                width={Dimensions.get('screen').width * 0.8}
                value={progressWithOnComplete}
                onComplete={() => {
                  setModalVisible(false);
                }}
              />
            </View>
          </View>
        </View>
      </Modal>
    );
  };
  const checkUpdate = () => {
    CodePush.sync(
      {updateDialog: true},
      (status) => {
        switch (status) {
          case CodePush.SyncStatus.DOWNLOADING_PACKAGE:
            setModalVisible(true);
            break;
          case CodePush.SyncStatus.UPDATE_INSTALLED:
            RNRestart.Restart();
            break;
          case CodePush.SyncStatus.INSTALLING_UPDATE:
            break;
        }
      },
      ({receivedBytes, totalBytes}) => {
        let total = totalBytes;
        let received = receivedBytes;
        let percentage = (received / total) * 100;
        setprogressWithOnComplete(percentage);
      },
    );
  };
  return (
    <View style={styles.container}>
      <View style={styles.splashContainer}>
        <Image
          resizeMode={'stretch'}
          source={IMAGES.IC_SPLASH}
          style={styles.splash}
        />
      </View>
      <View style={styles.logoContainer}>
        <Image
          resizeMode={'contain'}
          source={IMAGES.IC_LOGO}
          style={styles.logo}
        />
      </View>
      {renderModal()}
    </View>
  );
};

const mapStateToProps = (state: IReduxState) => ({});

export default connect(mapStateToProps, {
  getMainList,
})(Splash);
