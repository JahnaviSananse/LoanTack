import React from 'react';
import {
  ScrollView,
  KeyboardAvoidingView,
  Image,
  View,
  Text,
  SafeAreaView,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import {resetPassword_user} from 'src/redux/actions/auth';
import styles from './styles';
import {useNavigation} from '@react-navigation/native';
import {OpenValidationAlert} from 'src/redux/actions/common';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

interface IResetProps {
  resetPassword_user: Function;
  email: string;
  OpenValidationAlert: Function;
  loading: boolean;
  resetPassError: string;
}
const ResetPassword = (props: IResetProps) => {
  const navigation = useNavigation();
  const [password, setPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');

  React.useEffect(() => {
    if (props.resetPassError && !props.loading) {
      setTimeout(() => {
        showAlert(props.resetPassError, 'failure');
      }, 500);
    }
  }, [props.resetPassError]);

  const handleSave = () => {
    let message = '';
    let isValidate = false;
    if (password.trim() === '') {
      message = 'Please enter password';
    } else if (confirmPassword.trim() === '') {
      message = 'Please enter confirm password';
    } else if (password.trim() !== confirmPassword.trim()) {
      message = 'Password and confirm password must be same';
    } else if (password.trim().length < 6) {
      message = 'Password must more then 6 characters';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      showAlert(message, 'failure');
    } else {
      let obj = {
        email: props.email,
        password: password,
      };
      props.resetPassword_user(obj);
    }
  };
  console.log('RPROP', props);
  const showAlert = (message: string, type: string) => {
    let obj = {
      message: message,
      type: type,
    };
    props.OpenValidationAlert(obj);
  };
  const renderForm = () => {
    return (
      <View style={styles.scrollView}>
        <COMPONENT.TextField
          maxLength={50}
          value={password}
          secureTextEntry={true}
          title={'New Password'}
          placeholder={'Enter Here'}
          style={styles.textField}
          onChangeText={(password: string) => {
            setPassword(password);
          }}
        />
        <COMPONENT.TextField
          maxLength={50}
          value={confirmPassword}
          title={'Confirm Password'}
          placeholder={'Enter Here'}
          secureTextEntry={true}
          style={styles.textField}
          onChangeText={(password: string) => {
            setConfirmPassword(password);
          }}
        />
      </View>
    );
  };
  const renderButton = () => {
    return (
      <View style={styles.proceedContainer}>
        <COMPONENT.Button
          title={'SAVE'}
          type={'fill'}
          onPress={() => handleSave()}
        />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={''}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => navigation.navigate('ForgotPassword')}
      />
      <KeyboardAwareScrollView contentContainerStyle={styles.keyboardAware}>
        <View style={styles.logoContainer}>
          <Image
            resizeMode={'contain'}
            source={IMAGES.IC_LOGO}
            style={styles.logo}
          />
          <View style={styles.forgotPassTextContainer}>
            <Text style={styles.forgotPassText}>Reset Password</Text>
          </View>
        </View>
        {renderForm()}
        {renderButton()}
      </KeyboardAwareScrollView>
      <COMPONENT.Popup />
      <COMPONENT.Loader isLoading={props.loading} />
    </SafeAreaView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  email: state.auth.email,
  loading: state.auth.loading,
  resetPassError: state.auth.resetPassError,
});

export default connect(mapStateToProps, {
  resetPassword_user,
  OpenValidationAlert,
})(ResetPassword);
