import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import React from 'react';
import Login from './Login';
import Splash from './Splash';
import ForgotPassword from './ForgotPassword';
import ResetPassword from './ResetPassword';
import Signup from './Signup';
import VerificationCode from './VerificationCode';
import WalkthroughBO from './WalkthroughBO';
import WalkthroughLO from './WalkthroughLO';
import BOTabs from 'src/screens/app/BOTabs';



// import CalculatorBO from 'src/screens/app/CalculatorBO'
// import PurchaseBO from 'src/screens/app/PurchaseBO'
// import RefinanceBO from 'src/screens/app/RefinanceBO'
// import FHARefinanceBO from 'src/screens/app/FHARefinanceBO'
// import ConventionalRefinanceBO from 'src/screens/app/ConventionalRefinanceBO'
// import JumboRefinanceBO from 'src/screens/app/JumboRefinanceBO'
// import USDARefinanceBO from 'src/screens/app/USDARefinanceBO'
// import VARefinanceBO from 'src/screens/app/VARefinanceBO'
// import FHAPurchaseBO from 'src/screens/app/FHAPurchaseBO'
// import ConventionalPurchaseBO from 'src/screens/app/ConventionalPurchaseBO'
// import JumboPurchaseBO from 'src/screens/app/JumboPurchaseBO'
// import USDAPurchaseBO from 'src/screens/app/USDAPurchaseBO'
// import VAPurchaseBO from 'src/screens/app/VAPurchaseBO'
// import AffordabilityBO from 'src/screens/app/AffordabilityBO'
// import AffordabilityResult from 'src/screens/app/AffordabilityResult'
// import SavedCalculationBO from 'src/screens/app/SavedCalculationBO'
// import ShouldIRefinanceBO from 'src/screens/app/ShouldIRefinanceBO'
// import RefinanceResult from 'src/screens/app/RefinanceResult'

// import UploadedDocumentBO from 'src/screens/app/UploadedDocumentBO'

import EditMenuBO from 'src/screens/app/EditMenuBO'


import { navigationRef } from 'src/routes/router';
import { App } from '../app/tabs/index';

const Stack = createStackNavigator();

function StackScreen() {
  return (
    <Stack.Navigator initialRouteName="Splash" headerMode={'none'}>
      {/* <Stack.Screen name="EditMenuBO" component={EditMenuBO} /> */}
      <Stack.Screen name="Splash" component={Splash} />
      <Stack.Screen name="WalkthroughBO" component={WalkthroughBO} />
      <Stack.Screen name="WalkthroughLO" component={WalkthroughLO} />
      <Stack.Screen name="Login" component={Login} />
      <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
      <Stack.Screen name="ResetPassword" component={ResetPassword} />
      <Stack.Screen name="VerificationCode" component={VerificationCode} />
      <Stack.Screen name="Signup" component={Signup} />
      <Stack.Screen name="LoanTackTabsBO" component={BOTabs} />
      <Stack.Screen name="LoanTackTabs" component={App} />
    </Stack.Navigator>
  );
}

export const Auth = () => (
  <NavigationContainer ref={navigationRef}>
    <Stack.Navigator
      initialRouteName="Splash"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name="Splash" component={StackScreen}></Stack.Screen>
    </Stack.Navigator>
  </NavigationContainer>
);

export const LoanTackTabs = () => (
  <NavigationContainer ref={navigationRef}>{/* <App /> */}</NavigationContainer>
);
