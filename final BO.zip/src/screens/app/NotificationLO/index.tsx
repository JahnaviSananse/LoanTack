import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation, useRoute } from '@react-navigation/native';

const NotificationLO = () => {
  const navigation = useNavigation()
  const params = useRoute().params;
  const data = [
    { name: "Jack recently uploaded a document", time: "3 mins ago" },
    { name: "Oliver Ross has sent you a message", time: "2 hours ago" },
  ]
  React.useEffect(() => {
  }, [])
  const renderItem = (item: any) => {
    return (
      <View>
        <View style={styles.cellContainer}>
          <Text style={styles.nameText}>{item.name}</Text>
          <Text style={styles.timeText}>{item.time}</Text>
        </View>
        <View style={styles.separetor} />
      </View>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={"Notifications"}
          leftImg={params !== undefined && IMAGES.IC_BACK}
          leftClick={() => params !== undefined && navigation.goBack()}
        />
        <View style={styles.flatlistContaier}>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => renderItem(item)}
          />
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default NotificationLO;

