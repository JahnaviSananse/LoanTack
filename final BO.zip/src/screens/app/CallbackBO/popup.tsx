import React from 'react';
import { Text, TouchableOpacity, View, Modal, Image, FlatList, Alert } from 'react-native';
import styles from './styles'
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import { useNavigation, useRoute } from '@react-navigation/native';


interface IButtonProps {
    visible: boolean;
    closeAlert: any;
    timeSlot: any;
    value: any;
}

const data = [{ title: "Morning" }, { title: "Evening" }, { title: "ASAP" }]
const Popup = (props: IButtonProps) => {
    const navigation = useNavigation();
    const { visible, closeAlert, timeSlot, value } = props;

    const renderItem = (item: any) => {
        return (
            <TouchableOpacity
                onPress={() => {
                    closeAlert(false)
                    timeSlot(item.title)
                }}
                style={[styles.cell, { backgroundColor: item.title === value ? "#4FB263" : "white" }]}>
                <Text style={[styles.title, { color: item.title === value ? "white" : "black" }]}>{item.title}</Text>
            </TouchableOpacity>
        )
    }
    return (
        <View style={styles.popupView}>
            <Modal
                animationType="none"
                transparent={true}
                visible={visible}
                onRequestClose={() => { }}>
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContainer}>
                        <TouchableOpacity
                            onPress={() => closeAlert(false)}
                            style={styles.close}>
                            <Image source={IMAGES.IC_CLOSE} style={styles.icon} resizeMode={'contain'} />
                        </TouchableOpacity>
                        <Text style={styles.desc}>{"Best Time to Call"}</Text>
                        <FlatList
                            scrollEnabled={true}
                            data={data}
                            style={styles.flatStyle}
                            showsVerticalScrollIndicator={false}
                            renderItem={({ item }) => renderItem(item)}
                        />
                    </View>
                </View>
            </Modal>
        </View>
    );

}
export default Popup;
