import React from 'react';

import { View, SafeAreaView, Text, ScrollView, Alert } from 'react-native';
import * as COMPONENT from 'src/components'
import styles from './styles';
import * as IMAGES from 'src/assets/images'
import * as Router from 'src/routes/router'
import { useNavigation } from '@react-navigation/native';

const termData = [
    { label: '5 Years', value: '5' },
    { label: '10 Years', value: '10' },
    { label: '20 Years', value: '20' },
    { label: '30 Years', value: '30' },
]
const yearData = [
    { label: '2008', value: '2008' },
    { label: '2009', value: '2009' },
    { label: '2010', value: '2010' },
    { label: '2011', value: '2011' },
    { label: '2012', value: '2012' },
    { label: '2013', value: '2013' },
    { label: '2014', value: '2014' },
    { label: '2015', value: '2015' },
]
const ShouldIRefinanceBO = () => {
    const [originalTerm, setOriginalTerm] = React.useState("5")
    const [newTerm, setNewTerm] = React.useState("10")
    const [year, setYear] = React.useState("2008")
    const [HOAValue, setHOAValue] = React.useState("")
    const [oldLoan, setOldloan] = React.useState([
        {
            title: 'Original Loan Amount',
            signature: '$',
            amt: 0,
            value: 0
        },
        {
            title: 'Original Interest Rate',
            signature: '%',
            amt: 0,
            value: 0
        },
    ])
    const [newLoan, setNewLoan] = React.useState([
        {
            title: 'New Loan Amount',
            signature: '$',
            amt: 0,
            value: 0
        },
        {
            title: 'New Interest Rate',
            signature: '$',
            amt: 0,
            value: 0
        },
    ])

    const navigation = useNavigation()

    const renderPicker = (currentData: any, type: number) => {
        return (
            <COMPONENT.Picker
                data={currentData}
                onValueChange={(value: any) => {
                    if (type === 1) {
                        setOriginalTerm(value)
                    } else if (type === 2) {
                        setYear(value)
                    } else {
                        setNewTerm(value)
                    }
                }}
                value={returnPickerValue(type)}
            />
        )
    }
    const returnPickerValue = (type: any) => {
        switch (type) {
            case 1:
                return originalTerm;
            case 2:
                return year;
            case 3:
                return newTerm;
        }
    }
    return (
        <SafeAreaView style={styles.container}>
            <COMPONENT.Header
                title='Should I Refinance?'
                rightImg={IMAGES.IC_HEADER_INFO}
                leftImg={IMAGES.IC_BACK}
                leftClick={() => Router.goBack()} />
            <ScrollView style={styles.scrollView}>
                <View style={styles.container}>
                    <View style={[styles.hzLine, { marginTop: 10 }]} />
                    <Text style={styles.boldTitle}>{'Your Original Loan'}</Text>
                    <View style={styles.hzLine} />
                    {
                        oldLoan.map((item, index) => {
                            let sliderValue = 0;
                            let minValue = 0
                            let maxValue = 0
                            if (index === 0) {
                                sliderValue = oldLoan[0].amt ? oldLoan[0].amt : 0;
                                minValue = 0;
                                maxValue = 4000000;
                            } else {
                                sliderValue = oldLoan[1].amt ? oldLoan[1].amt : 0
                                minValue = 0;
                                maxValue = 20;
                            }
                            return (
                                <>
                                    <View style={styles.viewContainer}>
                                        <Text style={styles.text}>{item.title}</Text>
                                        <COMPONENT.PriceBox
                                            sign={item.signature}
                                            title={item.amt}
                                            width={120}
                                            onChangeText={(value: number) => {
                                                let currentData = JSON.parse(JSON.stringify(oldLoan))
                                                currentData[index].amt = value
                                                setOldloan(currentData)
                                            }} />
                                    </View>
                                    <COMPONENT.Slider
                                        value={parseInt(sliderValue)}
                                        minValue={minValue}
                                        maxValue={maxValue}
                                        showPercentage={false}
                                        percentage={0}
                                        onValueChange={(value: any) => {
                                            if (index === 0) {
                                                let currentData = JSON.parse(JSON.stringify(oldLoan))
                                                currentData[0].amt = Math.round(value)
                                                setOldloan(currentData)
                                            } else {
                                                let currentData = JSON.parse(JSON.stringify(oldLoan))
                                                currentData[1].amt = Math.round(value)
                                                setOldloan(currentData)
                                            }
                                        }} />
                                </>
                            )
                        })
                    }
                    <Text style={styles.title}>{'Origination Year'}</Text>
                    {renderPicker(yearData, 2)}
                    <Text style={styles.title}>{'Original Term'}</Text>
                    {renderPicker(termData, 1)}
                    <View style={[styles.hzLine, { marginTop: 20 }]} />
                    <Text style={styles.boldTitle}>{'Your New Loan'}</Text>
                    <View style={styles.hzLine} />
                    <View style={{ marginVertical: 20 }}>
                        {
                            newLoan.map((item, index) => {
                                let sliderValue = 0;
                                let minValue = 0
                                let maxValue = 0
                                if (index === 0) {
                                    sliderValue = newLoan[0].amt ? newLoan[0].amt : 0
                                    minValue = 0;
                                    maxValue = 4000000;
                                } else {
                                    sliderValue = newLoan[1].amt ? newLoan[1].amt : 0
                                    minValue = 0;
                                    maxValue = 20;
                                }
                                return (
                                    <>
                                        <View style={styles.viewContainer}>
                                            <Text style={styles.text}>{item.title}</Text>
                                            <COMPONENT.PriceBox
                                                sign={item.signature}
                                                title={item.amt}
                                                width={120}
                                                onChangeText={(value: number) => {
                                                    let currentData = JSON.parse(JSON.stringify(newLoan))
                                                    currentData[index].amt = value
                                                    setNewLoan(currentData)
                                                }} />
                                        </View>
                                        <COMPONENT.Slider
                                            value={parseInt(sliderValue)}
                                            minValue={minValue}
                                            maxValue={maxValue}
                                            showPercentage={false}
                                            percentage={0}
                                            onValueChange={(value: any) => {
                                                if (index === 0) {
                                                    let currentData = JSON.parse(JSON.stringify(newLoan))
                                                    currentData[0].amt = Math.round(value)
                                                    setNewLoan(currentData)
                                                } else {
                                                    let currentData = JSON.parse(JSON.stringify(newLoan))
                                                    currentData[1].amt = Math.round(value)
                                                    setNewLoan(currentData)
                                                }
                                            }} />
                                    </>
                                )
                            })
                        }
                        <Text style={styles.title}>{'Refinance Fees'}</Text>
                        <COMPONENT.SignatureTextInput
                            isLeft={true}
                            sign={'$'}
                            placeholder={'0.00'}
                            value={HOAValue}
                            onChangeText={(text: any) => {
                                setHOAValue(text)
                            }}
                            keyboardType={'default'}
                            customStyle={styles.textInputCustom}
                        />
                        <Text style={styles.title}>{'New Term'}</Text>
                        {renderPicker(termData, 3)}
                        <View style={styles.buttonContainer}>
                            <COMPONENT.Button
                                title={"CALCULATE"}
                                type={"fill"}
                                onPress={() => navigation.navigate("RefinanceResult")}
                            />
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default ShouldIRefinanceBO;
