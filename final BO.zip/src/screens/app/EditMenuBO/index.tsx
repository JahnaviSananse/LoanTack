import React from 'react';
import {
  View,
  Dimensions,
  SafeAreaView,
  Image,
  Text,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import { DraggableGrid } from 'react-native-draggable-grid';
import styles from './styles';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { useNavigation } from '@react-navigation/native';
import { setTabbarTabs } from 'src/redux/actions/dashboard_bo'

interface IEditMenuBOProps {
  setTabbarTabs: Function;
  allTabs: any;
  mainlistData: any;
}
const blankData = [
  { id: "DASHBOARD", type: 1, name: "", "sequence": 6, },
  { id: "DASHBOARD", type: 1, name: "", "sequence": 7, }
]
const EditMenuBO = (props: IEditMenuBOProps) => {
  const navigation = useNavigation()
  const [data, setData] = React.useState([]);
  React.useEffect(() => {
    if (props.mainlistData) {
      let termpData = JSON.parse(JSON.stringify(props.mainlistData))
      let fillData = termpData.filter(fvalue => fvalue.name !== "")

      let mainLinks = fillData.splice(0, 4)
      let moreLinks = fillData.splice(0, fillData.length)
      fillData = moreLinks.concat(mainLinks)

      fillData.splice.apply(fillData, [6, 0].concat(blankData));
      let mdata = []
      Object.values(fillData).map((mvalue, index) => {
        let temp = JSON.parse(JSON.stringify(mvalue))
        temp.key = index.toString()
        mdata.push(temp)
      })
      setData(mdata)
    }
  }, [props.mainlistData])
  const renderItem = (item: any, index: number) => {
    return (
      <View>
        {index < 6 &&
          <View style={styles.item}
            key={item.key}>
            <Image source={{ uri: item.icon.gray }} style={styles.icon} resizeMode={'contain'} />
            <Text style={styles.item_text}>{item.name}</Text>
          </View>
        }
        {index > 7 &&
          <View style={styles.selected_item}
            key={item.key}>
            <Image source={{ uri: item.icon.gray }} style={styles.icon} resizeMode={'contain'} />
            <Text style={styles.item_text}>{item.name}</Text>
          </View>
        }
      </View>
    )
  }
  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={"Edit Menu"}
        leftImg={IMAGES.IC_BACK}
        leftClick={() => {
          setTimeout(() => {
            props.setTabbarTabs(JSON.parse(JSON.stringify(data)))
            navigation.goBack()
          }, 100);
        }}
      />
      <View style={styles.blackContainer}>
        <Text style={styles.mainLinks}>Main Links</Text>
      </View>
      <View style={styles.whiteContainer}>
        <Text style={styles.moreLinks}>More Links</Text>
        <View style={styles.sep} />
      </View>
      <View style={styles.wrapper}>
        <DraggableGrid
          numColumns={4}
          renderItem={(item, index) => renderItem(item, index)}
          data={data && data}
          onDragRelease={(data) => {
            let fillData = data.filter(fvalue => fvalue.name !== "")
            let blankData = data.filter(fvalue => fvalue.name === "")
            fillData.splice.apply(fillData, [6, 0].concat(blankData));
            console.log("fillData", fillData)
            setData(fillData)
          }}
        />
      </View>
    </SafeAreaView>
  );
};

const mapStateToProps = (state: IReduxState) => (
  {
    allTabs: state.common.tabs,
    mainlistData: state.dashboard_bo.mainlistData
  });

export default connect(mapStateToProps, {
  setTabbarTabs
})(EditMenuBO);
