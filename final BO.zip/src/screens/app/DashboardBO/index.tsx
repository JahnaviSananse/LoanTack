import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  View,
  Image,
  Text,
  KeyboardAvoidingView,
  AsyncStorage,
  SafeAreaView,
  ScrollView,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import styles from './styles';
import CELL from './cell';
import {useNavigation} from '@react-navigation/native';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
import {toggleSettingOption} from 'src/redux/actions/common';
import {setScanRedirect} from 'src/redux/actions/common';
import * as CONSTANT from 'src/constants/constant';
import {
  getLOOfficers,
  getAssignedLO,
  assignLO,
  clearAssignData,
} from 'src/redux/actions/dashboard_bo';
import * as COMPONENT from 'src/components';

interface IDashboardLOProps {
  toggleSettingOption: any;
  showOptions: boolean;
  setScanRedirect: Function;
  userData: Object;
  getLOOfficers: Function;
  getAssignedLO: Function;
  clearAssignData: Function;
  assignedloData: any;
  loading: boolean;
}
const DashboardLO = (props: IDashboardLOProps) => {
  const navigation = useNavigation();
  const [isAvailable, setIsAvailable] = React.useState(null);
  const data = [
    {
      title: 'Calculator',
      image: IMAGES.IC_CELL_CAL,
      stack: 'CalculatorScreen',
      redirect: 'CalculatorBO',
    },
    {
      title: 'Scan Documents',
      image: IMAGES.IC_CELL_SCAN,
      stack: 'ScanScreen',
      redirect: 'ScanDocumentBO',
    },
    {
      title: 'Uploaded Documents',
      image: IMAGES.IC_CELL_DOC,
      stack: 'UploadedDocumentScreen',
      redirect: 'UploadedDocumentBO',
    },
  ];
  const OfficerData = [
    {
      name: 'Robert Baker',
      designation: 'Branch Manager',
      code: 'NMLS : 236495',
      image: IMAGES.IC_DEMO_PROFILE,
      main: true,
    },
    {
      name: 'Roy Miller',
      designation: 'Branch Manager',
      code: 'NMLS : 236495',
      image: IMAGES.IC_LOAN_OFFICER,
      main: false,
    },
  ];
  const introData = {
    title: 'Welcome!',
    detail:
      'Proin at sollicitudin molestie non quis tempor vestibulum ac. Nulla dignissim egestas iaculis sem mauris curabitur eget id euismod. Enim blandit nulla...',
  };
  React.useEffect(() => {
    props.getAssignedLO();
  }, []);

  React.useEffect(() => {
    AsyncStorage.getItem(CONSTANT.USER_DATA).then((value) => {
      let data = JSON.parse(value);
      if (data.data.user.parent_id) {
        setIsAvailable(true);
      } else {
        setIsAvailable(false);
      }
    });
    if (isAvailable) {
      //props.getAssignedLO();
      console.log('AssignedLO_data', props.assignedloData);
    }
  }, [props.getAssignedLO, props.assignedloData, isAvailable]);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity
        style={styles.cellContainer}
        onPress={() => {
          if (item.stack !== 'CalculatorScreen') {
            props.setScanRedirect('DashboardBO');
          }
          navigation.navigate(item.stack, {
            screen: item.redirect,
            params: {isBack: true},
          });
        }}>
        <Image
          source={item.image}
          style={styles.cellImage}
          resizeMode={'contain'}
        />
        <Text style={styles.cellTitle}>{item.title}</Text>
      </TouchableOpacity>
    );
  };
  const renderIntro = (detail) => {
    return (
      <View style={styles.introContainer}>
        <Text style={styles.introTitle}>{introData.title}</Text>
        <Text style={styles.introDetail}>{detail}</Text>
        <TouchableOpacity style={styles.readMoreButton}>
          <Text style={styles.readMoreText}>READ MORE</Text>
        </TouchableOpacity>
      </View>
    );
  };
  const renderOfficer = () => {
    if (props.assignedloData === []) {
      //props.getAssignedLO();
    }
    let data = Object.entries(props.assignedloData).length
      ? [props.assignedloData.data]
      : [];
    console.log('DATA', data);
    return (
      <View>
        <FlatList
          scrollEnabled={false}
          data={data}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.containStyle}
          renderItem={({item}) => <CELL item={item} />}
        />
        {renderIntro(
          Object.entries(props.assignedloData).length
            ? props.assignedloData.data.welcome_text
            : '',
        )}
      </View>
    );
  };
  const selectOfficer = () => {
    return (
      <View>
        <TouchableOpacity
          style={styles.selectOfficeContainer}
          onPress={() => {
            props.getLOOfficers();
            navigation.navigate('MessageScreen', {
              screen: 'SelectLO',
              params: {isBack: true},
            });
            props.clearAssignData();
          }}>
          <Text style={styles.loanOfficeText}>Select Loan Officer</Text>
        </TouchableOpacity>
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Dashboard'}
          leftImg={IMAGES.IC_HEADER_SETTING}
          leftClick={() => props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView>
          {isAvailable ? renderOfficer() : selectOfficer()}
          <FlatList
            scrollEnabled={false}
            data={data}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.containStyle}
            renderItem={({item}) => renderItem(item)}
          />
        </ScrollView>
        <COMPONENT.Loader isLoading={props.loading} />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions,
  userData: state.auth.userData,
  assignedloData: state.dashboard_bo.assignedloData,
  loading: state.dashboard_bo.loading,
});

export default connect(mapStateToProps, {
  toggleSettingOption,
  setScanRedirect,
  getLOOfficers,
  getAssignedLO,
  clearAssignData,
})(DashboardLO);
