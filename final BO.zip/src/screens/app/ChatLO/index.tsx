import React from 'react';
import {
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  TextInput,
  KeyboardAvoidingView,
  ScrollView,
  FlatList,
  Platform,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import Bubble from './Bubble';
import chat from './chat.json'
import { useNavigation, useRoute } from '@react-navigation/native';
import DocumentPicker from 'react-native-document-picker';
import ImagePicker from 'react-native-image-crop-picker';

const ChatLO = () => {
  const navigation = useNavigation()
  const params = useRoute().params;
  const [msgAry, setMsgAry] = React.useState(chat);
  const [msg, setMsg] = React.useState("");
  const [userID, setUser] = React.useState(1);
  const [optionVisible, setOptionVisible] = React.useState(false);
  const [name, setName] = React.useState("");
  const [canGoBack, setCanGoBack] = React.useState(false);
  React.useEffect(() => {
    if (params) {
      if (params.name !== undefined) {
        setName(params.name)
      } else {
        setName("Robert Baker")
      }
      if (params.isBack !== undefined) {
        setCanGoBack(true)
      }
    } else {
      setName("Robert Baker")
    }
  }, [params])
  const onSend = (msg: any) => {
    if (msg.trim() !== "") {
      let obj = {
        _id: 1,
        text: msg,
        createdAt: new Date(),
        user_id: 1,
      }
      setMsgAry([obj].concat(msgAry))
      setMsg("")
    }
  }
  const chooseDoc = async () => {
    try {
      const res = await DocumentPicker.pick({
        type: [DocumentPicker.types.pdf],
      });
      let obj = {
        _id: 1,
        createdAt: new Date(),
        user_id: 1,
        pdf: res.uri,
        filename: res.name
      }
      setOptionVisible(false)
      setMsgAry([obj].concat(msgAry))
    } catch (err) {
      if (DocumentPicker.isCancel(err)) {
      } else {
        throw err;
      }
    }
  }

  const chooseImage = () => {
    ImagePicker.openPicker({
      mediaType: 'photo',
      multiple: false
    }).then(images => {
      let obj = {
        _id: 1,
        createdAt: new Date(),
        user_id: 1,
        image: images.path,
        filename: images.path.substring(images.path.lastIndexOf('/') + 1)
      }
      setMsgAry([obj].concat(msgAry))
      setOptionVisible(false)
    })
  }
  const renderChatFooter = () => {
    let ATTACHMENT = optionVisible ? IMAGES.IC_ATTACHMENT_ACTIVE : IMAGES.IC_ATTACHMENT_INACTIVE
    return (
      <View>
        {optionVisible &&
          <View style={styles.optionBox}>
            <TouchableOpacity onPress={() => chooseImage()} style={styles.buttonCotainer}>
              <Image source={IMAGES.IC_ADD_IMAGE} style={styles.optionIcons} resizeMode={"contain"} />
              <Text style={styles.optionText}>Image</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => chooseDoc()} style={styles.buttonCotainer}>
              <Image source={IMAGES.IC_ADD_DOC} style={styles.optionIcons} resizeMode={"contain"} />
              <Text style={styles.optionText}>Document</Text>
            </TouchableOpacity>
          </View>
        }
        <View style={styles.bottomContainer}>
          <View style={styles.textFieldContainer}>
            <TextInput
              style={[styles.textFieldStyle, { fontStyle: msg.length === 0 ? 'italic' : 'normal' }]}
              value={msg}
              placeholder={"Type Here"}
              onChangeText={text => setMsg(text)}
            />
            <TouchableOpacity style={styles.attachmentContainer} onPress={() => setOptionVisible(!optionVisible)} >
              <Image source={ATTACHMENT} style={styles.iconAttachment} />
            </TouchableOpacity>
          </View>
          <TouchableOpacity style={styles.sendContainer} onPress={() => onSend(msg)}>
            <Image source={IMAGES.IC_SEND} resizeMode={'contain'} style={styles.iconSend} />
          </TouchableOpacity>
        </View>
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <COMPONENT.Header
        title={name}
        leftImg={canGoBack && IMAGES.IC_BACK}
        leftClick={() => canGoBack && navigation.goBack()}
      />
      <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === 'android' ? -500 : 0} style={styles.keyboardAware}>
        <View style={styles.mainContainer}>
          <FlatList
            data={msgAry}
            inverted
            style={styles.flatStyle}
            showsVerticalScrollIndicator={false}
            renderItem={({ item, index }) => <Bubble item={item} showDate={msgAry.length - 1 === index ? true : false} />}
          />
          <View style={styles.footerContainer}>
            {renderChatFooter()}
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView >
  );
};

export default ChatLO;

