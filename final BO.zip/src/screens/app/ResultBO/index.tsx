import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Image,
  FlatList,
  Text,
  Modal,
  ScrollView,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import {useNavigation} from '@react-navigation/native';
import Pie from 'react-native-pie';
import * as UTILITY from 'src/utility/util';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
import {OpenValidationAlert} from 'src/redux/actions/common';

const chartData = [
  {
    percentage: 30,
    color: '#F4C427',
  },
  {
    percentage: 40,
    color: '#4FB263',
  },
  {
    percentage: 20,
    color: '#3ACBE9',
  },
  {
    percentage: 10,
    color: '#EB4949',
  },
];
const data = [
  {color: '#4FB263', title: '$1,155.73', desc: 'Principal & Interest'},
  {color: '#EB4949', title: '$66.67', desc: 'Hazard Insurance'},
  {color: '#F4C427', title: '$250.00', desc: 'Taxes & HOA'},
  {color: '#3ACBE9', title: '$228.24', desc: 'Mortgage Insurance'},
];
const description =
  'LoanTack helps you determine your monthly mortgage payment by estimating your total loan amount, mortgage term length, and interest rate. Accurate estimates rely on the user entering accurate FICO score, property taxes and applicable HOA fees. Any calculation results are estimates, not final loan amounts, and are not guaranteed.';
const detailData = [
  {title: 'Details', redirect: 'ResultDetailBO'},
  {title: 'Amortization', redirect: 'Amortization'},
];
interface IResultProps {
  loading: boolean;
  OpenValidationAlert: Function;
}
const ResultBO = (props: IResultProps) => {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = React.useState(false);
  const [fileName, setFileName] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState('');

  React.useEffect(() => {}, []);

  const renderPageRedirect = (item: any) => {
    return (
      <TouchableOpacity
        style={styles.redirectCell}
        onPress={() => navigation.navigate(item.redirect)}>
        <View style={styles.saperator} />
        <Text style={styles.pageTitle}>{item.title}</Text>
      </TouchableOpacity>
    );
  };
  const renderPie = () => {
    return (
      <View style={styles.chartContainer}>
        <Pie radius={80} sections={chartData} strokeCap={'butt'} />
      </View>
    );
  };
  const renderButtons = () => {
    return (
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.shareButton}>
          <Image
            source={IMAGES.IC_RESULT_SHARE}
            style={styles.icon}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
        <TouchableOpacity style={styles.downloadButton}>
          <Image
            source={IMAGES.IC_RESULT_DOWNLOAD}
            style={styles.icon}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.saveButton}
          onPress={() => {
            setModalVisible(true);
          }}>
          <Text style={styles.saveText}>SAVE</Text>
        </TouchableOpacity>
      </View>
    );
  };
  const renderRedirectPage = () => {
    return (
      <FlatList
        scrollEnabled={false}
        data={detailData}
        style={styles.flatlistStyle}
        showsVerticalScrollIndicator={false}
        renderItem={({item}) => renderPageRedirect(item)}
      />
    );
  };
  const validateName = () => {
    if (fileName.trim() === '') {
      setAlertMessage(true);
      let obj = {
        message: 'Please enter a name to save calculation',
        type: 'failure',
      };
      props.OpenValidationAlert(obj);
    } else {
      setAlertMessage(false);
      setModalVisible(false);
      setTimeout(() => {
        setFileName('');
        navigation.navigate('SavedCalculationScreen', {
          screen: 'SavedCalculationBO',
          params: {isBack: true},
        });
      }, 500);
    }
  };
  const showAlertMessage = () => {
    return (
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <Image
            source={IMAGES.IC_FAILURE}
            style={styles.popupImage}
            resizeMode={'contain'}
          />
          <Text style={styles.desc}>
            {'Please enter a name to save calculation'}
          </Text>
          <View style={styles.alertbuttonContainer}>
            <COMPONENT.Button
              title={'OK'}
              onPress={() => {
                setAlertMessage(false);
              }}
              type={'fill'}
            />
          </View>
        </View>
      </View>
    );
  };
  const getFileName = () => {
    return (
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <Text style={styles.alertTitle}>Save Calculation</Text>
          <COMPONENT.TextField
            maxLength={15}
            value={fileName}
            title={'Name'}
            placeholder={'Enter Here'}
            secureTextEntry={false}
            onChangeText={(name: string) => {
              setFileName(name);
            }}
          />
          <View style={styles.alertbuttonsContainer}>
            <COMPONENT.Button
              title={'SAVE'}
              type={'fill'}
              onPress={() => {
                if (fileName.trim() === '') {
                  setAlertMessage(true);
                  let obj = {
                    message: 'Please enter a name to save calculation',
                    type: 'failure',
                  };
                  props.OpenValidationAlert(obj);
                } else {
                  setAlertMessage(false);
                  setModalVisible(false);
                  setTimeout(() => {
                    setFileName('');
                    navigation.navigate('SavedCalculationScreen', {
                      screen: 'SavedCalculationBO',
                      params: {isBack: true},
                    });
                  }, 500);
                }
              }}
            />

            <COMPONENT.Button
              title={'CANCEL'}
              type={'unfill'}
              onPress={() => setModalVisible(false)}
            />
          </View>
        </View>
      </View>
    );
  };
  const renderPopup = () => {
    return (
      <View style={styles.popupView}>
        <Modal
          animationType="none"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            setModalVisible(false);
          }}>
          {getFileName()}
          <COMPONENT.Popup />
        </Modal>
      </View>
    );
  };
  const closeAlert = () => {
    setShowAlert(false);
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Results'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <ScrollView>
          {renderPopup()}
          <View style={styles.paymentContainer}>
            <Text style={styles.amount}>$1,700.64</Text>
            <Text style={styles.amountDesc}>Total Payment Amount</Text>
          </View>
          {renderPie()}
          <COMPONENT.ChartDetail data={data} column={2} />
          {renderButtons()}
          {renderRedirectPage()}
          <View style={styles.descContainer}>
            <Text style={styles.descText}>{description}</Text>
          </View>
        </ScrollView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};
const mapStateToProps = (state: IReduxState) => ({
  loading: state.auth.loading,
});
export default connect(mapStateToProps, {
  OpenValidationAlert,
})(ResultBO);
