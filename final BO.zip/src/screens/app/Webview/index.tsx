import React from 'react';
import {View, TextInput, Text} from 'react-native';
import styles from './styles';
import {WebView} from 'react-native-webview';
import {SafeAreaView, KeyboardAvoidingView} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import {useNavigation, useRoute} from '@react-navigation/native';

const Webview = (props: any) => {
  const navigation = useNavigation();
  var params = useRoute().params;
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={''}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <WebView source={{uri: params.url}} scrollEnabled={true} />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};
export default Webview;
