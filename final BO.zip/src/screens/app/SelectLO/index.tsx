import React from 'react';
import {
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  View,
  TextInput,
  SafeAreaView,
  Image,
  Text,
  AsyncStorage,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import * as CONSTANT from 'src/constants/constant';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
import {assignLO, clearAssignData} from 'src/redux/actions/dashboard_bo';
import {OpenValidationAlert, closeModal} from 'src/redux/actions/common';
import styles from './styles';
import {useNavigation} from '@react-navigation/native';
import * as Router from '../../../routes/router';
interface ISelectLO {
  loofficerData: Object;
  assignLO: Function;
  assignloMessage: string;
  loading: boolean;
  OpenValidationAlert: Function;
  clearAssignData: Function;
  closeModal: Function;
}
const SelectLO = (props: ISelectLO) => {
  const navigation = useNavigation();
  const [search, setSearch] = React.useState('');
  const [data, setData] = React.useState([]);

  React.useEffect(() => {
    if (props.loofficerData.data !== undefined) {
      if (props.loofficerData.data.data.is_data) {
        setData(props.loofficerData.data.data.result);
      }
    }
    if (search !== '') {
      if (props.loofficerData.data !== undefined) {
        let mData = JSON.parse(
          JSON.stringify(props.loofficerData.data.data.result),
        );
        let ary = [];
        mData.map((mvalue) => {
          let n = mvalue.name.search(search);
          if (n !== -1) {
            ary.push(mvalue);
          }
        });
        setData(ary);
      } else {
        setData(mData);
      }
    }
    if (props.assignloMessage && !props.loading) {
      AsyncStorage.getItem(CONSTANT.USER_DATA).then((value) => {
        let data = JSON.parse(value);
        data.data.user.parent_id = true;
        AsyncStorage.setItem(CONSTANT.USER_DATA, JSON.stringify(data));
      });
      setTimeout(() => {
        let obj = {
          message: props.assignloMessage,
          type: 'success',
        };
        props.OpenValidationAlert(obj);
        Router.replace('DashboardBO', {});
        props.clearAssignData();
        props.closeModal();
      }, 500);
    }
  }, [search, props.loofficerData, props.assignloMessage]);
  const renderItem = (item: any) => {
    return (
      <View>
        <TouchableOpacity
          onPress={() => {
            let obj = {
              assign_lo_number: item.id,
            };
            props.assignLO(obj);
          }}
          style={styles.cellContainer}>
          <Image source={{uri: item.profile_photo}} style={styles.avatar} />
          <Text style={styles.nameText}>{item.name}</Text>
        </TouchableOpacity>
        <View style={styles.separetor} />
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'New Message'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <View style={styles.dataContainer}>
          <View style={styles.searchContainer}>
            <Image source={IMAGES.IC_SEARCH} style={styles.searchIcon} />
            <TextInput
              style={styles.textInput}
              value={search}
              placeholder={'Search'}
              onChangeText={(text) => setSearch(text)}
            />
          </View>
          <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            renderItem={({item}) => renderItem(item)}
          />
        </View>
        <COMPONENT.Popup />
        <COMPONENT.Loader isLoading={props.loading} />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  loofficerData: state.dashboard_bo.loofficerData,
  assignloMessage: state.dashboard_bo.assignloMessage,
  loading: state.dashboard_bo.loading,
});

export default connect(mapStateToProps, {
  assignLO,
  OpenValidationAlert,
  clearAssignData,
  closeModal,
})(SelectLO);
