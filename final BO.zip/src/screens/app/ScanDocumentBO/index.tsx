import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  ScrollView,
  Image
} from 'react-native';
import * as IMAGES from 'src/assets/images'
import * as COMPONENT from 'src/components'
import styles from './styles';
import { useNavigation, useRoute } from '@react-navigation/native';
import POPUP from './popup'
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { toggleSettingOption } from 'src/redux/actions/common'


interface IScanDocumentBOProps {
  toggleSettingOption: any;
  showOptions: boolean;
}
const ScanDocumentBO = (props: IScanDocumentBOProps) => {
  const navigation = useNavigation()
  const params = useRoute().params;
  const [showAlert, setShowAlert] = React.useState(false);
  const [fileName, setFileName] = React.useState("");
  React.useEffect(() => {
  }, [])
  const renderButton = () => {
    return (
      <View style={styles.uploadDocumentContainer}>
        <TouchableOpacity style={styles.uploadDocumentButton} onPress={() => {
          navigation.navigate("UploadedDocumentScreen", {
            screen: "UploadedDocumentBO",
            params: { isBack: true },
          })
        }}>
          <Text style={styles.uploadDocumentText}>UPLOADED DOCUMENTS</Text>
        </TouchableOpacity>
      </View>
    )
  }
  const renderOptions = () => {
    return (
      <View>
        <View style={styles.buttonsContainer}>
          <View>
            <TouchableOpacity style={styles.button} onPress={() => setShowAlert(true)}>
              <Image source={IMAGES.IC_BUTTON_CAMERA} style={styles.img} resizeMode={'contain'} />
            </TouchableOpacity>
            <Text style={styles.buttonTitle}>Take a Photo</Text>
          </View>
          <View>
            <TouchableOpacity style={styles.button} onPress={() => setShowAlert(true)}>
              <Image source={IMAGES.IC_BUTTON_GALLARY} style={styles.img} resizeMode={'contain'} />
            </TouchableOpacity>
            <Text style={styles.buttonTitle}>Select from Gallery</Text>
          </View>
        </View>
        <View style={styles.buttonsContainer}>
          <View>
            <TouchableOpacity style={styles.button} onPress={() => setShowAlert(true)}>
              <Image source={IMAGES.IC_BUTTON_FILE} style={styles.img} resizeMode={'contain'} />
            </TouchableOpacity>
            <Text style={styles.buttonTitle}>Upload File</Text>
          </View>
        </View>
      </View>
    )
  }
  const closeAlert = () => {
    setShowAlert(false)
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Scan'}
          leftImg={params !== undefined ? IMAGES.IC_BACK : IMAGES.IC_HEADER_SETTING}
          leftClick={() => params !== undefined ? navigation.goBack() : props.toggleSettingOption(!props.showOptions)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <Text style={styles.title}>Scan New Document</Text>
        <ScrollView style={styles.mainContainer} contentContainerStyle={styles.extraPadding}>
          {renderOptions()}
          {renderButton()}
        </ScrollView>
        <POPUP type={"failure"}
          visible={showAlert}
          closeAlert={() => closeAlert()}
          onChangeText={(text: string) => setFileName(text)}
          value={fileName}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};


const mapStateToProps = (state: IReduxState) => ({
  showOptions: state.common.showOptions
});

export default connect(mapStateToProps, {
  toggleSettingOption
})(ScanDocumentBO);


