import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';

const data = [
  { title: 'FHA', redirect: "FHARefinanceBO" },
  { title: 'Conventional', redirect: "ConventionalRefinanceBO" },
  { title: 'Jumbo', redirect: "JumboRefinanceBO" },
  { title: 'USDA', redirect: 'USDARefinanceBO' },
  { title: 'VA', redirect: "VARefinanceBO" },
]

const RefinanceBO = () => {
  const navigation = useNavigation()
  React.useEffect(() => {

  }, []);
  const renderItem = (item: any) => {
    return (
      <TouchableOpacity style={styles.cellContainer} onPress={() => navigation.navigate(item.redirect)}>
        <Text style={styles.title}>{item.title}</Text>
        <View style={styles.saperator} />
      </TouchableOpacity>
    )
  }
  return (
    <KeyboardAvoidingView behavior="padding" enabled style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Refinance'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <FlatList
          scrollEnabled={false}
          data={data}
          style={styles.flatStyle}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => renderItem(item)}
        />
      </SafeAreaView>
    </KeyboardAvoidingView >
  );
};

export default RefinanceBO;
