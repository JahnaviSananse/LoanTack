import React from 'react';
import { View, SafeAreaView, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as COMPONENT from 'src/components'
import styles from './styles';
import * as IMAGES from 'src/assets/images'
import * as Router from 'src/routes/router'

const termData = [
    { label: '5 Years', value: '5' },
    { label: '10 Years', value: '10' },
    { label: '20 Years', value: '20' },
    { label: '30 Years', value: '30' },
]

const stateData = [
    {
        label: 'California', value: 'California', data: [
            { label: 'Alpine', value: 'Alpine' },
            { label: 'Calaveras', value: 'Calaveras' },
            { label: 'El Dorado', value: 'El Dorado' },
            { label: 'Los Angeles', value: 'Los Angeles' },
            { label: 'San Diego', value: 'San Diego' },
            { label: 'San Francisco', value: 'San Francisco' },
        ]
    },
    {
        label: 'Florida', value: 'Florida', data: [
            { label: 'Alachua', value: 'Alachua' },
            { label: 'Charlotte', value: 'Charlotte' },
            { label: 'Manatee', value: 'Manatee' },
            { label: 'Miami-Dade', value: 'Miami-Dade' },
            { label: 'Palm Beach', value: 'Palm Beach' },
            { label: 'Saint Johns', value: 'Saint Johns' },
        ]
    },
    {
        label: 'Texas', value: 'Texas', data: [
            { label: 'Armstrong', value: 'Armstrong' },
            { label: 'Brooks', value: 'Brooks' },
            { label: 'Collingsworth', value: 'Collingsworth' },
            { label: 'Crockett', value: 'Crockett' },
            { label: 'Kenedy', value: 'Kenedy' },
            { label: 'Shelby', value: 'Shelby' },
        ]
    },
    {
        label: 'Arizona', value: 'Arizona', data: [
            { label: 'Apache', value: 'Apache' },
            { label: 'Graham', value: 'Graham' },
            { label: 'Maricopa', value: 'Maricopa' },
            { label: 'Mohave', value: 'Mohave' },
            { label: 'Santa Cruz', value: 'Santa Cruz' },
            { label: 'Yavapai', value: 'Yavapai' },
        ]
    },
]
const VAPurchaseBO = () => {
    const navigation = useNavigation()
    const [term, setTerm] = React.useState("5");
    const [state, setState] = React.useState("California");
    const [country, setCountry] = React.useState("USA");
    const [HOAValue, setHOAValue] = React.useState("")
    const [InsuranceValue, setInsuranceValue] = React.useState("")
    const [PropertyPercentage, setPropertyPercenatge] = React.useState("")
    const [PropertyAmount, setPropertyAmount] = React.useState("")
    const [advOpen, setAdvOpen] = React.useState(false);
    const [countryList, setCountryList] = React.useState(stateData[0].data)
    const [data, setData] = React.useState([
        {
            title: 'Property Price',
            signature: '$',
            amt: 0,
            value: 0
        },
        {
            title: 'Down Payment',
            signature: '$',
            amt: 0,
            value: 0
        },
        {
            title: 'Interest Rate',
            signature: '%',
            amt: 0,
            value: 0
        },
    ])
    const renderPicker = (pickerdata: any, type: any) => {
        return (
            <COMPONENT.Picker
                data={pickerdata}
                onValueChange={(value: any) => {
                    if (type === 1) {
                        setTerm(value)
                    } else if (type === 2) {
                        let ary = stateData.filter(fvalue => fvalue.value === value)
                        setCountryList(ary[0].data)
                        setState(value)
                    } else {
                        setCountry(value)
                    }
                }}
                value={returnPickerValue(type)}
            />
        )
    }
    const returnPickerValue = (type: any) => {
        switch (type) {
            case 1:
                return term;
            case 2:
                return state;
            case 3:
                return country;

        }
    }
    return (
        <SafeAreaView style={styles.container}>
            <COMPONENT.Header
                title='VA Purchase'
                rightImg={IMAGES.IC_HEADER_INFO}
                leftImg={IMAGES.IC_BACK}
                leftClick={() => Router.goBack()} />
            <ScrollView style={styles.scrollView}>
                <View style={styles.container}>
                    {
                        data.map((item, index) => {
                            let sliderValue = 0;
                            let minValue = 0
                            let maxValue = 0
                            if (index === 0) {
                                sliderValue = data[0].amt ? data[0].amt : 0;
                                minValue = 0;
                                maxValue = 4000000;
                            } else if (index === 1) {
                                sliderValue = data[1].amt ? data[1].amt : 0
                                minValue = 0;
                                maxValue = 4000000;
                            } else {
                                sliderValue = data[2].amt ? data[2].amt : 0;
                                minValue = 0;
                                maxValue = 20;
                            }
                            return (
                                <>
                                    <View style={styles.viewContainer}>
                                        <Text style={styles.text}>{item.title}</Text>
                                        {item.title === "Down Payment" &&
                                            <COMPONENT.PriceBox
                                                sign={"%"}
                                                width={80}
                                                title={item.value}
                                                onChangeText={(value: number) => {
                                                    let currentData = JSON.parse(JSON.stringify(data))
                                                    let per = 4000000 * value / 100
                                                    per = per > 0 ? per : 0
                                                    currentData[index].amt = per
                                                    currentData[index].value = value && value
                                                    setData(currentData)
                                                }} />
                                        }
                                        <View>
                                            <COMPONENT.PriceBox
                                                sign={item.signature}
                                                title={item.amt}
                                                width={120}
                                                onChangeText={(value: number) => {
                                                    let currentData = JSON.parse(JSON.stringify(data))
                                                    let per = currentData[index].amt * 100
                                                    per = per / 400000
                                                    currentData[index].amt = value
                                                    currentData[index].value = value > 0 ? per : 0
                                                    setData(currentData)
                                                }} />
                                        </View>
                                    </View>
                                    <COMPONENT.Slider
                                        value={parseInt(sliderValue)}
                                        minValue={minValue}
                                        maxValue={maxValue}
                                        showPercentage={index === 1 ? true : false}
                                        percentage={parseFloat(data[1].value)}
                                        onValueChange={(value: any) => {
                                            if (index === 0) {
                                                let currentData = JSON.parse(JSON.stringify(data))
                                                currentData[0].amt = Math.round(value)
                                                setData(currentData)
                                            } else if (index === 1) {
                                                let currentData = JSON.parse(JSON.stringify(data))
                                                let per = currentData[index].amt * 10
                                                per = per / 400000
                                                per = per > 0 ? per : 0
                                                currentData[1].value = per.toFixed(2)
                                                currentData[1].amt = value.toFixed(2)
                                                setData(currentData)
                                            } else {
                                                let currentData = JSON.parse(JSON.stringify(data))
                                                currentData[2].amt = Math.round(value)
                                                setData(currentData)
                                            }
                                        }} />
                                </>
                            )
                        })
                    }
                    <TouchableOpacity
                        onPress={() => setAdvOpen(!advOpen)}
                        style={styles.advStyle}>
                        <Text style={styles.boldTitle}>{'Advanced'}</Text>
                        <Image source={advOpen ? IMAGES.IC_UP_ARROW : IMAGES.IC_DOWN_ARROW} style={styles.iconContainer} resizeMode={"contain"} />
                    </TouchableOpacity>
                    {advOpen &&
                        <View style={{ marginVertical: 20 }}>
                            <Text style={styles.title}>{'Term'}</Text>
                            {renderPicker(termData, 1)}
                            <Text style={styles.title}>{'Monthly HOA'}</Text>
                            <COMPONENT.SignatureTextInput
                                isLeft={true}
                                sign={'$'}
                                placeholder={'0.00'}
                                value={HOAValue}
                                onChangeText={(text: any) => {
                                    setHOAValue(text)
                                }}
                                keyboardType={'default'}
                                customStyle={styles.textInputCustom}

                            />
                            <Text style={styles.title}>{'Annual Hazard Insurance'}</Text>
                            <COMPONENT.SignatureTextInput
                                isLeft={true}
                                sign={'$'}
                                placeholder={'0.00'}
                                value={InsuranceValue}
                                onChangeText={(text: any) => {
                                    setInsuranceValue(text)
                                }}
                                keyboardType={'default'}
                                customStyle={styles.textInputCustom}

                            />
                            <Text style={styles.title}>{'Annual Property Tax'}</Text>
                            <View style={styles.taxMainContainer}>
                                <View style={styles.taxContainer}>
                                    <COMPONENT.SignatureTextInput
                                        isLeft={false}
                                        sign={'%'}
                                        placeholder={'0.00'}
                                        value={PropertyPercentage}
                                        onChangeText={(text: any) => {
                                            setPropertyPercenatge(text)
                                        }}
                                        keyboardType={'default'}
                                        customStyle={styles.textInputCustom}

                                    />
                                </View>
                                <View style={styles.taxContainer}>
                                    <COMPONENT.SignatureTextInput
                                        isLeft={true}
                                        sign={'$'}
                                        placeholder={'0.00'}
                                        value={PropertyAmount}
                                        onChangeText={(text: any) => {
                                            setPropertyAmount(text)
                                        }}
                                        keyboardType={'default'}
                                        customStyle={styles.textInputCustom}

                                    />
                                </View>


                            </View>

                            <Text style={styles.title}>{'State'}</Text>
                            {renderPicker(stateData, 2)}
                            <Text style={styles.title}>{'County'}</Text>
                            {renderPicker(countryList, 3)}
                        </View>
                    }
                    <View style={styles.buttonContainer}>
                        <COMPONENT.Button
                            title={"CALCULATE"}
                            type={"fill"}
                            onPress={() => navigation.navigate("ResultBO")}
                        />
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )

}

export default VAPurchaseBO;
