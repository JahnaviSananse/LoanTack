import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  Text,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import styles from './styles';
import { useNavigation, useRoute } from '@react-navigation/native';
import { SwipeListView } from 'react-native-swipe-list-view';


interface IUDProps {
  scanRedirect: string;
}
const UploadedDocumentBO = (props: IUDProps) => {
  const navigation = useNavigation();
  const params = useRoute().params;
  let _swipeListView = null;
  const [data, setData] = React.useState([
    { title: 'img123.jpg', time: '3 mins ago', key: 0 },
    { title: 'Rental Insurance', time: '1 hour ago', key: 1 },
    { title: 'Health Insurance', time: '2 hours ago', key: 2 },
  ]);
  React.useEffect(() => { }, []);
  const renderItem = (item: any) => {
    return (
      <View style={styles.cellContainer}>
        <Image
          source={IMAGES.IC_DOCUMENT_FILLED}
          style={styles.docImage}
          resizeMode={'contain'}
        />
        <Text style={styles.title}>{item.item.title}</Text>
        <Text style={styles.time}>{item.item.time}</Text>
      </View>
    );
  };
  const closeRow = (rowMap: any, rowKey: any) => {
    if (rowMap[rowKey]) {
      rowMap[rowKey].closeRow();
    }
  };
  const deleteRow = (rowMap: any, rowKey: any, item: any) => {
    closeRow(rowMap, rowKey);
    let filteredAry = data.filter(fvalue => fvalue.title !== rowKey)
    setData(filteredAry);
  };
  const renderHiddenItem = (item: any, rowMap: any) => (
    <View style={styles.rowBack}>
      <Text></Text>
      <TouchableOpacity
        style={[styles.backRightBtn, styles.backRightBtnRight]}
        onPress={() => deleteRow(rowMap, item.item.title, item.item)}>
        <Image
          source={IMAGES.IC_DELETE}
          style={{ height: 25, width: 25 }}
          resizeMode={'contain'}
        />
      </TouchableOpacity>
    </View>
  );
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Uploaded Documents'}
          leftImg={params !== undefined && IMAGES.IC_BACK}
          leftClick={() => params !== undefined &&
            // navigation.navigate("ScanDocumentBO")
            navigation.navigate(props.scanRedirect)

          }
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
        />
        <SwipeListView
          ref={(ref) => (_swipeListView = ref)}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={(data) => renderItem(data)}
          renderHiddenItem={(data, rowMap) => renderHiddenItem(data, rowMap)}
          rightOpenValue={-50}
          previewRowKey={'0'}
          previewOpenValue={-40}
          previewOpenDelay={3000}
        />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  scanRedirect: state.common.scanRedirect
});

export default connect(mapStateToProps, {

})(UploadedDocumentBO);

// export default UploadedDocumentBO;
