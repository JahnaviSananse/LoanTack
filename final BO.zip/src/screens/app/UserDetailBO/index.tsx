import React from 'react';
import {
  KeyboardAvoidingView,
  View,
  SafeAreaView,
  TouchableOpacity,
  Text,
  ScrollView,
  Platform,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import {
  getUserProfile,
  saveBorrowerProfile,
  clearBorrowerProfile,
} from 'src/redux/actions/user';
import { connect } from 'react-redux';
import { IReduxState } from 'src/redux/reducers';
import { OpenValidationAlert, closeModal } from 'src/redux/actions/common';
import ImgToBase64 from 'react-native-image-base64';
interface IUserProfileProps {
  getUserProfile: Function;
  saveBorrowerProfile: Function;
  loading: boolean;
  borrowerProfileMessage: string;
  clearBorrowerProfile: Function;
  OpenValidationAlert: Function;
  closeModal: Function;
  profileData: any;
  borrowerProfileSuccess: boolean;
}
const ScanDocumentBO = (props: IUserProfileProps) => {
  const navigation = useNavigation();
  const [phone, setPhone] = React.useState('');
  const [code, setCode] = React.useState(1);
  const [name, setName] = React.useState('');
  const [displayPhone, setDisplayPhone] = React.useState('');
  const [showAlert, setShowAlert] = React.useState(false);
  const [alertMsg, setAlertMsg] = React.useState('');
  const [type, setType] = React.useState('failure');
  const [callingCode, setCallingCode] = React.useState('+1');
  const [countryCode, setCountryCode] = React.useState('US');
  const [country, setCountry] = React.useState(null);

  React.useEffect(() => {
    props.getUserProfile();
  }, []);
  React.useEffect(() => {
    if (props.borrowerProfileMessage && props.borrowerProfileSuccess == false) {
      setTimeout(() => {
        let obj = {
          message: props.borrowerProfileMessage,
          type: 'failure',
        };
        props.OpenValidationAlert(obj);
      }, 500);
    }
    if (props.borrowerProfileSuccess) {
      let obj = {
        message: 'User detail updated',
        type: 'success',
      };
      props.OpenValidationAlert(obj);
      setTimeout(() => {
        props.closeModal();
        props.clearBorrowerProfile();
        navigation.goBack();
      }, 1500);
    }
  }, [props.borrowerProfileMessage, props.borrowerProfileSuccess]);
  const onSelect = (country: any) => {
    setCountry(country);
    setCountryCode(country.cca2);
    setCallingCode('+' + country.callingCode);
  };
  React.useEffect(() => {
    if (props.profileData.data) {
      let data = props.profileData.data;
      let conNum = data.contact_number.toString()
      let phone = conNum.replace(/\D/g, '');
      const match = conNum.match(/^(\d{1,3})(\d{0,3})(\d{0,4})$/);
      if (match) {
        phone = `${match[1]}${match[2] ? ' ' : ''}${match[2]}${
          match[3] ? '-' : ''
          }${match[3]}`;
      }
      setName(data.name);
      setCountryCode(data.contact_code);
      setDisplayPhone(phone);
    }
  }, [props.profileData]);
  const validateForm = () => {
    let message = '';
    let isValidate = false;
    if (name.trim() === '') {
      message = 'Please enter name';
    } else if (displayPhone.trim() === '') {
      message = 'Please enter phone';
    } else {
      isValidate = true;
    }

    if (!isValidate) {
      let obj = {
        message: message,
        type: 'failure',
      };
      props.OpenValidationAlert(obj);
    } else {
      if (props.profileData) {
        let data = props.profileData.data;
        let phoneNum = displayPhone.replace(' ', '').replace('-', '');
        if (data.name !== name || phoneNum.toString() !== data.contact_number.toString() || data.contact_code !== countryCode) {
          var obj = {
            name: name,
            contact_number: phoneNum,
            contact_code: countryCode,
          };
          props.saveBorrowerProfile(obj);
        }
      }
    }
  };
  const renderButton = () => {
    return (
      <View style={styles.buttonPadding}>
        <COMPONENT.Button
          title={'SAVE'}
          type={'fill'}
          onPress={() => validateForm()}
        />
        <COMPONENT.Button
          title={'CANCEL'}
          type={'unfill'}
          onPress={() => navigation.goBack()}
        />
      </View>
    );
  };
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS == 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'android' ? -500 : 0}
      style={styles.keyboardAware}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.Header
          title={'User Details'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
        />
        <ScrollView contentContainerStyle={{ paddingBottom: 150 }}>
          <COMPONENT.TextField
            maxLength={50}
            value={name}
            keyboardType={'default'}
            title={'Name'}
            placeholder={'Enter Here'}
            secureTextEntry={false}
            style={styles.textField}
            onChangeText={(text: string) => {
              setName(text);
            }}
          />
          <COMPONENT.PhoneNumberInput
            maxLength={12}
            onSelect={onSelect}
            value={displayPhone}
            keyboardType={'number-pad'}
            title={'Cell Phone'}
            placeholder={'(xxx) xxx - xxxx'}
            onChangeText={(text: string) => {
              let phone = text.replace(/\D/g, '');
              const match = phone.match(/^(\d{1,3})(\d{0,3})(\d{0,4})$/);
              if (match) {
                phone = `${match[1]}${match[2] ? ' ' : ''}${match[2]}${
                  match[3] ? '-' : ''
                  }${match[3]}`;
              }
              setPhone(text);
              setDisplayPhone(phone);
            }}
          />
          {renderButton()}
        </ScrollView>
        <COMPONENT.Popup />
        <COMPONENT.Loader isLoading={props.loading} />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

const mapStateToProps = (state: IReduxState) => ({
  loading: state.user.loading,
  profileData: state.user.profileData,
  borrowerProfileMessage: state.user.borrowerProfileMessage,
  borrowerProfileSuccess: state.user.borrowerProfileSuccess,
});

export default connect(mapStateToProps, {
  getUserProfile,
  saveBorrowerProfile,
  OpenValidationAlert,
  closeModal,
  clearBorrowerProfile,
})(ScanDocumentBO);
