import React from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  SafeAreaView,
  TouchableOpacity,
  View,
  Image,
  Text,
} from 'react-native';
import * as IMAGES from 'src/assets/images';
import * as COMPONENT from 'src/components';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import * as modalInfo from 'src/redux/types/modalDescription';

const rows = [
  {
    title: 'A-D Loan',
    isOpen: false,
    desc: "Acquisition and Development – a loan for the purchase of raw land for the purpose of development"
  },
  {
    title: 'Abstract Title ',
    isOpen: false,
    desc: "A written history of the ownership of a parcel of land."
  },
  {
    title: 'Affidavit',
    isOpen: false,
    desc: "A sworn statement in writing."
  },
  {
    title: 'Amortization',
    isOpen: false,
    desc: "Amortization refers to the principal portion of the loan payment and is the loan payment by equal periodic payments calculated to pay off the debt at the end of a fixed period, including accrued interest on the outstanding balance. A fully amortized loan will be completely paid off at the end of the loan term."
  },
  {
    title: 'Realtor',
    isOpen: false,
    desc: "A sworn statement in writing."
  },
];
const desc =
  'Welcome to our comprehensive mortgage glossary where you can find definitions of various mortgage and real estate related terms.';
const LearningCenterBO = () => {
  const navigation = useNavigation();
  const [showAlert, setShowAlert] = React.useState(false);
  const [data, setData] = React.useState(rows);
  React.useEffect(() => { }, []);

  const renderItem = (item: any, ind: number) => {
    return (
      <View style={styles.cell}>
        <TouchableOpacity
          style={styles.cellContainer}
          onPress={() => {
            let tempData = JSON.parse(JSON.stringify(data));
            tempData[ind].isOpen = !tempData[ind].isOpen;
            setData(tempData);
          }}>
          <Text style={styles.title}>{item.title}</Text>
          <Image
            source={item.isOpen ? IMAGES.IC_UP_ARROW : IMAGES.IC_DOWN_ARROW}
            style={styles.arrow}
            resizeMode={'contain'}
          />
        </TouchableOpacity>
        {item.isOpen === true && (
          <View style={styles.flatlist}>
            <Text style={styles.descText}>{item.desc}</Text>
          </View>
        )}
      </View>
    );
  };
  const closeAlert = () => {
    setShowAlert(false);
  };
  return (
    <KeyboardAvoidingView
      behavior="padding"
      enabled
      style={styles.keyboardAwareL}>
      <SafeAreaView style={styles.container}>
        <COMPONENT.HeaderBO
          title={'Glossary'}
          leftImg={IMAGES.IC_BACK}
          leftClick={() => navigation.goBack()}
          rightOneClick={() => setShowAlert(true)}
          rightOneImg={IMAGES.IC_HEADER_INFO}
          righTwoImg={IMAGES.IC_HEADER_SHARE}
          popupInfo={{
            title: modalInfo.default.glossaryTitle,
            description: modalInfo.default.glossaryDescription,
          }}
        />
        <FlatList
          scrollEnabled={true}
          data={data}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => renderItem(item, index)}
        />
        <COMPONENT.InfoPopup
          title={'Glossary'}
          visible={showAlert}
          desciption={desc}
          closeAlert={() => closeAlert()}
        />
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
};

export default LearningCenterBO;
