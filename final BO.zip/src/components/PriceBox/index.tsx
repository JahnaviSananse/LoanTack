import React from 'react';

import { View, Text, TextInput } from 'react-native';

import styles from './styles';
interface IProps {
    sign: string;
    title: any;
    onChangeText: any;
    width: number;
}

const PriceBox = (props: IProps) => {
    return (
        <View style={[styles.buttonView, { width: props.width ? props.width : 80 }]}>
            <Text style={styles.signText}>{`${props.sign}`}</Text>
            <TextInput
                value={props.title.toString()}
                style={[styles.inputText, { width: props.width ? props.width - 20 : 60 }]}
                keyboardType={'decimal-pad'}
                onChangeText={(text) => props.onChangeText(text)}
            />
        </View>
    )
}
export default PriceBox;
