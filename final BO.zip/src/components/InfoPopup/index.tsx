import React from 'react';
import {Text, TouchableOpacity, View, Modal, Image, Alert} from 'react-native';
import styles from './style';
import * as IMAGES from 'src/assets/images';
import {useNavigation} from '@react-navigation/native';
import {connect} from 'react-redux';
import {IReduxState} from 'src/redux/reducers';
import {updateInfoModal} from 'src/redux/actions/modal';

interface IInfoPopupProps {
  isInfo: boolean;
  description: string;
  closeAlert: any;
  title: string;
  updateInfoModal: Function;
}

const InfoPopup = (props: IInfoPopupProps) => {
  const {isInfo, description, title, closeAlert} = props;

  return (
    <Modal
      animationType="none"
      transparent={true}
      visible={isInfo}
      onRequestClose={() => {}}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.desc}>{description}</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => {
              props.updateInfoModal(false, '', '');
            }}>
            <Image
              source={IMAGES.IC_CLOSE}
              style={styles.icon}
              resizeMode={'contain'}
            />
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
const mapStateToProps = (state: IReduxState) => ({
  isInfo: state.modal.isInfo,
  title: state.modal.title,
  description: state.modal.description,
});

export default connect(mapStateToProps, {
  updateInfoModal,
})(InfoPopup);
