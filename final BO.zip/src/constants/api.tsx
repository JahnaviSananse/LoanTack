export const BASE_URL = "http://139.59.65.130:5000/mob/api/v1/"
export const API_SIGNUP = "auth/signup"
export const API_LOGIN = "auth/login"
export const API_RESEND_CODE = "auth/resendverificationcode"