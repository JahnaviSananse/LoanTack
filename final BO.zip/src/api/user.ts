import request from './request';
import AxiosInstance from 'src/api/interceptorCall';
import AxiosFormDataInstance from 'src/api/interceptorFormDataCall';
import {Platform} from 'react-native';

export async function getUserProfile() {
  return AxiosInstance.get(`/user/profile`);
}

export async function changePassword(req: any) {
  console.log('reqreqreq', req);
  return AxiosInstance.put(`/user/changepassword`, req);
}

export async function saveUserProfile(req: any) {
  var imgObj: any = '';

  if (req.profile_photo.uri) {
    imgObj = {
      name:
        req.profile_photo.fileName === undefined ||
        req.profile_photo.fileName === null
          ? 'profile.jpeg'
          : req.profile_photo.fileName,
      type: req.profile_photo.type,
      uri: 'data:image/jpeg;base64,' + req.profile_photo.uri,
    };
  } else {
    imgObj = {
      name: req.profile_photo.substring(req.profile_photo.lastIndexOf('/') + 1),
      type: 'jpeg',
      uri: req.profile_photo,
    };
  }
  let formData = new FormData();
  var path_value =
    Platform.OS === 'android'
      ? req.profile_photo.uri
      : req.profile_photo.uri.toString().replace('file://', '');
  let newFile = {
    name:
      req.profile_photo.filename != null && req.profile_photo.filename != ''
        ? req.profile_photo.filename
        : 'file1.jpg',
    uri: path_value,
    type: req.profile_photo.type,
  };
  formData.append('profile_photo', newFile);
  formData.append('bio', req.bio);
  console.log('FORMDATA', formData);
  return AxiosFormDataInstance.post(`/user/loanofficer/profile`, formData);
}

export async function getNotification(req: any) {
  return AxiosInstance.get(`/user/notification`);
}

export async function saveNotification(req: any) {
  return AxiosInstance.post(`/user/notification`, req);
}

//Borrower
export async function saveBorrowerProfile(req: any) {
  return AxiosInstance.post(`/user/borrower/profile`, req);
}
